#!/usr/bin/env python3
"""Entry point — same as `python -m ckb_translator.cli` (defaults to the web server).

Pydroid 3 note
--------------
Pydroid's launcher (iiec_run.py) runs your file with exec(), which — unlike a
normal `python run.py` — does NOT put the script's folder on sys.path. So even
when `ckb_translator/` sits right next to this file, the import fails with:

    ModuleNotFoundError: No module named 'ckb_translator'

The bootstrap below fixes that: before importing, it locates the project root
via sys.argv[0], the current directory, common Android locations
(/sdcard, /storage/emulated/0, Download/…) or $BT_HOME, and prepends it to
sys.path. If the package is genuinely missing (only run.py was copied to the
device) it exits with a clear bilingual Kurdish/English message instead of a
bare traceback.
"""
from __future__ import annotations

import os
import sys

_MARKER_FILE = os.path.join("ckb_translator", "__init__.py")


def _candidate_roots() -> list[str]:
    roots: list[str] = []

    # 1) explicit override
    for var in ("BT_HOME", "CKB_TRANSLATOR_HOME"):
        if os.environ.get(var):
            roots.append(os.environ[var])

    # 2) the file being run — Pydroid's exec() leaves __file__ undefined,
    #    but sys.argv[0] is the path of this script.
    if sys.argv and sys.argv[0] and not sys.argv[0].startswith("-"):
        roots.append(os.path.dirname(os.path.abspath(sys.argv[0])))

    # 3) __file__ (normal interpreter)
    module_file = globals().get("__file__")
    if module_file:
        roots.append(os.path.dirname(os.path.abspath(module_file)))

    # 4) working directory (Pydroid usually sets cwd to the script's folder)
    roots.append(os.getcwd())
    parent = os.getcwd()
    for _ in range(3):
        parent = os.path.dirname(parent)
        if parent:
            roots.append(parent)

    # 5) common Android locations, incl. zips extracted into Download/Documents
    for base in ("/sdcard", "/storage/emulated/0"):
        for sub in ("", "Download", "Documents",
                    "Download/book-translator-ckb",
                    "Documents/book-translator-ckb"):
            roots.append(os.path.join(base, sub))

    # 6) launched from the parent of the project folder
    roots.append(os.path.join(os.getcwd(), "book-translator-ckb"))
    return roots


def _find_project_root() -> str | None:
    seen: set[str] = set()
    for root in _candidate_roots():
        root = os.path.abspath(os.path.expanduser(root))
        if root in seen or not os.path.isdir(root):
            continue
        seen.add(root)
        # direct hit: <root>/ckb_translator/__init__.py
        if os.path.isfile(os.path.join(root, _MARKER_FILE)):
            return root
        # the candidate IS the package folder itself
        if (os.path.basename(root) == "ckb_translator"
                and os.path.isfile(os.path.join(root, "__init__.py"))):
            return os.path.dirname(root)
        # zip extracted one level deeper (…/book-translator-ckb/book-translator-ckb)
        nested = os.path.join(root, "book-translator-ckb")
        if os.path.isfile(os.path.join(nested, _MARKER_FILE)):
            return nested
    return None


_PROJECT_ROOT = _find_project_root()

if _PROJECT_ROOT is None:
    sys.stderr.write(
        "\n[ERROR] ckb_translator package not found\n"
        "-----------------------------------------\n"
        "Extract the ENTIRE book-translator-ckb folder first (running run.py\n"
        "alone, without the ckb_translator/ folder next to it, cannot work).\n"
        "Example layout on Android:\n"
        "    /sdcard/book-translator-ckb/run.py\n"
        "    /sdcard/book-translator-ckb/ckb_translator/   <-- required\n"
        "Then open run.py from INSIDE that folder, or point BT_HOME at it:\n"
        "    export BT_HOME=/sdcard/book-translator-ckb\n"
        "\n"
        "[هەڵە] پاکێجی ckb_translator نەدۆزرایەوە\n"
        "سەرەتا تەواوی فۆڵدەری book-translator-ckb دەربکە (extract)\n"
        "— تەنها run.py بەتەنها بەس نییە — دواتر run.py لەناو ئەو\n"
        "فۆڵدەرەوە بکەرەوە و جێبەجێی بکە.\n\n")
    raise SystemExit(1)

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

# Relative paths in the config (fonts/, data/, …) resolve against the
# working directory. When the project was located somewhere else (BT_HOME,
# argv[0], an Android scan path), move there so those paths still work.
if not os.path.isfile(os.path.join(os.getcwd(), _MARKER_FILE)):
    os.chdir(_PROJECT_ROOT)

from ckb_translator.cli import main  # noqa: E402

if __name__ == "__main__":
    if len(sys.argv) == 1:
        sys.argv = [sys.argv[0], "serve"]
    raise SystemExit(main())
