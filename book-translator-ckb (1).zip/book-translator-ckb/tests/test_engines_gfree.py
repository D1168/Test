"""Offline tests for the free Google engine (no network access needed)."""
from __future__ import annotations

import io
import json
import urllib.error

import pytest

from ckb_translator.core.config import TranslationConfig, runtime_options
from ckb_translator.translate.engines import FreeGoogleTranslator, build_engine


def _cfg() -> TranslationConfig:
    return TranslationConfig(engine="gfree", target_language="ckb",
                             free_delay=0.0)


class _FakeResponse:
    def __init__(self, payload: bytes, status: int = 200):
        self._stream = io.BytesIO(payload)
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self) -> bytes:
        return self._stream.read()


def _seg_payload(translations: list[str]) -> bytes:
    """Shape the endpoint returns: [[[trans, orig, ...], ...], ...]."""
    return json.dumps([[[t, "orig", None, None] for t in translations],
                       None, "en", False]).encode()


def _http_error(code: int) -> urllib.error.HTTPError:
    return urllib.error.HTTPError("url", code, "err", hdrs=None, fp=None)


def test_translate_joins_segments(monkeypatch):
    calls = []

    def fake_urlopen(req, timeout=None):
        calls.append(req.full_url)
        assert "tl=ckb" in req.full_url
        return _FakeResponse(_seg_payload(["سڵاو", " جیهان"]))

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    out = FreeGoogleTranslator(_cfg()).translate(["Hello world"])
    assert out == ["سڵاو جیهان"]
    assert len(calls) == 1


def test_empty_texts_pass_through(monkeypatch):
    seen = []

    def fake_urlopen(req, timeout=None):
        seen.append(req.full_url)
        return _FakeResponse(_seg_payload(["x"]))

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    out = FreeGoogleTranslator(_cfg()).translate(["", "  ", "Hello"])
    assert out == ["", "  ", "x"]
    assert len(seen) == 1  # only the non-empty text hit the network


def test_backoff_on_429_then_success(monkeypatch):
    sleeps: list[float] = []
    monkeypatch.setattr("time.sleep", sleeps.append)
    attempts = {"n": 0}

    def fake_urlopen(req, timeout=None):
        attempts["n"] += 1
        if attempts["n"] <= 2:          # two 429s, then success
            raise _http_error(429)
        return _FakeResponse(_seg_payload(["وەرگێڕان"]))

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    out = FreeGoogleTranslator(_cfg()).translate(["Hello"])
    assert out == ["وەرگێڕان"]
    assert attempts["n"] == 3
    assert len(sleeps) == 2             # 0.2*2^0, 0.2*2^1


def test_gives_up_after_retries(monkeypatch):
    monkeypatch.setattr("time.sleep", lambda s: None)
    attempts = {"n": 0}

    def fake_urlopen(req, timeout=None):
        attempts["n"] += 1
        raise _http_error(429)

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    with pytest.raises(RuntimeError, match="free Google request failed"):
        FreeGoogleTranslator(_cfg()).translate(["Hello"])
    assert attempts["n"] == FreeGoogleTranslator.RETRIES


def test_delay_from_env(monkeypatch):
    monkeypatch.setenv("BT_FREE_DELAY", "1.5")
    assert FreeGoogleTranslator(_cfg()).delay == 1.5


def test_engine_registered_and_validated(tmp_path):
    from ckb_translator.core.config import AppConfig, load_config
    cfg = load_config(None)
    cfg.base_dir = tmp_path
    opts = runtime_options(cfg, {"engine": "gfree"})
    assert opts["engine"] == "gfree"
    engine = build_engine(cfg, opts)
    assert isinstance(engine, FreeGoogleTranslator)
    assert engine.name == "gfree"
