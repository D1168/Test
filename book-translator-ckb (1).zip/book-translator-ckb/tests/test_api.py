"""End-to-end API test: upload -> create job -> poll -> download.

Uses the mock engine and 72 dpi so it runs fully offline and fast, while
exercising the real pipeline (extract -> translate -> inpaint -> render ->
export) through the HTTP layer.
"""
from __future__ import annotations

import io
import time

import pytest
from fastapi.testclient import TestClient

from ckb_translator.main import create_app


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)  # config.yaml is not picked up here
    app = create_app(str(tmp_path / "unused-config.yaml"))

    # redirect runtime dirs into tmp_path
    from ckb_translator.core.config import resolve_path
    cfg = app.state.config
    cfg.base_dir = tmp_path
    cfg.jobs.dir = str(tmp_path / "jobs")
    cfg.jobs.uploads_dir = str(tmp_path / "uploads")
    cfg.jobs.output_dir = str(tmp_path / "output")
    cfg.cache.path = str(tmp_path / "cache.sqlite3")
    cfg.translation.engine = "mock"
    app.state.manager = __import__("ckb_translator.core.jobs", fromlist=["JobManager"]).JobManager(cfg)

    from ckb_translator.samplebook import make_sample_pdf
    book = tmp_path / "book.pdf"
    make_sample_pdf(book)

    with TestClient(app) as test_client:
        yield test_client, book


def test_health(client):
    http, _book = client
    res = http.get("/api/health")
    assert res.status_code == 200
    body = res.json()
    assert body["status"] == "ok"
    assert isinstance(body["raqm"], bool)


def test_config_endpoint_hides_secrets(client):
    http, _book = client
    # plant fake secrets and make sure no VALUE ever leaks
    cfg = http.app.state.config
    fake_cred = "/tmp/pytest/secret-service-account.json"
    fake_key = "sk-ant-fake-secret-key-123"
    cfg.translation.google_credentials = fake_cred
    cfg.post_edit.api_key = fake_key
    body = http.get("/api/config").json()
    rendered = str(body)
    assert fake_cred not in rendered
    assert fake_key not in rendered
    assert "BEGIN PRIVATE" not in rendered
    assert body["engines"]["mock"]["available"] is True


def test_upload_rejects_bad_extension(client):
    http, _book = client
    res = http.post("/api/upload",
                    files={"files": ("virus.exe", b"xxxx", "application/octet-stream")})
    assert res.status_code == 415


def test_full_translation_flow(client):
    http, book = client

    # ---- upload ----
    res = http.post("/api/upload", files={
        "files": ("book.pdf", book.read_bytes(), "application/pdf")})
    assert res.status_code == 200
    names = res.json()["names"]
    assert len(names) == 1

    # ---- create job ----
    res = http.post("/api/jobs", json={
        "uploads": names,
        "options": {"engine": "mock", "dpi": 72, "alignment": "mirror",
                    "page_workers": 2}})
    assert res.status_code == 200
    job_id = res.json()["id"]

    # ---- poll until finished (pages processed independently) ----
    deadline = time.time() + 120
    detail = None
    while time.time() < deadline:
        detail = http.get(f"/api/jobs/{job_id}").json()
        if detail["status"] in ("completed", "completed_with_errors", "failed"):
            break
        time.sleep(0.4)
    assert detail is not None
    assert detail["status"] in ("completed", "completed_with_errors"), \
        f"job did not finish: {detail}"
    assert detail["progress"]["total"] == 3
    assert detail["progress"]["done"] == 3
    assert detail["progress"]["failed"] == 0

    # ---- page preview ----
    res = http.get(f"/api/jobs/{job_id}/pages/0/preview")
    assert res.status_code == 200
    assert res.headers["content-type"].startswith("image/jpeg")

    # ---- download output ----
    res = http.get(f"/api/jobs/{job_id}/output")
    assert res.status_code == 200
    assert res.content[:5] == b"%PDF-"
    assert len(res.content) > 10_000

    # ---- job list ----
    jobs = http.get("/api/jobs").json()["jobs"]
    assert any(j["id"] == job_id for j in jobs)


def test_unknown_job_404(client):
    http, _book = client
    assert http.get("/api/jobs/job_missing").status_code == 404


def test_engine_google_without_credentials_rejected(client):
    http, book = client
    res = http.post("/api/upload", files={
        "files": ("book.pdf", book.read_bytes(), "application/pdf")})
    names = res.json()["names"]
    res = http.post("/api/jobs", json={"uploads": names,
                                       "options": {"engine": "google"}})
    assert res.status_code == 400
    assert "Google" in res.json()["detail"]
