"""Pipeline-level tests: resume after failure, cancel, reflowable EPUB path."""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import pytest

from ckb_translator.core.config import runtime_options
from ckb_translator.core.jobs import JobManager
from ckb_translator.core.models import JobState
from ckb_translator.core.pipeline import BookJob
from ckb_translator.samplebook import make_sample_pdf


def _make_state(config, paths, input_type, options=None) -> JobState:
    manager = JobManager(config)
    return manager.create(paths, Path(paths[0]).name, input_type,
                          runtime_options(config, options or {}))


def test_resume_after_page_failure(config, sample_pdf):
    """Pages already 'done' are skipped on re-run; failed ones are retried."""
    from ckb_translator.translate.engines import PassthroughTranslator

    calls = {"n": 0}

    class Flaky(PassthroughTranslator):
        """Fails every call until told to succeed."""
        fail = True

        def translate(self, texts):
            calls["n"] += 1
            if Flaky.fail:
                raise RuntimeError("engine exploded")
            return super().translate(texts)

    state = _make_state(config, [str(sample_pdf)], "pdf")
    job = BookJob(state, config)
    job.translator.engine = Flaky()
    job.run()
    assert state.status == "completed_with_errors"
    assert state.progress()["failed"] == 3
    assert state.output and Path(state.output).is_file()  # failed pages included as originals

    # ---- resume with a working engine ----
    flaky_calls_before = calls["n"]
    job2 = BookJob(state, config)  # fresh job, same persistent state
    job2.translator.engine = PassthroughTranslator()
    job2.run()
    assert state.status == "completed"
    assert state.progress() == {"total": 3, "done": 3, "failed": 0, "pending": 0}
    assert calls["n"] == flaky_calls_before  # no more engine failures


def test_done_pages_are_not_retranslated(config, sample_pdf):
    state = _make_state(config, [str(sample_pdf)], "pdf")
    job = BookJob(state, config)
    job.run()
    assert state.status == "completed"

    # mark page 1 as pending again and re-run: pages 0 and 2 keep their images
    page_paths = [job.pages_dir / f"page_{i:04d}.png" for i in range(3)]
    mtimes = [p.stat().st_mtime_ns for p in page_paths]

    state.pages[1].status = "pending"
    time.sleep(0.01)
    job2 = BookJob(state, config)
    job2.run()
    assert state.status == "completed"
    assert page_paths[0].stat().st_mtime_ns == mtimes[0]
    assert page_paths[2].stat().st_mtime_ns == mtimes[2]
    assert page_paths[1].stat().st_mtime_ns != mtimes[1]  # only page 1 re-rendered


def test_cancel_between_pages(config, sample_pdf):
    state = _make_state(config, [str(sample_pdf)], "pdf")
    job = BookJob(state, config)
    job.progress_hook = lambda i, s: job.cancel_event.set()  # cancel after page 0
    job.run()
    assert state.status == "cancelled"
    assert state.progress()["done"] >= 1  # the finished page persisted


def test_cache_makes_resume_cheap(config, sample_pdf):
    state = _make_state(config, [str(sample_pdf)], "pdf")
    job = BookJob(state, config)
    job.run()
    assert state.status == "completed"
    assert state.stats["engine_calls"] >= 1

    # re-run everything with a FRESH job: all translations must come from cache
    for page in state.pages:
        page.status = "pending"
    state.status = "pending"
    job2 = BookJob(state, config)
    job2.run()
    assert state.status == "completed"
    assert state.stats["engine_calls"] == 0, "cache should serve every segment"
    assert state.stats["cache_hits"] > 0


def test_epub_pipeline_round_trip(config):
    """EPUB in -> translate -> EPUB out, with embedded Kurdish font."""
    from ckb_translator.export import build_epub
    from ckb_translator.extract.reflow_doc import EpubDocument

    source = config.base_dir / "book.epub"
    paragraph = ("The mountains stand high above the valley. Every spring the "
                 "snow melts and the rivers run toward the sea. The shepherds "
                 "move with their flocks from village to village.")
    build_epub("Mountains", [
        ("Mountains", [(paragraph, False, 11.0)]),
    ], source, font_path=None)

    state = _make_state(config, [str(source)], "epub")
    job = BookJob(state, config)
    job.run()
    assert state.status == "completed"
    assert state.output and Path(state.output).suffix == ".epub"
    assert Path(state.output).is_file()

    out = EpubDocument(state.output)
    chapters = out.chapters()
    assert chapters, "output epub must have chapters"
    # mock engine translated the known sentence
    joined = " ".join(b.text for ch in chapters for b in ch.blocks)
    assert "چیاکان" in joined


def test_epub_pipeline_pdf_output(config):
    """EPUB in -> re-typeset PDF out."""
    from ckb_translator.export import build_epub

    source = config.base_dir / "book.epub"
    paragraph = ("The mountains stand high above the valley. Every spring the "
                 "snow melts and the rivers run toward the sea. The shepherds "
                 "move with their flocks from village to village.")
    build_epub("Mountains", [
        ("Mountains", [(paragraph, False, 11.0)]),
    ], source, font_path=None)

    state = _make_state(config, [str(source)], "epub",
                        {"output_format": "pdf"})
    job = BookJob(state, config)
    job.run()
    assert state.status == "completed"
    assert Path(state.output).suffix == ".pdf"
    assert Path(state.output).is_file()
    import fitz
    with fitz.open(state.output) as doc:
        assert doc.page_count >= 1


def test_job_state_json_round_trip(config, sample_pdf):
    state = _make_state(config, [str(sample_pdf)], "pdf")
    state.pages[0].status = "done"
    state.pages[1].status = "failed"
    state.pages[1].error = "boom"
    raw = state.to_json()
    loaded = JobState.from_json(raw)
    assert loaded.id == state.id
    assert loaded.pages[1].status == "failed"
    assert loaded.pages[1].error == "boom"
    assert loaded.progress() == {"total": 3, "done": 1, "failed": 1, "pending": 1}
