"""Unit tests for OCR line grouping and style estimation (engine-agnostic)."""
from __future__ import annotations

import numpy as np
import pytest
from PIL import Image, ImageDraw

from ckb_translator.extract.ocr import TesseractOcrProvider, _Line, _estimate_style, group_lines
from ckb_translator.extract.pdf_doc import merge_lines


def _lines(spec: list[tuple]) -> list[_Line]:
    return [_Line(rect=(s[0], s[1], s[2], s[3]), text=s[4]) for s in spec]


def test_group_lines_merges_paragraph():
    lines = _lines([
        (100, 100, 400, 120, "first line"),
        (100, 122, 380, 142, "second line"),
        (102, 144, 390, 164, "third line"),
    ])
    boxes = group_lines(lines, Image.new("RGB", (500, 300)), dpi=150)
    assert len(boxes) == 1
    assert boxes[0].bbox == (100, 100, 400, 164)
    assert boxes[0].text == merge_lines(["first line", "second line", "third line"])
    assert boxes[0].source == "ocr"


def test_group_lines_splits_distant_paragraphs():
    lines = _lines([
        (100, 100, 400, 120, "para one"),
        (100, 300, 400, 320, "para two far below"),
    ])
    boxes = group_lines(lines, Image.new("RGB", (500, 500)), dpi=150)
    assert len(boxes) == 2


def test_group_lines_splits_columns():
    # two columns side by side, same rows — no x overlap
    lines = _lines([
        (50, 100, 220, 120, "left col line"),
        (280, 100, 450, 120, "right col line"),
        (50, 122, 210, 142, "left col line two"),
        (282, 122, 445, 142, "right col line two"),
    ])
    boxes = group_lines(lines, Image.new("RGB", (500, 300)), dpi=150)
    assert len(boxes) == 2


def test_estimate_style_dark_text_on_white(arabic_font):
    image = Image.new("RGB", (300, 80), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    draw.text((20, 10), "some text here", fill=(30, 30, 30),
              font=__import__("PIL.ImageFont", fromlist=["truetype"]).truetype(str(arabic_font), 40))
    color, bold = _estimate_style(image, (0, 0, 300, 80))
    assert all(0 <= c <= 80 for c in color), f"expected near-black, got {color}"
    assert isinstance(bold, bool)


def test_estimate_style_light_text_on_dark(arabic_font):
    image = Image.new("RGB", (300, 80), (10, 10, 10))
    draw = ImageDraw.Draw(image)
    draw.text((20, 10), "some text here", fill=(240, 240, 240),
              font=__import__("PIL.ImageFont", fromlist=["truetype"]).truetype(str(arabic_font), 40))
    color, _bold = _estimate_style(image, (0, 0, 300, 80))
    assert all(c >= 180 for c in color), f"expected near-white, got {color}"


def test_estimate_style_empty_region():
    image = Image.new("RGB", (50, 50), "white")
    color, bold = _estimate_style(image, (0, 0, 50, 50))
    assert color == (0, 0, 0)
    assert bold is False


@pytest.mark.skipif(not __import__("shutil").which("tesseract"),
                    reason="tesseract binary not installed")
def test_tesseract_provider_end_to_end():
    image = Image.new("RGB", (600, 200), "white")
    draw = ImageDraw.Draw(image)
    draw.text((50, 50), "The quick brown fox", fill=(0, 0, 0))
    draw.text((50, 90), "jumps over the lazy dog", fill=(0, 0, 0))

    from ckb_translator.core.config import OcrConfig
    provider = TesseractOcrProvider(OcrConfig())
    boxes = provider.get_boxes(image)
    assert boxes, "tesseract found no text"
    combined = " ".join(b.text for b in boxes).lower()
    assert "quick" in combined and "lazy" in combined
    box = boxes[0]
    assert box.source == "ocr"
    assert box.bbox[2] > box.bbox[0] and box.bbox[3] > box.bbox[1]
    assert 5 <= box.font_size_pt <= 60


def test_build_ocr_provider_none():
    from ckb_translator.core.config import OcrConfig
    from ckb_translator.extract.ocr import build_ocr_provider
    assert build_ocr_provider(OcrConfig(provider="none")) is None


def test_build_ocr_provider_paddle_missing_raises():
    from ckb_translator.core.config import OcrConfig
    from ckb_translator.extract.ocr import OcrError, build_ocr_provider, _paddle_available
    if _paddle_available():
        pytest.skip("paddle installed — cannot test the error path")
    with pytest.raises(OcrError):
        build_ocr_provider(OcrConfig(provider="paddle"))
