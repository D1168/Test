"""Unit tests for RTL rendering (shaping, bidi, wrapping, fitting, alignment)."""
from __future__ import annotations

import numpy as np
import pytest
from PIL import Image

from ckb_translator.render import rtl

KURDISH = "سلاو کوردستان! ئەم دەقە بۆ تاقیکردنەوەی خوێندنەوەی ڕاست بۆ چەپە."
LONG = ("ئەم ڕستەیە درێژە و دەبێت بە چەند دێڕێکی جیاوازدا تێپەڕێت " * 8)


# ------------------------------------------------------------------ #
# shaping / bidi
# ------------------------------------------------------------------ #

def test_reshape_produces_presentation_forms():
    reshaped = rtl.reshape("سلام")
    assert any(ord(ch) >= 0xFE70 for ch in reshaped), \
        "expected Arabic presentation forms after reshaping"
    assert reshaped != "سلام"


def test_reshape_joins_kurdish_letters():
    # Kurdish-specific letters must still trigger joining of neighbours
    reshaped = rtl.reshape("کوردی")
    assert reshaped != "کوردی"


def test_bidi_moves_trailing_punctuation_to_visual_left():
    display = rtl.shape_for_display("سلاو!")
    # RTL paragraph: the trailing '!' is rendered leftmost -> first char
    assert display.startswith("!")


def test_bidi_keeps_digits_readable():
    display = rtl.shape_for_display("ساڵی ٢٠٢٥")
    assert any(ch.isdigit() for ch in display)


def test_shape_for_display_idempotent_for_latin():
    assert rtl.shape_for_display("hello world") == "hello world"


def test_source_is_rtl_detection():
    assert rtl.source_is_rtl("کوردیی ناوەندی") is True
    assert rtl.source_is_rtl("The mountains are high") is False
    assert rtl.source_is_rtl("") is False
    assert rtl.source_is_rtl("12345") is False


def test_convert_numerals():
    assert rtl.convert_numerals("2025") == "٢٠٢٥"
    assert rtl.convert_numerals("page 3 of 12") == "page ٣ of ١٢"
    assert rtl.convert_numerals("no digits") == "no digits"


# ------------------------------------------------------------------ #
# alignment mapping
# ------------------------------------------------------------------ #

@pytest.mark.parametrize("original,mode,source,expected", [
    ("left", "mirror", "English text", "right"),
    ("right", "mirror", "English text", "left"),
    ("center", "mirror", "English text", "center"),
    ("left", "preserve", "English text", "left"),
    ("right", "preserve", "English text", "right"),
    ("left", "right", "anything", "right"),
    ("left", "auto", "English text", "right"),      # LTR source -> mirror
    ("right", "auto", "نص عربي", "right"),           # RTL source -> preserve
    ("left", "auto", "نص عربي", "left"),
    ("bogus", "preserve", "x", "left"),
])
def test_effective_alignment(original, mode, source, expected):
    assert rtl.effective_alignment(original, mode, source) == expected


# ------------------------------------------------------------------ #
# wrapping / fitting
# ------------------------------------------------------------------ #


def test_wrap_respects_max_width(arabic_font):
    font = rtl.load_font(arabic_font, 24)
    lines = rtl.wrap_text(LONG, font, 260)
    assert len(lines) > 1
    for line in lines:
        assert rtl.text_width(line, font) <= 260 + 0.5


def test_wrap_preserves_explicit_line_breaks(arabic_font):
    font = rtl.load_font(arabic_font, 20)
    lines = rtl.wrap_text("دێڕی یەکەم\nدێڕی دووەم", font, 500)
    assert lines == ["دێڕی یەکەم", "دێڕی دووەم"]


def test_wrap_single_long_word_is_not_split(arabic_font):
    font = rtl.load_font(arabic_font, 20)
    word = "چواردەڕەمانەیی" * 3
    lines = rtl.wrap_text(word, font, 60)
    assert lines == [word]  # overflow is handled by fit_text, not by breaking words


def test_fit_shrinks_font_to_fit_box(arabic_font):
    size, lines, step, overflow = rtl.fit_text(
        LONG, arabic_font, box_w=280, box_h=200, start_size=48, min_size=9)
    assert size <= 48
    font = rtl.load_font(arabic_font, size)
    assert all(rtl.text_width(l, font) <= 280 + 0.5 for l in lines)
    assert step * len(lines) <= 200
    assert overflow is False


def test_fit_reports_overflow_when_impossible(arabic_font):
    size, lines, step, overflow = rtl.fit_text(
        LONG, arabic_font, box_w=30, box_h=20, start_size=40, min_size=9)
    assert size == 9
    assert overflow is True


def test_fit_fits_when_generous(arabic_font):
    size, _lines, _step, overflow = rtl.fit_text(
        "سلاو", arabic_font, box_w=400, box_h=120, start_size=40, min_size=9)
    assert size == 40
    assert overflow is False


# ------------------------------------------------------------------ #
# block rendering
# ------------------------------------------------------------------ #

def _ink_columns(image, box):
    x0, y0, x1, y1 = box
    region = np.asarray(image.convert("L").crop((x0, y0, x1, y1)))
    ink = region < 128
    cols = ink.any(axis=0)
    return int(np.argmax(cols)), int(len(cols) - 1 - np.argmax(cols[::-1])), cols


@pytest.mark.usefixtures("arabic_font")
def test_draw_block_right_alignment():
    from tests.conftest import ARABIC_FONT
    image = Image.new("RGB", (400, 120), "white")
    box = (20, 20, 380, 100)
    rtl.draw_block(image, box, "سلاو کوردستان",
                   font_path=ARABIC_FONT, color=(0, 0, 0),
                   alignment="left", alignment_mode="mirror",
                   start_size_px=40, min_size=10)
    first_ink, last_ink, _cols = _ink_columns(image, box)
    assert 380 - 20 - last_ink <= 8, "right-aligned text must touch the right edge"
    assert first_ink > 60, "right-aligned short text must not start at the left edge"


@pytest.mark.usefixtures("arabic_font")
def test_draw_block_left_alignment():
    from tests.conftest import ARABIC_FONT
    image = Image.new("RGB", (400, 120), "white")
    box = (20, 20, 380, 100)
    rtl.draw_block(image, box, "سلاو کوردستان",
                   font_path=ARABIC_FONT, color=(0, 0, 0),
                   alignment="left", alignment_mode="preserve",
                   start_size_px=40, min_size=10)
    first_ink, _last, _cols = _ink_columns(image, box)
    assert first_ink <= 8, "left-aligned text must start at the left edge"


@pytest.mark.usefixtures("arabic_font")
def test_draw_block_center_alignment():
    from tests.conftest import ARABIC_FONT
    image = Image.new("RGB", (400, 120), "white")
    box = (20, 20, 380, 100)
    rtl.draw_block(image, box, "سلاو",
                   font_path=ARABIC_FONT, color=(0, 0, 0),
                   alignment="center", alignment_mode="preserve",
                   start_size_px=40, min_size=10)
    first_ink, last_ink, _cols = _ink_columns(image, box)
    left_gap, right_gap = first_ink, (360 - last_ink)
    assert abs(left_gap - right_gap) <= 12, "centred text must be centred"


@pytest.mark.usefixtures("arabic_font")
def test_draw_block_wraps_inside_box():
    from tests.conftest import ARABIC_FONT
    image = Image.new("RGB", (300, 300), "white")
    box = (10, 10, 210, 290)
    info = rtl.draw_block(image, box, LONG,
                          font_path=ARABIC_FONT, color=(0, 0, 0),
                          alignment="right", alignment_mode="preserve",
                          start_size_px=30, min_size=10)
    assert info["lines"] >= 2
    assert info["overflow"] is False
    # no ink outside the box horizontally
    region = np.asarray(image.convert("L"))
    assert (region[:10, :] < 128).sum() == 0
    assert (region[:, :10] < 128).sum() == 0


def test_draw_block_uses_given_color():
    image = Image.new("RGB", (300, 100), "white")
    rtl.draw_block(image, (10, 10, 290, 90), "سلاو",
                   font_path=None, color=(200, 30, 30),
                   alignment="left", alignment_mode="preserve",
                   start_size_px=30, min_size=10)
    arr = np.asarray(image)
    ink = (arr.min(axis=2) < 240)
    assert ink.any()
    red_mask = (arr[:, :, 0] > 150) & (arr[:, :, 1] < 120)
    assert (ink & red_mask).sum() > 20, "ink should be reddish"


def test_draw_block_empty_text_is_noop():
    image = Image.new("RGB", (100, 100), "white")
    info = rtl.draw_block(image, (10, 10, 90, 90), "   ",
                          font_path=None, color=(0, 0, 0))
    assert info["lines"] == 0
    assert np.asarray(image).min() == 255


def test_draw_block_survives_missing_font():
    image = Image.new("RGB", (300, 100), "white")
    info = rtl.draw_block(image, (10, 10, 290, 90), "سلاو",
                          font_path="/nonexistent/font.ttf", color=(0, 0, 0),
                          start_size_px=30, min_size=10)
    assert info["size"] > 0  # fell back to a default font without crashing
