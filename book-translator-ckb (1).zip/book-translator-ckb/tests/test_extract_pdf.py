"""Unit tests for PDF text-layer extraction (bbox, size, colour, flags)."""
from __future__ import annotations

import fitz
import pytest

from ckb_translator.core.models import Document
from ckb_translator.extract.pdf_doc import PdfDocument, guess_alignment, merge_lines


def test_guess_alignment_left():
    rects = [(0, 0, 100, 10), (0, 12, 80, 22), (0, 24, 90, 34)]
    assert guess_alignment(rects) == "left"


def test_guess_alignment_right():
    rects = [(20, 0, 100, 10), (40, 12, 100, 22), (30, 24, 100, 34)]
    assert guess_alignment(rects) == "right"


def test_guess_alignment_center():
    rects = [(10, 0, 90, 10), (20, 12, 80, 22), (15, 24, 85, 34)]
    assert guess_alignment(rects) == "center"


def test_guess_alignment_single_line_defaults_left():
    assert guess_alignment([(0, 0, 100, 10)]) == "left"


def test_merge_lines_dehyphenates():
    assert merge_lines(["mountain-", "ous"]) == "mountainous"
    assert merge_lines(["hello", "world"]) == "hello world"
    assert merge_lines(["double  spaces", " collapse"]) == "double spaces collapse"


def test_pdf_extract_finds_blocks(sample_pdf):
    doc = PdfDocument(sample_pdf)
    assert doc.page_count == 3
    assert doc.has_text_layer(0)

    boxes = doc.extract_boxes(0, dpi=150)
    assert len(boxes) >= 3  # title, subtitle, author, edition

    title = boxes[0]
    assert "Little Book of Kurdistan" in title.text
    assert title.bold is True
    assert title.font_size_pt == pytest.approx(28, abs=1.5)
    assert title.alignment == "center"
    # colour roughly (0.13, 0.16, 0.45) * 255
    assert title.color[2] > title.color[0]  # blue-ish
    assert title.dpi == 150
    assert title.source == "text"
    # bbox in pixels at 150 dpi: A4 width 595pt -> ~1239 px
    assert 0 < title.bbox[0] < 300 < title.bbox[2] <= 1240
    assert title.mask_polys, "mask polygons must be recorded for inpainting"


def test_pdf_extract_justified_paragraph_and_page_number(sample_pdf):
    doc = PdfDocument(sample_pdf)
    boxes = doc.extract_boxes(1, dpi=150)
    body = [b for b in boxes if "mountains stand high" in b.text]
    assert body, "justified body paragraph must be extracted"
    assert body[0].alignment == "left"  # justified reads as left-aligned
    assert body[0].bold is False
    assert body[0].font_size_pt == pytest.approx(11, abs=1.5)
    # the mock dictionary key must round-trip through line merging
    assert body[0].text.startswith("The mountains stand high above the valley.")

    page_number = [b for b in boxes if b.text.strip() == "2"]
    assert page_number and page_number[0].alignment == "center"


def test_pdf_extract_sans_and_italic_flags(sample_pdf):
    doc = PdfDocument(sample_pdf)
    boxes = doc.extract_boxes(0, dpi=150)
    subtitle = [b for b in boxes if "translation pipeline" in b.text][0]
    assert classify_sans(subtitle.font_name) == "sans"
    author = [b for b in boxes if "Sample Author" in b.text][0]
    assert author.italic is True


def classify_sans(name: str) -> str:
    from ckb_translator.font_match import classify_font
    return classify_font(name)


def test_pdf_render_page_size(sample_pdf):
    doc = PdfDocument(sample_pdf)
    image = doc.render_page(0, dpi=150)
    # A4 at 150 dpi ≈ 1240 x 1754
    assert 1200 <= image.width <= 1260
    assert 1720 <= image.height <= 1790
    assert image.mode == "RGB"


def test_scanned_page_has_no_text_layer(sample_pdf, tmp_path):
    from ckb_translator.samplebook import make_scanned_pdf
    scanned = make_scanned_pdf(sample_pdf, tmp_path / "scan.pdf", dpi=100)
    doc = PdfDocument(scanned)
    assert doc.has_text_layer(0) is False
    with pytest.raises(RuntimeError, match="OCR"):
        doc.extract_boxes(0, dpi=100)


def test_document_base_class_is_abstract():
    with pytest.raises(NotImplementedError):
        Document([]).page_count
