"""Unit tests for the inpainting stage."""
from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw

from ckb_translator.core.models import TextBox, rect_to_poly
from ckb_translator.inpaint import build_mask, inpaint_image


def _text_image() -> tuple[Image.Image, TextBox]:
    image = Image.new("RGB", (400, 200), (250, 248, 244))
    draw = ImageDraw.Draw(image)
    box = (40, 60, 300, 110)
    draw.rectangle(box, outline=(200, 200, 200))
    draw.text((45, 70), "Original English text here", fill=(10, 10, 10))
    # return the inner region actually containing glyphs as the mask box
    tb = TextBox(bbox=(40, 60, 260, 105), text="Original English text here",
                 mask_polys=[rect_to_poly((42, 62, 258, 103))], dpi=150)
    return image, tb


def test_build_mask_covers_text_boxes():
    image, tb = _text_image()
    mask = build_mask(image.size, [tb], dilate_px=2)
    assert mask.shape == (200, 400)
    assert mask[80, 100] == 255      # inside text
    assert mask[10, 10] == 0         # far corner untouched
    assert mask.sum() > 500


def test_inpaint_removes_text():
    image, tb = _text_image()
    result = inpaint_image(image, [tb], method="telea", radius=3, dilate_px=3)
    region = np.asarray(result.convert("L").crop((42, 62, 258, 103)))
    # every actual text pixel must be gone (nothing darker than 200)
    assert (region < 200).sum() == 0, "dark text pixels survived inpainting"
    # and the restored area stays close to the background tone
    assert region.mean() > 220, f"background not restored (mean={region.mean():.1f})"
    # the border drawn around the box survives
    border = np.asarray(result.convert("L").crop((38, 58, 302, 112)))
    assert border.min() < 220, "the surrounding graphics must survive inpainting"


def test_inpaint_ns_method():
    image, tb = _text_image()
    result = inpaint_image(image, [tb], method="ns", radius=3, dilate_px=3)
    region = np.asarray(result.convert("L").crop((42, 62, 258, 103)))
    assert (region < 200).sum() == 0
    assert region.mean() > 200


def test_inpaint_without_boxes_returns_original():
    image = Image.new("RGB", (50, 50), "white")
    result = inpaint_image(image, [], method="telea")
    assert list(result.getdata()) == list(image.getdata())


def test_inpaint_handles_boxes_without_mask_polys():
    image, tb = _text_image()
    tb.mask_polys = []
    result = inpaint_image(image, [tb], dilate_px=2)
    region = np.asarray(result.convert("L").crop((40, 60, 260, 105)))
    assert (region < 200).sum() == 0
