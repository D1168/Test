"""Unit tests for font classification and Kurdish font resolution."""
from __future__ import annotations

from pathlib import Path

import pytest

from ckb_translator.font_match import FontLibrary, classify_font


@pytest.mark.parametrize("font_name,kwargs,expected", [
    ("Times New Roman", {}, "serif"),
    ("Times-Bold", {}, "serif"),
    ("Times-Roman", {}, "serif"),
    ("Georgia", {}, "serif"),
    ("Garamond", {}, "serif"),
    ("Noto Serif", {}, "serif"),
    ("Arial", {}, "sans"),
    ("Helvetica", {}, "sans"),
    ("Helvetica-Bold", {}, "sans"),
    ("Verdana", {}, "sans"),
    ("Segoe UI", {}, "sans"),
    ("Noto Sans", {}, "sans"),
    ("Vazirmatn", {}, "sans"),
    ("Comic Sans MS", {}, "script"),
    ("Lucida Handwriting", {}, "script"),
    ("Brush Script", {}, "script"),
    ("Noto Kufi Arabic", {}, "kufi"),
    ("Courier New", {}, "mono"),
    ("Consolas", {}, "mono"),
    # PDF subset prefixes are stripped
    ("ABCDEF+TimesNewRomanPSMT", {}, "serif"),
    ("ABCDEF+ArialMT", {}, "sans"),
    # flags are used only when the name carries no hint
    ("UnknownFace", {"serifed": True}, "serif"),
    ("UnknownFace", {"serifed": False}, "sans"),
    ("UnknownFace", {"monospaced": True}, "mono"),
    ("UnknownFace", {}, "serif"),  # books default to serif
    # Arabic source font names
    ("Traditional Arabic", {}, "serif"),
    ("Diwani", {}, "script"),
    ("Sakkal Majalla", {"serifed": False}, "sans"),
])
def test_classify_font(font_name, kwargs, expected):
    assert classify_font(font_name, **kwargs) == expected


@pytest.fixture()
def library(tmp_path) -> FontLibrary:
    """A fake font directory — the matcher only needs files to exist."""
    for name in ("Amiri-Regular.ttf", "Amiri-Bold.ttf", "Amiri-Italic.ttf",
                 "Amiri-BoldItalic.ttf",
                 "Vazirmatn-Regular.ttf", "Vazirmatn-Bold.ttf",
                 "ScheherazadeNew-Regular.ttf", "NotoKufiArabic-Regular.ttf"):
        (tmp_path / name).write_bytes(b"fake")
    return FontLibrary(tmp_path,
                       preferred={"serif": ["Amiri", "Scheherazade New"],
                                  "sans": ["Vazirmatn", "Noto Kufi Arabic"],
                                  "script": ["Scheherazade New", "Amiri"],
                                  "kufi": ["Noto Kufi Arabic"],
                                  "mono": ["Vazirmatn"]},
                       default=["Amiri", "Vazirmatn"])


def test_scan_finds_families(library):
    fams = library.families()
    assert fams == ["amiri", "notokufiarabic", "scheherazadenew", "vazirmatn"]


def test_resolve_prefers_bold_face(library):
    choice = library.match(font_name="Times New Roman", bold=True, text="")
    assert choice.family == "Amiri"
    assert choice.path.name == "Amiri-Bold.ttf"
    assert choice.simulated_bold is False


def test_resolve_simulated_bold_when_no_bold_face(library):
    choice = library.match(font_name="Arial", bold=True, text="")
    # Vazirmatn has a Bold file here, so force a family without one:
    choice = library.match(font_name="Comic Sans MS", bold=True, text="")
    # script -> Scheherazade New (no bold installed) -> Amiri has bold
    assert choice.family in ("Scheherazade New", "Amiri")
    if choice.family == "Scheherazade New":
        assert choice.simulated_bold is True
        assert choice.path.name == "ScheherazadeNew-Regular.ttf"


def test_resolve_italic_prefers_italic_face(library):
    choice = library.match(font_name="Times New Roman", italic=True, text="")
    assert choice.path.name == "Amiri-Italic.ttf"


def test_resolve_falls_back_through_default_list(library):
    # category 'mono' -> preferred Vazirmatn is installed
    choice = library.match(font_name="Courier New", text="")
    assert choice.family == "Vazirmatn"


def test_resolve_when_nothing_installed(tmp_path):
    empty = FontLibrary(tmp_path / "nope", default=["Amiri"])
    choice = empty.match(font_name="Arial", bold=True, text="سلاو")
    assert choice.path is None
    assert choice.fallback is True
    assert choice.simulated_bold is True


def test_match_without_text_skips_coverage_check(library):
    choice = library.match(font_name="Arial", text="")
    assert choice.coverage == 1.0


def test_real_font_coverage(project_fonts_dir):
    """With the real downloaded fonts, Kurdish text must be fully covered."""
    if not list(Path(project_fonts_dir).glob("*.ttf")):
        pytest.skip("fonts not downloaded yet (run scripts/fetch_fonts.py)")
    from ckb_translator.core.config import FontsConfig
    fonts_cfg = FontsConfig()
    library = FontLibrary(project_fonts_dir, fonts_cfg.preferred, fonts_cfg.default)
    choice = library.match(font_name="Times New Roman",
                           text="ڕۆژی هەینی شوانێک مێڕەکانی بەرەو دۆڵەکە برد")
    assert choice.path is not None
    assert choice.coverage == 1.0
    assert choice.category == "serif"
    assert choice.family == "Amiri"


def test_real_font_coverage_picks_best_when_partial(project_fonts_dir):
    if not list(Path(project_fonts_dir).glob("*.ttf")):
        pytest.skip("fonts not downloaded yet")
    from ckb_translator.core.config import FontsConfig
    fonts_cfg = FontsConfig()
    library = FontLibrary(project_fonts_dir, fonts_cfg.preferred, fonts_cfg.default)
    # a char outside the Arabic block (Latin) lowers coverage but still resolves
    choice = library.match(font_name="Arial", text="hello سلاو")
    assert choice.path is not None
    assert 0.0 < choice.coverage < 1.0 or choice.coverage == 1.0
