"""Round-trip tests for the exporters (PDF / EPUB / DOCX)."""
from __future__ import annotations

from pathlib import Path

import fitz
import pytest
from PIL import Image


def test_export_pdf_pages_and_size(tmp_path):
    from ckb_translator.export import export_pdf
    pages = []
    for color in ((255, 0, 0), (0, 255, 0), (0, 0, 255)):
        img = Image.new("RGB", (1240, 1754), color)
        path = tmp_path / f"{color}.png"
        img.save(path)
        pages.append(path)
    out = export_pdf(pages, tmp_path / "out.pdf", dpi=150)
    assert out.is_file()
    with fitz.open(out) as doc:
        assert doc.page_count == 3
        # 1240 px at 150 dpi -> 595 pt (A4) ± rounding
        assert abs(doc[0].rect.width - 595.3) < 3
        assert abs(doc[0].rect.height - 842) < 4


def test_export_pdf_empty_raises(tmp_path):
    from ckb_translator.export import export_pdf
    with pytest.raises(ValueError):
        export_pdf([], tmp_path / "empty.pdf")


def test_build_epub_and_read_back(tmp_path):
    from ckb_translator.export import build_epub
    from ckb_translator.extract.reflow_doc import EpubDocument

    chapters = [
        ("Chapter One", [("Chapter One", True, 20.0),
                         ("First paragraph in Kurdish.", False, 11.0)]),
        ("Chapter Two", [("Chapter Two", True, 20.0),
                         ("Second paragraph here.", False, 11.0)]),
    ]
    out = build_epub("Test Book", chapters, tmp_path / "book.epub",
                     font_path=None)
    assert out.is_file()

    doc = EpubDocument(out)
    assert doc.title() == "Test Book"
    parsed = doc.chapters()
    assert len(parsed) == 2
    assert parsed[0].title == "Chapter One"
    texts = [b.text for b in parsed[0].blocks]
    assert "First paragraph in Kurdish." in texts
    assert parsed[0].blocks[0].kind == "heading"
    assert parsed[0].blocks[0].bold is True


def test_build_docx_and_read_back(tmp_path):
    from ckb_translator.export import build_docx
    from ckb_translator.extract.reflow_doc import DocxDocument

    chapters = [
        ("Chapter One", [("Chapter One", True, 18.0),
                         ("Body paragraph one.", False, 11.0),
                         ("Body paragraph two.", False, 11.0)]),
        ("Chapter Two", [("Chapter Two", True, 18.0),
                         ("Body paragraph three.", False, 11.0)]),
    ]
    out = build_docx("Test Book", chapters, tmp_path / "book.docx",
                     font_name="Amiri")
    assert out.is_file()

    doc = DocxDocument(out)
    parsed = doc.chapters()
    # Title becomes front-matter, then one chapter per Heading 1
    assert len(parsed) == 3
    assert parsed[0].blocks[0].text == "Test Book"
    assert parsed[0].blocks[0].kind == "heading"
    assert parsed[1].title == "Chapter One"
    assert "Body paragraph two." in [b.text for b in parsed[1].blocks]
    assert parsed[2].title == "Chapter Two"
    headings = [b for ch in parsed for b in ch.blocks if b.kind == "heading"]
    assert len(headings) == 3  # Title + two chapter headings (duplicates removed)


def test_docx_rtl_markup_present(tmp_path):
    """The generated DOCX must carry w:bidi / w:rtl / w:cs for proper RTL."""
    from ckb_translator.export import build_docx
    import zipfile

    out = build_docx("T", [("C", [("x", False, 11.0)])],
                     tmp_path / "rtl.docx", font_name="Amiri")
    with zipfile.ZipFile(out) as zf:
        xml = zf.read("word/document.xml").decode("utf-8")
    assert "w:bidi" in xml
    assert "w:rtl" in xml
    assert 'w:cs="Amiri"' in xml
