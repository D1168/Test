"""Shared fixtures: config, fonts, sample PDFs."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from ckb_translator.core.config import AppConfig, FontsConfig  # noqa: E402


def _first_font() -> Path | None:
    fonts_dir = PROJECT_ROOT / "fonts"
    for name in ("Amiri-Regular.ttf", "NotoNaskhArabic-Regular.ttf",
                 "Vazirmatn-Regular.ttf", "ScheherazadeNew-Regular.ttf"):
        candidate = fonts_dir / name
        if candidate.is_file():
            return candidate
    for fallback in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",):
        if Path(fallback).is_file():
            return Path(fallback)
    return None


ARABIC_FONT = _first_font()
requires_arabic_font = pytest.mark.skipif(
    ARABIC_FONT is None, reason="no Arabic-capable font available")


@pytest.fixture(scope="session")
def arabic_font() -> Path:
    assert ARABIC_FONT is not None, "no Arabic font available for tests"
    return ARABIC_FONT


@pytest.fixture()
def config(tmp_path) -> AppConfig:
    """Isolated config: temp dirs, mock engine, project fonts."""
    cfg = AppConfig()
    cfg.base_dir = tmp_path
    cfg.fonts.dir = str(PROJECT_ROOT / "fonts")
    cfg.translation.engine = "mock"
    cfg.cache.path = str(tmp_path / "cache.sqlite3")
    cfg.jobs.dir = str(tmp_path / "jobs")
    cfg.jobs.uploads_dir = str(tmp_path / "uploads")
    cfg.jobs.output_dir = str(tmp_path / "output")
    cfg.dpi = 72  # small + fast for tests
    cfg.inpaint.dilate_px = 1
    return cfg


@pytest.fixture(scope="session")
def project_fonts_dir() -> Path:
    return PROJECT_ROOT / "fonts"


@pytest.fixture()
def sample_pdf(tmp_path) -> Path:
    """One-page PDF with known content, generated in memory."""
    import fitz

    from ckb_translator.samplebook import make_sample_pdf
    path = tmp_path / "book.pdf"
    make_sample_pdf(path)
    assert path.is_file()
    return path


__all__ = ["PROJECT_ROOT", "ARABIC_FONT", "requires_arabic_font"]
