"""Unit tests for the translation cache and service (batching, dedupe, stats)."""
from __future__ import annotations

import pytest

from ckb_translator.translate.cache import TranslationCache, cache_key
from ckb_translator.translate.engines import MockTranslator, PassthroughTranslator
from ckb_translator.translate.service import TranslationService


@pytest.fixture()
def cache(tmp_path):
    c = TranslationCache(tmp_path / "cache.sqlite3")
    yield c
    c.close()


def test_cache_key_is_stable_and_stage_separated():
    k1 = cache_key("google", "en", "ckb", "hello")
    k2 = cache_key("google", "en", "ckb", "hello")
    k3 = cache_key("google", "en", "ckb", "hello", post_edit=True)
    k4 = cache_key("mock", "en", "ckb", "hello")
    assert k1 == k2
    assert k1 != k3 != k4


def test_cache_roundtrip(cache):
    keys = [cache_key("mock", "en", "ckb", t) for t in ("one", "two")]
    cache.put_many({keys[0]: ("mock", "en", "ckb", "one", "یەک"),
                    keys[1]: ("mock", "en", "ckb", "two", "دوو")})
    assert cache.get_many(keys) == {keys[0]: "یەک", keys[1]: "دوو"}
    assert cache.count() == 2


def test_cache_get_missing_returns_empty(cache):
    key = cache_key("mock", "en", "ckb", "nope")
    assert cache.get_many([key]) == {}


def test_cache_overwrites_on_put_again(cache):
    key = cache_key("mock", "en", "ckb", "one")
    cache.put_many({key: ("mock", "en", "ckb", "one", "first")})
    cache.put_many({key: ("mock", "en", "ckb", "one", "second")})
    assert cache.get_many([key]) == {key: "second"}


class CountingTranslator(PassthroughTranslator):
    def __init__(self):
        super().__init__()
        self.calls = 0

    def translate(self, texts):
        self.calls += 1
        return super().translate(texts)


def test_service_deduplicates_and_caches():
    engine = CountingTranslator()
    service = TranslationService(engine, cache=None, source_language="en",
                                 target_language="ckb")
    result = service.translate(["a", "b", "a", "a"])
    assert result == ["a", "b", "a", "a"]
    assert engine.calls == 1  # dedupe -> single call with unique texts


def test_service_uses_cache_between_runs(cache):
    engine = CountingTranslator()
    service = TranslationService(engine, cache=cache, source_language="en",
                                 target_language="ckb")
    service.translate(["hello", "world"])
    assert engine.calls == 1
    service.translate(["hello", "world"])   # fully cached
    assert engine.calls == 1
    service.translate(["hello", "new"])     # one new text
    assert engine.calls == 2
    stats = service.snapshot_stats()
    assert stats["cache_hits"] == 3
    assert stats["engine_texts"] == 3


def test_service_preserves_order_and_blanks():
    service = TranslationService(MockTranslator(), cache=None)
    out = service.translate(["", "The Little Book of Kurdistan", "  "])
    assert out[0] == ""
    assert out[1] == "کتێبی بچووکی کوردستان"
    assert out[2] == ""


def test_mock_translator_known_and_unknown():
    engine = MockTranslator()
    assert engine.translate(["A language is a map of the human heart."]) == \
        ["زمان نەخشەی دڵی مرۆڤایەتییە."]
    assert engine.translate(["42"]) == ["42"]
    unknown = engine.translate(["something not in the dictionary"])[0]
    assert "وەرگێڕدراوە" in unknown


def test_service_raises_on_engine_length_mismatch():
    class Broken(PassthroughTranslator):
        def translate(self, texts):
            return ["only one"]

    service = TranslationService(Broken(), cache=None)
    with pytest.raises(RuntimeError):
        service.translate(["a", "b"])
