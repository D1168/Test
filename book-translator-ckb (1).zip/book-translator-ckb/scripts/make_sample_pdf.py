#!/usr/bin/env python3
"""Generate the sample book (text PDF + scanned variant) under samples/."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from ckb_translator.samplebook import make_sample_pdf, make_scanned_pdf  # noqa: E402

target = ROOT / "samples" / "sample_book.pdf"
make_sample_pdf(target)
make_scanned_pdf(target, ROOT / "samples" / "sample_scanned.pdf", dpi=150)
print(f"wrote {target}")
print(f"wrote {ROOT / 'samples' / 'sample_scanned.pdf'}")
