#!/usr/bin/env python3
"""Download the Kurdish-capable font families used by the font matcher.

Families (all SIL Open Font License):
    Amiri, Noto Naskh Arabic, Vazirmatn, Noto Kufi Arabic, Scheherazade New

Run from the project root:  python scripts/fetch_fonts.py
Files land in ./fonts/ .  Already-present files are kept (idempotent).
"""
from __future__ import annotations

import io
import sys
import urllib.request
import zipfile
from pathlib import Path

FONTS_DIR = Path(__file__).resolve().parent.parent / "fonts"

UA = {"User-Agent": "Mozilla/5.0 (book-translator-ckb font fetcher)"}

# (family label, filename, direct-URL candidates)
DIRECT = [
    ("Noto Naskh Arabic", "NotoNaskhArabic-Regular.ttf", [
        "https://raw.githubusercontent.com/googlefonts/noto-fonts/main/hinted/ttf/NotoNaskhArabic/NotoNaskhArabic-Regular.ttf",
        "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoNaskhArabic/hinted/ttf/NotoNaskhArabic-Regular.ttf",
    ]),
    ("Noto Naskh Arabic", "NotoNaskhArabic-Bold.ttf", [
        "https://raw.githubusercontent.com/googlefonts/noto-fonts/main/hinted/ttf/NotoNaskhArabic/NotoNaskhArabic-Bold.ttf",
        "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoNaskhArabic/hinted/ttf/NotoNaskhArabic-Bold.ttf",
    ]),
    ("Noto Kufi Arabic", "NotoKufiArabic-Regular.ttf", [
        "https://raw.githubusercontent.com/googlefonts/noto-fonts/main/hinted/ttf/NotoKufiArabic/NotoKufiArabic-Regular.ttf",
        "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoKufiArabic/hinted/ttf/NotoKufiArabic-Regular.ttf",
    ]),
    ("Noto Kufi Arabic", "NotoKufiArabic-Bold.ttf", [
        "https://raw.githubusercontent.com/googlefonts/noto-fonts/main/hinted/ttf/NotoKufiArabic/NotoKufiArabic-Bold.ttf",
        "https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoKufiArabic/hinted/ttf/NotoKufiArabic-Bold.ttf",
    ]),
]

# (family label, zip URL candidates, member filename(s) wanted)
ZIPS = [
    ("Amiri", [
        "https://github.com/aliftype/amiri/releases/download/1.000/Amiri-1.000.zip",
    ], ["Amiri-Regular.ttf", "Amiri-Bold.ttf", "Amiri-Italic.ttf",
        "Amiri-BoldItalic.ttf"]),
    ("Scheherazade New", [
        "https://software.sil.org/downloads/r/scheherazade/ScheherazadeNew-5.200.zip",
        "https://software.sil.org/downloads/r/scheherazade/ScheherazadeNew-4.300.zip",
    ], ["ScheherazadeNew-Regular.ttf", "ScheherazadeNew-Bold.ttf"]),
    ("Vazirmatn", [
        "https://github.com/rastikerdar/vazirmatn/releases/download/v33.003/vazirmatn-v33.003.zip",
        "https://github.com/rastikerdar/vazirmatn/releases/download/v33.003/vazirmatn-v33.003.zip",
    ], ["Vazirmatn-Regular.ttf", "Vazirmatn-Bold.ttf"]),
]


def fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(request, timeout=120) as response:
        return response.read()


def main() -> int:
    FONTS_DIR.mkdir(parents=True, exist_ok=True)
    failures: list[str] = []

    for _family, filename, urls in DIRECT:
        target = FONTS_DIR / filename
        if target.is_file() and target.stat().st_size > 10_000:
            print(f"  kept      {filename}")
            continue
        for url in urls:
            try:
                data = fetch(url)
                if data[:4] not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
                    raise ValueError("not a font file")
                target.write_bytes(data)
                print(f"  fetched   {filename}  ({len(data) // 1024} KB)")
                break
            except Exception as exc:
                print(f"  miss      {url}  ({exc})")
        else:
            failures.append(filename)

    for family, urls, members in ZIPS:
        remaining = [m for m in members
                     if not (FONTS_DIR / m).is_file()
                     or (FONTS_DIR / m).stat().st_size < 10_000]
        if not remaining:
            print(f"  kept      {family} (complete)")
            continue
        for url in urls:
            try:
                archive = zipfile.ZipFile(io.BytesIO(fetch(url)))
                names = {Path(n).name: n for n in archive.namelist()}
                found_any = False
                for member in remaining:
                    if member in names:
                        (FONTS_DIR / member).write_bytes(archive.read(names[member]))
                        print(f"  fetched   {member}  (from {url.rsplit('/', 1)[-1]})")
                        found_any = True
                if found_any:
                    break
            except Exception as exc:
                print(f"  miss      {url}  ({exc})")
        else:
            failures.extend(remaining)

    print()
    if failures:
        print(f"FAILED to fetch: {', '.join(failures)}")
        print("The font matcher will fall back to whatever is installed.")
        return 1
    print(f"All fonts present in {FONTS_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
