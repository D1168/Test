"""Translation engines.

* :class:`GoogleTranslator` — Google Cloud Translation API v3, target ``ckb``
  (Central Kurdish / Sorani).  Multiple texts are sent per request (batching).
* :class:`FreeGoogleTranslator` — same Google MT via the public
  ``translate_a/single`` endpoint.  No key, no billing, no SDK — plain
  ``urllib``.  Unofficial, so it is throttled and retries with backoff.
* :class:`ClaudePostEditor` — optional fluency pass on machine output.
* :class:`MockTranslator` — offline dictionary used by the demo, the tests
  and anyone evaluating the pipeline without API credentials.
* :class:`PassthroughTranslator` — identity engine (debugging/tests).

The Google / Anthropic SDKs are imported lazily so the app runs without them.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Sequence

from ckb_translator.core.config import AppConfig, TranslationConfig, PostEditConfig

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Availability checks (used by the API to fail fast with a helpful message)
# --------------------------------------------------------------------------- #

def google_ready(cfg: TranslationConfig) -> tuple[bool, str]:
    if not cfg.google_credentials:
        return False, "translation.google_credentials is not set (path to service-account JSON)"
    if not Path(cfg.google_credentials).is_file():
        # never echo the path itself — it may contain account names
        return False, "google credentials file not found (check translation.google_credentials in config.yaml)"
    if not cfg.google_project_id and not _project_from_credentials(cfg.google_credentials):
        return False, "google_project_id missing and not present in the credentials file"
    return True, ""


def _project_from_credentials(cred_path: str) -> str:
    try:
        with open(cred_path, "r", encoding="utf-8") as fh:
            return json.load(fh).get("project_id", "")
    except Exception:
        return ""


def claude_ready(cfg: PostEditConfig) -> tuple[bool, str]:
    if not (cfg.api_key or os.environ.get("ANTHROPIC_API_KEY")):
        return False, "post_edit.api_key (or BT_CLAUDE_API_KEY) is not set"
    return True, ""


# --------------------------------------------------------------------------- #
# Engines
# --------------------------------------------------------------------------- #

class BaseTranslator:
    name = "base"

    def translate(self, texts: Sequence[str]) -> list[str]:
        raise NotImplementedError


class GoogleTranslator(BaseTranslator):
    """Google Cloud Translation API v3 — batches several texts per request."""
    name = "google"

    def __init__(self, cfg: TranslationConfig):
        self.cfg = cfg
        self._client = None

    @property
    def client(self):
        if self._client is None:
            if self.cfg.google_credentials:
                os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS",
                                      self.cfg.google_credentials)
            try:
                from google.cloud import translate_v3
            except ImportError as exc:
                raise RuntimeError(
                    "google-cloud-translate is not installed; "
                    "run: pip install google-cloud-translate") from exc
            ok, reason = google_ready(self.cfg)
            if not ok:
                raise RuntimeError(f"Google Translate is not configured: {reason}")
            self._client = translate_v3.TranslationServiceClient()
        return self._client

    def _project(self) -> str:
        return self.cfg.google_project_id or _project_from_credentials(
            self.cfg.google_credentials)

    def _chunks(self, texts: Sequence[str]) -> list[list[str]]:
        chunks: list[list[str]] = []
        current: list[str] = []
        chars = 0
        for text in texts:
            t = text or ""
            if current and (len(current) >= self.cfg.batch_size
                            or chars + len(t) > self.cfg.batch_chars):
                chunks.append(current)
                current, chars = [], 0
            current.append(t)
            chars += len(t)
        if current:
            chunks.append(current)
        return chunks

    def translate(self, texts: Sequence[str]) -> list[str]:
        client = self.client
        parent = f"projects/{self._project()}/locations/global"
        results: list[str] = []
        for chunk in self._chunks(texts):
            request = {
                "parent": parent,
                "contents": list(chunk),
                "mime_type": "text/plain",
                "target_language_code": self.cfg.target_language,
            }
            if self.cfg.source_language and self.cfg.source_language != "auto":
                request["source_language_code"] = self.cfg.source_language
            try:
                response = client.translate_text(request=request)
                results.extend(t.translated_text for t in response.translations)
            except Exception as exc:
                raise RuntimeError(f"Google Translate request failed: {exc}") from exc
        if len(results) != len(texts):
            raise RuntimeError(
                f"Google Translate returned {len(results)} results for {len(texts)} texts")
        return results


class FreeGoogleTranslator(BaseTranslator):
    """Google MT via the public endpoint — free, no key, no billing.

    Uses the same consumer endpoint that translate.google.com uses
    (``client=gtx``), which supports Central Kurdish (``ckb``).  Nothing to
    install (plain ``urllib``) and nothing to configure.

    Because it is unofficial we keep a polite delay between requests and
    retry 429/5xx responses with exponential backoff.  The translation
    cache means repeated lines across pages cost nothing.  For heavy
    recurring workloads prefer the official :class:`GoogleTranslator`.
    """

    name = "gfree"
    ENDPOINT = "https://translate.googleapis.com/translate_a/single"
    RETRIES = 5
    RETRY_CODES = frozenset({403, 429, 500, 502, 503})

    def __init__(self, cfg: TranslationConfig, delay: float | None = None):
        self.cfg = cfg
        env = os.environ.get("BT_FREE_DELAY")
        if env is not None:
            self.delay = max(0.0, float(env))
        else:
            self.delay = float(cfg.free_delay) if delay is None else float(delay)

    # ---- one HTTP request ------------------------------------------- #
    def _request(self, text: str) -> str:
        params = urllib.parse.urlencode({
            "client": "gtx",
            "sl": self.cfg.source_language or "auto",
            "tl": self.cfg.target_language,
            "dt": "t",
            "q": text,
        })
        url = f"{self.ENDPOINT}?{params}"
        last_err: Exception | None = None
        for attempt in range(self.RETRIES):
            try:
                req = urllib.request.Request(url, headers={
                    "User-Agent": "Mozilla/5.0 (book-translator-ckb)",
                })
                with urllib.request.urlopen(req, timeout=20) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                segments = data[0] or []
                return "".join(seg[0] or "" for seg in segments
                               if seg and seg[0])
            except urllib.error.HTTPError as exc:
                last_err = exc
                if exc.code in self.RETRY_CODES and attempt < self.RETRIES - 1:
                    # rate limits need longer waits than transient hiccups
                    base = max(self.delay, 1.0) if exc.code in (403, 429) else self.delay
                    time.sleep(base * (2 ** attempt))
                    continue
                break
            except (urllib.error.URLError, TimeoutError, OSError,
                    ValueError, IndexError, KeyError) as exc:
                # ValueError covers json.JSONDecodeError (a subclass)
                last_err = exc
                if attempt < self.RETRIES - 1:
                    time.sleep(self.delay)
                    continue
                break
        raise RuntimeError(
            f"free Google request failed after {self.RETRIES} tries: {last_err}")

    def translate(self, texts: Sequence[str]) -> list[str]:
        out: list[str] = []
        for i, text in enumerate(texts):
            stripped = (text or "").strip()
            if not stripped:
                out.append(text or "")
                continue
            out.append(self._request(stripped))
            if self.delay and i < len(texts) - 1:
                time.sleep(self.delay)
        return out


class PassthroughTranslator(BaseTranslator):
    """Returns the input unchanged — for tests and dry runs."""
    name = "passthrough"

    def translate(self, texts: Sequence[str]) -> list[str]:
        return list(texts)


def _norm_key(text: str) -> str:
    """Normalised lookup key for the mock dictionary."""
    t = " ".join((text or "").split()).lower()
    return t.strip(" .!?:;،؛«»\u200c")


# A small English -> Kurdish Sorani dictionary so that the mock engine,
# the demo and the test-suite produce real RTL Kurdish output offline.
_MOCK_RAW: dict[str, str] = {
    "The Little Book of Kurdistan": "کتێبی بچووکی کوردستان",
    "A sample book for the translation pipeline": "کتێبێکی نموونە بۆ ئەم ئامرازەی وەرگێڕان",
    "Sample Author": "نووسەری نموونە",
    "First Edition": "چاپی یەکەم",
    "Chapter One — The Mountains": "بەشی یەکەم — چیاکان",
    "The mountains stand high above the valley. Every spring the snow melts and the "
    "rivers run toward the sea. The shepherds move with their flocks from village to "
    "village.":
        "چیاکان بە بەرزی لە سەر دۆڵەکە ڕادەوەستن. هەموو بەهارێک بەفرەکە دەتوێتەوە و "
        "ڕووبارەکان بەرەو دەریا دەڕژێن. شوانەکان لەگەڵ مێڕەکانیان لە گوندێکەوە بۆ "
        "گوندێکی تر دەجوڵێن.",
    "In the evening the old men gather in the teahouse. They tell stories about the "
    "past and about the heroes of the land. The tea is hot and the nights are long.":
        "لە ئێوارەدا پیاوانی بەتەم لە چایخانە کۆدەبنەوە. چیرۆکی ڕابردوو و پاڵەوانانی "
        "ئەم وڵاتە دەگێڕنەوە. چا گەرمە و شەوەکان درێژن.",
    "The valley is green in spring and golden in autumn. Small gardens surround "
    "every house, and the sound of water follows the paths.":
        "دۆڵەکە لە بەهاردا سەوزە و لە پاییزدا زێڕینە. باخچەی بچووک هەر ماڵێک دەورە "
        "دەگرن و دەنگی ئاو بە درێژایی ڕێگاکان دەڕوات.",
    "Language is the road map of a culture. It tells you where its people come from "
    "and where they are going.":
        "زمان نەخشەی ڕێگای کەلتوورێکە. بەتۆ دەڵێت خەڵکەکەی لە کوێوە هاتوون و بۆ "
        "کوێ دەڕۆن.",
    "A language is a map of the human heart.": "زمان نەخشەی دڵی مرۆڤایەتییە.",
    "This page was set with mixed serif and sans typefaces.":
        "ئەم لاپەڕەیە بە فۆنتی سێریف و سانس ڕێکخراوە.",
}
MOCK_DICTIONARY: dict[str, str] = {_norm_key(k): v for k, v in _MOCK_RAW.items()}

_MOCK_FALLBACK = "ئەم دەقە وەرگێڕدراوە بۆ کوردیی ناوەندی."


class MockTranslator(BaseTranslator):
    """Offline dictionary engine — no network, deterministic, for demo/tests."""
    name = "mock"

    def __init__(self, dictionary: dict[str, str] | None = None,
                 fallback: str = _MOCK_FALLBACK):
        self.dictionary = dictionary if dictionary is not None else MOCK_DICTIONARY
        self.fallback = fallback

    def translate(self, texts: Sequence[str]) -> list[str]:
        out: list[str] = []
        for text in texts:
            key = _norm_key(text)
            if key in self.dictionary:
                out.append(self.dictionary[key])
            elif (text or "").strip().isdigit():
                out.append(text.strip())  # page numbers etc. pass through
            else:
                out.append(self.fallback)
        return out


# --------------------------------------------------------------------------- #
# Claude post-editing
# --------------------------------------------------------------------------- #

class ClaudePostEditor:
    """Optional second pass: polish machine translations for fluency."""

    def __init__(self, cfg: PostEditConfig):
        self.cfg = cfg
        self._client = None

    @property
    def client(self):
        if self._client is None:
            try:
                import anthropic
            except ImportError as exc:
                raise RuntimeError(
                    "anthropic is not installed; run: pip install anthropic") from exc
            ok, reason = claude_ready(self.cfg)
            if not ok:
                raise RuntimeError(f"Claude post-edit is not configured: {reason}")
            self._client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY / cfg
        return self._client

    _SYSTEM = (
        "You are a professional editor of Central Kurdish (Sorani, language code "
        "ckb), written in the Arabic script. You receive machine translations "
        "together with their English source segments. Fix grammar, word choice, "
        "spelling and naturalness. Preserve the meaning and approximate length. "
        "Never merge or drop segments. Reply with ONLY the JSON array requested.")

    def polish(self, sources: Sequence[str], translations: Sequence[str]) -> list[str]:
        if len(sources) != len(translations):
            raise ValueError("sources/translations length mismatch")
        results = list(translations)
        size = max(1, int(self.cfg.batch_size))
        for start in range(0, len(sources), size):
            batch_src = sources[start:start + size]
            batch_mt = translations[start:start + size]
            payload = [{"id": i, "source": s, "translation": t}
                       for i, (s, t) in enumerate(zip(batch_src, batch_mt))]
            prompt = (
                f"Improve the fluency of these {len(payload)} Kurdish Sorani "
                f"machine translations. Return ONLY a JSON array of objects "
                f'like {{"id": 0, "translation": "…"}} with one object per input '
                f"id, same order, no commentary:\n\n"
                + json.dumps(payload, ensure_ascii=False, indent=1))
            try:
                response = self.client.messages.create(
                    model=self.cfg.model,
                    max_tokens=1024 + 256 * len(payload),
                    system=self._SYSTEM,
                    messages=[{"role": "user", "content": prompt}])
                text = "".join(block.text for block in response.content
                               if getattr(block, "text", None))
                parsed = self._parse(text)
                if parsed is not None:
                    for item in parsed:
                        idx = int(item.get("id", -1))
                        if 0 <= idx < len(batch_src) and str(item.get("translation", "")).strip():
                            results[start + idx] = str(item["translation"]).strip()
            except Exception as exc:
                logger.warning("Claude post-edit failed (keeping MT output): %s", exc)
        return results

    @staticmethod
    def _parse(text: str) -> list[dict] | None:
        """Lenient JSON extraction (handles code fences / stray prose)."""
        text = text.strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S)
        try:
            data = json.loads(text)
            return data if isinstance(data, list) else None
        except json.JSONDecodeError:
            pass
        match = re.search(r"\[.*\]", text, flags=re.S)
        if match:
            try:
                data = json.loads(match.group(0))
                return data if isinstance(data, list) else None
            except json.JSONDecodeError:
                return None
        return None


# --------------------------------------------------------------------------- #
# Factory
# --------------------------------------------------------------------------- #

def build_engine(cfg: AppConfig, options: dict) -> BaseTranslator:
    engine = options.get("engine", cfg.translation.engine)
    if engine == "google":
        return GoogleTranslator(cfg.translation)
    if engine == "gfree":
        return FreeGoogleTranslator(cfg.translation)
    if engine == "mock":
        return MockTranslator()
    if engine == "passthrough":
        return PassthroughTranslator()
    raise ValueError(f"unknown engine: {engine!r}")


def build_post_editor(cfg: AppConfig, options: dict) -> ClaudePostEditor | None:
    if not options.get("post_edit"):
        return None
    ok, reason = claude_ready(cfg.post_edit)
    if not ok:
        raise ValueError(f"post_edit requested but unavailable: {reason}")
    return ClaudePostEditor(cfg.post_edit)
