"""Image files (one image = one page) as a fixed-layout document."""
from __future__ import annotations

from pathlib import Path

from PIL import Image

from ckb_translator.core.models import Document, TextBox


class ImageListDocument(Document):
    """A book supplied as page images (scans, photos) — OCR per page."""
    kind = "images"

    def __init__(self, paths: list[str | Path], ocr_provider=None):
        super().__init__(sorted(Path(p) for p in paths))
        self.ocr = ocr_provider

    @property
    def page_count(self) -> int:
        return len(self.paths)

    def render_page(self, index: int, dpi: int = 300) -> Image.Image:
        image = Image.open(self.paths[index])
        return image.convert("RGB")

    def extract_boxes(self, index: int, dpi: int = 300) -> list[TextBox]:
        if self.ocr is None:
            raise RuntimeError(
                "image input requires an OCR provider — install PaddleOCR or "
                "tesseract (see README 'OCR extras')")
        image = self.render_page(index)
        boxes = self.ocr.get_boxes(image)
        for box in boxes:
            box.source = "ocr"
        return boxes
