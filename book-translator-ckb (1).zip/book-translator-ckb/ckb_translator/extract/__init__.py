"""Input dispatch: open any supported document type."""

from __future__ import annotations

import logging
from pathlib import Path

from ckb_translator.core.models import Document
from ckb_translator.extract.images_doc import ImageListDocument
from ckb_translator.extract.pdf_doc import PdfDocument
from ckb_translator.extract.reflow_doc import DocxDocument, EpubDocument, ReflowDocument

logger = logging.getLogger(__name__)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
FIXED_EXTS = {".pdf"} | IMAGE_EXTS
REFLOW_EXTS = {".epub", ".docx"}
SUPPORTED_EXTS = FIXED_EXTS | REFLOW_EXTS


def classify_input(names: list[str]) -> str:
    """Determine the input type from file extensions."""
    exts = [Path(n).suffix.lower() for n in names]
    if any(e not in SUPPORTED_EXTS for e in exts):
        bad = next(n for n, e in zip(names, exts) if e not in SUPPORTED_EXTS)
        raise ValueError(f"unsupported input file: {bad}")
    if all(e in IMAGE_EXTS for e in exts):
        return "images"
    if len(exts) == 1 and exts[0] == ".pdf":
        return "pdf"
    if len(exts) == 1 and exts[0] == ".epub":
        return "epub"
    if len(exts) == 1 and exts[0] == ".docx":
        return "docx"
    raise ValueError("mixed inputs are only supported between page images "
                     "(PNG/JPG); PDF/EPUB/DOCX must be a single file")


def open_document(paths: list[str], input_type: str, ocr_provider=None):
    """Open a document of any supported type."""
    if input_type == "pdf":
        return PdfDocument(paths[0], ocr_provider)
    if input_type == "images":
        return ImageListDocument(paths, ocr_provider)
    if input_type == "epub":
        return EpubDocument(paths[0])
    if input_type == "docx":
        return DocxDocument(paths[0])
    raise ValueError(f"unknown input_type: {input_type!r}")


def peek_page_count(paths: list[str], input_type: str) -> int:
    """Fast page/chapter count for progress display at job creation."""
    if input_type == "pdf":
        import fitz
        with fitz.open(paths[0]) as doc:
            return doc.page_count
    if input_type == "images":
        return len(paths)
    if input_type == "epub":
        return EpubDocument(paths[0]).page_count
    if input_type == "docx":
        return DocxDocument(paths[0]).page_count
    raise ValueError(f"unknown input_type: {input_type!r}")
