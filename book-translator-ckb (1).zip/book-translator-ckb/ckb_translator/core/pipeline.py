"""The per-book translation pipeline.

Fixed-layout inputs (PDF, page images) run the full six-stage pipeline per
page, each page fully independent:

    render(300 dpi) -> extract blocks (text layer or OCR)
    -> translate (cache -> engine batch -> optional Claude post-edit)
    -> inpaint original text away -> font match -> RTL render into bboxes
    -> save page image

Reflowable inputs (EPUB, DOCX) translate chapter blocks and re-typeset the
Kurdish text into a fresh PDF / EPUB / DOCX.

Every page/chapter status is persisted to the job state file after it
finishes, which is what makes resume-after-failure work: re-running a job
skips ``done`` pages, retries ``failed`` ones, and cached translations make
retries cheap.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from PIL import Image

from ckb_translator.core.config import AppConfig, resolve_path
from ckb_translator.core.models import JobState, PageEntry
from ckb_translator.export import build_docx, build_epub, export_pdf
from ckb_translator.extract import open_document
from ckb_translator.font_match import FontLibrary
from ckb_translator.inpaint import inpaint_image
from ckb_translator.render import rtl
from ckb_translator.translate import (TranslationCache, TranslationService,
                           build_engine, build_post_editor)

logger = logging.getLogger(__name__)

A4_PT = (595.0, 842.0)


class JobCancelled(Exception):
    pass


class BookJob:
    """Orchestrates one book translation from a persistent JobState."""

    def __init__(self, state: JobState, config: AppConfig,
                 cancel_event: threading.Event | None = None):
        self.state = state
        self.config = config
        opts = state.options
        self.opts = opts
        self.dpi = int(opts.get("dpi", config.dpi))
        self.alignment_mode = opts.get("alignment", config.render.alignment)
        self.min_font_size = int(opts.get("min_font_size", config.render.min_font_size))
        self.line_spacing = float(config.render.line_spacing)
        self.padding = int(config.render.padding_px)
        self.eastern_numerals = bool(opts.get("eastern_numerals",
                                              config.render.eastern_numerals))
        self.simulate_bold = bool(config.render.simulate_bold)

        # services (built once per job)
        cache = (TranslationCache(resolve_path(config, config.cache.path))
                 if config.cache.enabled else None)
        self.translator = TranslationService(
            engine=build_engine(config, opts),
            cache=cache,
            post_editor=build_post_editor(config, opts),
            source_language=opts.get("source_language", "auto"),
            target_language=opts.get("target_language", "ckb"))
        self.library = FontLibrary(resolve_path(config, config.fonts.dir),
                                   config.fonts.preferred, config.fonts.default)

        # OCR provider is optional; built lazily-erroring at first scan page
        from ckb_translator.extract.ocr import build_ocr_provider
        self.ocr = build_ocr_provider(config.ocr, opts.get("ocr_provider"))

        self.cancel_event = cancel_event or threading.Event()
        self.progress_hook = None            # callable(index, status) for CLI/tqdm
        self.persist_hook = None             # callable() -> saves state
        self._stat_lock = threading.Lock()
        self._job_stats = {"ocr_pages": 0, "fallback_fonts": 0}

        job_dir = resolve_path(config, config.jobs.dir) / state.id
        self.job_dir = job_dir
        self.pages_dir = job_dir / "pages"
        self.pages_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ #
    # helpers
    # ------------------------------------------------------------------ #

    def _check_cancel(self) -> None:
        if self.cancel_event.is_set():
            raise JobCancelled()

    def _persist(self) -> None:
        self.state.stats = {**self.translator.snapshot_stats(), **self._job_stats}
        self.state.touch()
        if self.persist_hook is not None:
            try:
                self.persist_hook()
            except Exception as exc:
                logger.warning("state persist failed: %s", exc)

    def _page_path(self, index: int) -> Path:
        return self.pages_dir / f"page_{index:04d}.png"

    def _notify(self, index: int, status: str) -> None:
        if self.progress_hook is not None:
            try:
                self.progress_hook(index, status)
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    # entry point
    # ------------------------------------------------------------------ #

    def run(self) -> None:
        self.state.status = "running"
        self.state.error = None
        self._persist()
        try:
            if self.state.input_type in ("epub", "docx"):
                self._run_reflowable()
            else:
                self._run_fixed_layout()
        except JobCancelled:
            self.state.status = "cancelled"
        except Exception as exc:
            logger.exception("job %s failed", self.state.id)
            self.state.status = "failed"
            self.state.error = str(exc)
        finally:
            self._persist()

    # ------------------------------------------------------------------ #
    # fixed-layout path (PDF / images)
    # ------------------------------------------------------------------ #

    def _run_fixed_layout(self) -> None:
        doc = open_document(self.state.input_paths, self.state.input_type, self.ocr)
        try:
            total = doc.page_count
            self._ensure_pages(total)

            todo = [p.index for p in self.state.pages if p.status != "done"]
            workers = max(1, min(int(self.opts.get("page_workers", 1)), len(todo) or 1))
            logger.info("job %s: %d pages (%d todo, %d workers)",
                        self.state.id, total, len(todo), workers)

            with ThreadPoolExecutor(max_workers=workers,
                                    thread_name_prefix=f"page-{self.state.id}") as pool:
                futures = {pool.submit(self._process_page, doc, i): i for i in todo}
                try:
                    for future in as_completed(futures):
                        index = futures[future]
                        try:
                            future.result()
                            self.state.pages[index].status = "done"
                            self.state.pages[index].error = None
                        except JobCancelled:
                            break
                        except Exception as exc:
                            logger.exception("page %d failed", index)
                            self.state.pages[index].status = "failed"
                            self.state.pages[index].error = str(exc)[:500]
                        self._persist()
                        self._notify(index, self.state.pages[index].status)
                        if self.cancel_event.is_set():
                            break
                finally:
                    for future in futures:
                        future.cancel()

            if self.cancel_event.is_set():
                self.state.status = "cancelled"
                return

            if self.config.jobs.on_error == "abort" and \
                    any(p.status == "failed" for p in self.state.pages):
                self.state.status = "failed"
                self.state.error = "a page failed and on_error=abort"
                return
            self._finalize_fixed(doc)
        finally:
            doc.close()

    def _ensure_pages(self, total: int) -> None:
        """Create missing PageEntries; keep existing statuses (resume)."""
        known = {p.index for p in self.state.pages}
        for index in range(total):
            if index not in known:
                self.state.pages.append(PageEntry(index=index))
        self.state.pages.sort(key=lambda p: p.index)

    def _process_page(self, doc, index: int) -> Path:
        """Process one page independently; returns the rendered image path."""
        self._check_cancel()
        t0 = time.time()
        image = doc.render_page(index, self.dpi)
        boxes = doc.extract_boxes(index, self.dpi)
        if boxes and boxes[0].source == "ocr":
            with self._stat_lock:
                self._job_stats["ocr_pages"] += 1

        pairs = [(box, " ".join(box.text.split())) for box in boxes
                 if box.text and box.text.strip()]

        if not pairs:
            final = image  # page without text (illustration) passes through
        else:
            translations = self.translator.translate([p[1] for p in pairs])
            clean = inpaint_image(
                image, boxes,
                method=self.opts.get("inpaint_method", self.config.inpaint.method),
                radius=self.config.inpaint.radius,
                dilate_px=self.config.inpaint.dilate_px)
            for (box, _source_text), translated in zip(pairs, translations):
                if not (translated or "").strip():
                    continue
                self._render_block(clean, box, translated)
            final = clean

        out_path = self._page_path(index)
        final.save(out_path)
        logger.debug("page %d done in %.1fs", index, time.time() - t0)
        return out_path

    def _render_block(self, image: Image.Image, box, translated: str) -> None:
        choice = self.library.match(
            font_name=box.font_name, bold=box.bold, italic=box.italic,
            serifed=box.serifed, monospaced=box.monospaced, text=translated)
        if choice.fallback:
            with self._stat_lock:
                self._job_stats["fallback_fonts"] += 1
        rtl.render_box(
            image, box, translated,
            font_path=choice.path,
            alignment_mode=self.alignment_mode,
            min_size=self.min_font_size,
            line_spacing=self.line_spacing,
            padding=self.padding,
            eastern_numerals=self.eastern_numerals,
            simulate_bold=choice.simulated_bold and self.simulate_bold)

    def _finalize_fixed(self, doc) -> None:
        failed = [p for p in self.state.pages if p.status == "failed"]
        # Keep failed pages in the output as the ORIGINAL (untranslated)
        # page so the exported book stays complete; they can be retried later.
        for entry in failed:
            path = self._page_path(entry.index)
            if not path.is_file():
                doc.render_page(entry.index, self.dpi).save(path)

        page_paths = [self._page_path(i) for i in range(len(self.state.pages))]
        missing = [p for p in page_paths if not p.is_file()]
        if missing:
            self.state.status = "failed"
            self.state.error = f"{len(missing)} pages could not be rendered"
            return

        stem = Path(self.state.input_paths[0]).stem
        out_path = (resolve_path(self.config, self.config.jobs.output_dir)
                    / self.state.id / f"{stem}_ckb.pdf")
        export_pdf(page_paths, out_path, dpi=self.dpi,
                   image_format=self.opts.get("image_format",
                                              self.config.export.image_format),
                   jpeg_quality=self.config.export.jpeg_quality)
        self.state.output = str(out_path)
        self.state.status = "completed_with_errors" if failed else "completed"

    # ------------------------------------------------------------------ #
    # reflowable path (EPUB / DOCX)
    # ------------------------------------------------------------------ #

    def _run_reflowable(self) -> None:
        doc = open_document(self.state.input_paths, self.state.input_type, None)
        chapters = doc.chapters()
        self._ensure_pages(len(chapters))

        output_format = self.opts.get("output_format", "auto")
        if output_format == "auto":
            output_format = self.state.input_type  # epub -> epub, docx -> docx

        translated_chapters: list[tuple] = []
        for index, chapter in enumerate(chapters):
            self._check_cancel()
            texts = [" ".join(b.text.split()) for b in chapter.blocks]
            translations = self.translator.translate(texts)
            translated_chapters.append((chapter, translations))
            self.state.pages[index].status = "done"
            self.state.pages[index].error = None
            self._persist()
            self._notify(index, "done")

        stem = Path(self.state.input_paths[0]).stem
        out_dir = (resolve_path(self.config, self.config.jobs.output_dir)
                   / self.state.id)
        out_dir.mkdir(parents=True, exist_ok=True)

        if output_format == "epub":
            body_font = self.library.body_font()
            out = out_dir / f"{stem}_ckb.epub"
            build_epub(doc.title(),
                       [(ch.title, [(t, b.kind == "heading", b.size_pt)
                                    for b, t in zip(ch.blocks, trs)])
                        for ch, trs in translated_chapters],
                       out, font_path=body_font.path)
            self.state.output = str(out)
        elif output_format == "docx":
            out = out_dir / f"{stem}_ckb.docx"
            body_font = self.library.body_font()
            family = body_font.family if body_font.path else "Amiri"
            build_docx(doc.title(),
                       [(ch.title, [(t, b.kind == "heading", b.size_pt)
                                    for b, t in zip(ch.blocks, trs)])
                        for ch, trs in translated_chapters],
                       out, font_name=family)
            self.state.output = str(out)
        else:
            page_paths = self._typeset_pdf(translated_chapters)
            out = out_dir / f"{stem}_ckb.pdf"
            export_pdf(page_paths, out, dpi=self.dpi,
                       image_format=self.opts.get("image_format",
                                                  self.config.export.image_format))
            self.state.output = str(out)
        self.state.status = "completed"

    def _typeset_pdf(self, translated_chapters: list[tuple]) -> list[Path]:
        """Flow translated blocks onto fresh A4 pages (RTL, right-aligned)."""
        scale = self.dpi / 72.0
        page_w, page_h = round(A4_PT[0] * scale), round(A4_PT[1] * scale)
        margin = round(56 * scale)
        content_w = page_w - 2 * margin
        para_gap = round(10 * scale)

        images: list[Image.Image] = []
        current = Image.new("RGB", (page_w, page_h), "white")
        y = margin

        def new_page() -> None:
            nonlocal current, y
            images.append(current)
            current = Image.new("RGB", (page_w, page_h), "white")
            y = margin

        for chapter, translations in translated_chapters:
            if images or y > margin:
                new_page()
            for block, text in zip(chapter.blocks, translations):
                self._check_cancel()
                if not (text or "").strip():
                    continue
                choice = self.library.match(
                    font_name=block.font_name, bold=block.bold,
                    italic=block.italic, text=text)
                start_px = max(8, round(block.size_pt * scale))
                size, lines, step, _overflow = rtl.fit_text(
                    text, choice.path, content_w, page_h, start_px,
                    min_size=self.min_font_size,
                    line_spacing=self.line_spacing, bold=block.bold)
                needed = step * len(lines) + self.padding * 2
                if y + needed > page_h - margin:
                    new_page()
                bbox = (margin, y, page_w - margin, y + needed)
                rtl.draw_block(
                    current, bbox, text,
                    font_path=choice.path, color=block.color,
                    bold=block.bold, italic=block.italic,
                    simulate_bold=choice.simulated_bold and self.simulate_bold,
                    alignment="left", alignment_mode=self.alignment_mode,
                    source_text=block.text, start_size_px=start_px,
                    min_size=self.min_font_size,
                    line_spacing=self.line_spacing, padding=self.padding,
                    eastern_numerals=self.eastern_numerals)
                y += needed + para_gap

        images.append(current)
        paths: list[Path] = []
        for i, img in enumerate(images):
            path = self._page_path(i)
            img.save(path)
            paths.append(path)
        return paths
