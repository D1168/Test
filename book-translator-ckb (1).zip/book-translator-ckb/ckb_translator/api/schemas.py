"""Pydantic request schemas for the REST API."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class JobOptionsAPI(BaseModel):
    """Per-job overrides — anything omitted falls back to config.yaml."""
    engine: Literal["google", "gfree", "mock", "passthrough"] | None = None
    dpi: int | None = Field(default=None, ge=50, le=600)
    post_edit: bool | None = None
    output_format: Literal["auto", "pdf", "epub", "docx"] | None = None
    alignment: Literal["auto", "mirror", "preserve", "right"] | None = None
    page_workers: int | None = Field(default=None, ge=1, le=8)
    ocr_provider: Literal["auto", "paddle", "tesseract", "none"] | None = None
    inpaint_method: Literal["telea", "ns", "lama"] | None = None
    min_font_size: int | None = Field(default=None, ge=5, le=30)
    eastern_numerals: bool | None = None
    image_format: Literal["png", "jpeg"] | None = None
    source_language: str | None = None
    target_language: str | None = None


class JobCreateAPI(BaseModel):
    uploads: list[str] = Field(min_length=1)
    options: JobOptionsAPI = Field(default_factory=JobOptionsAPI)
