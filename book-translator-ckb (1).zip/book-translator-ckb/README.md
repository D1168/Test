# book-translator-ckb

Translate books into **Kurdish Sorani (`ckb`)** — page by page, preserving the
original layout: text blocks are detected with their bounding boxes, font size,
colour and weight; the original text is inpainted away; and the Kurdish
translation is rendered **right-to-left** into the same boxes with a matched
Kurdish-capable font. FastAPI backend + web UI + CLI.

```
PDF / EPUB / DOCX / images
        │
        ▼
┌─ 1. RENDER ──────── page → 300 DPI image (PyMuPDF)
├─ 2. EXTRACT ─────── text layer: blocks → lines → spans (bbox, size, colour,
│                     bold/italic/serif flags)  … or PaddleOCR / tesseract
├─ 3. TRANSLATE ───── Google Cloud Translation API (target "ckb"), batched;
│                     optional Claude post-edit pass; SQLite cache
├─ 4. INPAINT ─────── OpenCV Telea/NS (or LaMa) removes the original text
├─ 5. FONT MATCH ──── serif/sans/kufi/script → Amiri · Noto Naskh Arabic ·
│                     Vazirmatn · Noto Kufi Arabic · Scheherazade New
│                     (glyph-coverage aware, bold/italic aware)
├─ 6. RTL RENDER ─── HarfBuzz/Raqm (fallback: arabic-reshaper + python-bidi),
│                     matching size / colour / alignment, auto-shrink to fit
└─ 7. EXPORT ─────── pages → PDF (img2pdf) · EPUB/DOCX for reflowable input
```

Every page is an independent unit with its own persisted status
(`data/jobs/<job>.json`) — that is what powers the **progress bar**, the
**resume-after-failure** and the **retry** buttons.

---

## Quickstart

```bash
# 1) Python 3.10+ and a virtualenv
python3 -m venv .venv && source .venv/bin/activate

# 2) dependencies
pip install -r requirements.txt

# 3) Kurdish fonts (Amiri, Noto Naskh, Noto Kufi, Scheherazade, Vazirmatn)
python scripts/fetch_fonts.py

# 4) offline demo — no API keys needed (mock translation engine)
python -m ckb_translator.cli demo

# 5) web app  →  http://127.0.0.1:8000
python -m ckb_translator.cli serve        # or: python run.py
```

The demo writes `samples/sample_book_kurdish.pdf` (and a scanned variant
exercising the OCR path). Inspect it next to `samples/sample_book.pdf` to see
inpainting + RTL rendering at work.

## Configuration

Copy `config.example.yaml` → `config.yaml` (a working mock-engine copy ships
with this repo) and edit:

```yaml
translation:
  engine: google                  # mock | passthrough for offline runs
  target_language: ckb
  google_credentials: /path/to/service-account.json
  google_project_id: my-project   # inferred from the JSON if omitted

post_edit:
  enabled: true                   # optional Claude fluency pass
  api_key: sk-ant-...
```

Environment overrides: `BT_ENGINE`, `BT_GOOGLE_CREDENTIALS`,
`BT_GOOGLE_PROJECT`, `BT_CLAUDE_API_KEY`, `BT_CLAUDE_MODEL`, `BT_DPI`,
`BT_FONTS_DIR`, `BT_TARGET_LANG`, `BT_CONFIG`. Keys are never logged or
exposed by the API.

**Google Cloud Translation setup** (5 minutes):
1. Create/choose a GCP project and enable the *Cloud Translation API*.
2. Create a *service account*, grant it the Translation API user role, and
   download a JSON key.
3. Point `translation.google_credentials` at that file (or set
   `GOOGLE_APPLICATION_CREDENTIALS`).
4. `pip install google-cloud-translate` (already in requirements.txt).

**Claude post-edit setup** (optional): `pip install anthropic`, set
`post_edit.api_key` or `ANTHROPIC_API_KEY`, flip `post_edit.enabled: true`.
Each pass sends up to `post_edit.batch_size` machine translations together
with their sources and asks Claude to fix fluency in Sorani; failures fall
back to the machine output (and are cached).

See `config.example.yaml` for every knob (DPI, alignment policy, inpainting
method, cache path, workers, JPEG export, …).

## Translation engines

| Engine | Needs | Cost | Sorani quality |
|--------|-------|------|----------------|
| `gfree` (default in UI) | nothing | free forever | same MT as translate.google.com |
| `google` (Cloud API) | service-account JSON + billing | 500,000 chars/month free, then $20/M | same MT, official + batched (fast, reliable) |
| `mock` | nothing | free | offline dictionary — demo only, produces a placeholder sentence |
| `passthrough` | nothing | free | no translation (debugging) |

**Which one for a whole book?** `gfree` is the zero-setup option, but the
public endpoint rate-limits aggressively (HTTP 429), so long books can end
up with failed pages — use **Retry failed** or raise `translation.free_delay`
(env `BT_FREE_DELAY`). The official `google` engine is the reliable
"free forever" route: the first 500,000 characters every month cost nothing
(a 200-page book fits comfortably) and requests never get throttled.

**Honest note on quality:** no machine translation is *excellent* for
Sorani — it is a low-resource language. The biggest quality jump comes from
the optional **Claude post-edit** pass (`post_edit.enabled: true`), which
fixes fluency on top of any engine. DeepL and LibreTranslate do not support
Sorani at all; Microsoft Azure Translator does (2M chars/month free tier)
and may be added as another engine later.

## Using the web UI

1. Open http://127.0.0.1:8000, drop a **PDF / EPUB / DOCX / page images**.
2. Pick options: engine, DPI, output format, alignment policy, OCR provider,
   page workers, Claude post-edit, Eastern numerals.
3. **Start translation** — a job card shows a live progress bar, per-page
   status grid (click a square to preview the rendered page) and stats.
4. **Download** the translated book when it completes.

Failed pages don't abort the book: they are retried on **Retry failed**, and
until then they are included in the export as the original page so the output
stays complete. After a crash or server restart, interrupted jobs are
detected automatically and can be resumed with one click — done pages are
skipped and the translation cache makes retries nearly free.

## Using the CLI

```bash
python -m ckb_translator.cli translate book.pdf                  # mock engine default
python -m ckb_translator.cli translate book.pdf --engine google --dpi 300
python -m ckb_translator.cli translate book.pdf --post-edit --alignment mirror
python -m ckb_translator.cli translate scan.png scan2.png        # images → OCR path
python -m ckb_translator.cli resume job_20250101_120000_ab12cd   # resume after failure
python -m ckb_translator.cli jobs                                # list all jobs
python -m ckb_translator.cli fonts                               # installed fonts + raqm status
python -m ckb_translator.cli demo                                # offline sample book
```

## Input and output matrix

| Input                     | Extraction                | Default output | Alternative |
|---------------------------|---------------------------|----------------|-------------|
| PDF with text layer       | PyMuPDF spans + flags     | PDF            | —           |
| Scanned PDF / photos      | PaddleOCR or tesseract    | PDF            | —           |
| EPUB                      | chapter HTML → blocks     | EPUB (RTL, embedded font) | PDF (typeset) |
| DOCX                      | paragraphs + heading styles | DOCX (RTL `w:bidi`/`w:rtl`) | PDF (typeset) |

Reflowable sources (EPUB/DOCX) have no fixed pages, so they are translated
chapter-by-chapter and re-typeset; `output_format: pdf` flows the Kurdish
text onto fresh A4 pages right-aligned.

## Optional components

| Component | Install | Notes |
|-----------|---------|-------|
| PaddleOCR | `pip install paddlepaddle paddleocr` | Preferred OCR for scans; auto-detected (`ocr.provider: auto`) |
| Tesseract | `pip install pytesseract` + system `tesseract` binary | Lightweight OCR fallback (used in the sandbox demo) |
| LaMa inpainting | `pip install simple-lama-inpainting` | Higher-quality text removal (`inpaint.method: lama`) |
| img2pdf | in requirements.txt | Lossless PDF assembly; falls back to Pillow if missing |

## Kurdish-specific behaviour

* **Shaping** — if Pillow is built with libraqm (the default in modern
  wheels), HarfBuzz shapes and FriBidi reorders natively. Otherwise the
  renderer falls back to `arabic-reshaper` (Kurdish language tables) +
  `python-bidi`. `python -m ckb_translator.cli fonts` shows which path is active.
* **Fonts** — the matcher classifies the source font (serif / sans / kufi /
  script / mono, honouring bold/italic) and picks the first preferred
  Kurdish family that fully covers the translated text's glyphs
  (Kurdish letters like ڕ ڵ ۆ ێ گ چ پ ژ ڤ are coverage-checked via
  fontTools). Missing bold faces are simulated with a stroke.
* **Alignment** — `auto` (default) mirrors the visual side for LTR sources
  (an English left-aligned paragraph becomes a right-aligned Kurdish one)
  and preserves it for Arabic-script sources. `mirror` / `preserve` /
  `right` force a policy.
* **Numerals** — set `render.eastern_numerals: true` to convert `0-9` → `٠-٩`.
* **Auto-shrink** — font size is binary-searched down to `min_font_size`
  whenever the Kurdish text overflows the original box.

## Project layout

```
ckb_translator/         (NOT `app` — see "Pydroid 3" note below)
├── main.py            FastAPI app factory
├── cli.py             serve / translate / resume / demo / jobs / fonts
├── api/               REST routes + pydantic schemas
├── core/
│   ├── config.py      defaults < config.yaml < env < job options
│   ├── models.py      TextBox, Document, JobState
│   ├── pipeline.py    the 7-stage orchestrator (fixed + reflowable)
│   └── jobs.py        job manager: threads, persistence, resume, cancel
├── extract/           pdf_doc · ocr (paddle/tesseract) · images_doc · reflow_doc
├── translate/         engines (google/mock/passthrough + Claude) · cache · service
├── inpaint/           OpenCV Telea/NS (+ optional LaMa)
├── font_match/        classifier + coverage-aware Kurdish font library
├── render/            rtl.py — shaping, wrapping, fitting, RTL drawing
├── export/            exporter.py — PDF / EPUB / DOCX writers
└── web/static/        vanilla JS web UI (no build step)
tests/                 119 tests incl. dedicated RTL-rendering suite
scripts/               fetch_fonts.py · make_sample_pdf.py
fonts/                 downloaded Kurdish fonts (OFL, see OFL-LICENSES.md)
```

## Tests

```bash
python -m pytest tests/ -q
```

Covers: RTL shaping/bidi/wrapping/fitting/alignment (rendered-ink
assertions), font classification and coverage-aware resolution, translation
cache + service batching/dedup, PDF block extraction (size/colour/bold/
alignment), OCR line grouping + style estimation, inpainting removal,
exporter round-trips (PDF/EPUB/DOCX), pipeline resume/cancel/cache, and a
full HTTP flow (upload → job → poll → download). All tests run offline with
the mock engine.

## Pydroid 3 (Android) — ImportError fix

The Python package on PyPI literally called `app` (a CLI toolkit) is
**preinstalled inside Pydroid 3's site-packages** and shadows any project
module named `app`. Running code that does `from app import __version__`
(or `import app`) on Pydroid 3 fails with:

```
ImportError: cannot import name '__version__' from 'app'
(/data/user/0/ru.iiec.pydroid3/files/aarch64-linux-android/.../site-packages/app/__init__.py)
```

This repo therefore uses the **unique package name `ckb_translator`**
instead of `app`, which sidesteps the collision entirely. No other change
is needed — every command is `python -m ckb_translator.cli ...` /
`python run.py`.

If you forked an earlier version that still used the `app/` package name,
either:

1. **rename the package** (recommended) — run
   `python scripts/rename_package.py /path/to/book-translator-ckb`, or
2. **uninstall the conflicting PyPI package** in Pydroid's pip:
   `pip uninstall app`.

### `ModuleNotFoundError: No module named 'ckb_translator'` (Pydroid)

Two possible causes:

1. **Only `run.py` was copied to the device.** The `ckb_translator/` folder
   must sit right next to it. Extract the **whole** `book-translator-ckb`
   zip (e.g. to `/sdcard/book-translator-ckb`) and open `run.py` from
   inside the extracted folder:
   ```
   /sdcard/book-translator-ckb/run.py
   /sdcard/book-translator-ckb/ckb_translator/   <-- required
   ```
2. **Pydroid's launcher quirk.** `iiec_run.py` executes your file with
   `exec()`, which — unlike a normal `python run.py` — does **not** add the
   script's folder to `sys.path`, so the import fails even when the
   package folder is right next to the file.

`run.py` ships with a bootstrap that fixes cause 2 automatically: before
importing anything it locates the project root (via `sys.argv[0]`, the
working directory, common Android locations like `/sdcard/Download/…`, or
the `BT_HOME` environment variable) and prepends it to `sys.path`. If the
package is genuinely missing it exits with a bilingual Kurdish/English
help message instead of a bare traceback.

On Pydroid, pressing **Run** on `run.py` starts the web server — keep the
console open and visit `http://127.0.0.1:8000` in Chrome on the same
device. From Pydroid's terminal you can also use
`cd /sdcard/book-translator-ckb && python -m ckb_translator.cli demo`.
To reach the UI from another device on the same Wi-Fi, set
`server.host: 0.0.0.0` in `config.yaml`.

## Limitations & roadmap

* Rotated or skewed scanned pages are not deskewed (OCR quality drops).
* Justification is approximated by alignment only.
* LaMa gives better inpainting than Telea on textured backgrounds — install
  it and set `inpaint.method: lama`.
* Machine-translated Sorani benefits greatly from the Claude post-edit pass.
* Vector graphics tightly overlapping text can be partially masked.
* Long books produce large PDFs at 300 DPI — use
  `export.image_format: jpeg` to shrink them.

## Licences

* Code: MIT.
* Fonts: SIL Open Font License 1.1 — see `fonts/OFL-LICENSES.md`.
