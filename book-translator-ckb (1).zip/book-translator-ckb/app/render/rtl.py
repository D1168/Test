"""RTL rendering of Kurdish Sorani text (Arabic script).

Two rendering paths, selected automatically:

* **libraqm path** (preferred): Pillow was built with libraqm, so HarfBuzz
  does the Arabic shaping and FriBidi the bidi reordering natively — text is
  passed in logical order with ``direction="rtl"``.
* **fallback path**: ``arabic-reshaper`` converts letters to their Arabic
  presentation forms and ``python-bidi`` reorders the string into visual
  (LTR drawable) order.  Works everywhere, slightly less correct for exotic
  combining sequences.

Both paths measure text the same way, so word-wrapping, auto-shrink and
alignment behave identically.
"""
from __future__ import annotations

import threading
from pathlib import Path

import arabic_reshaper
from bidi.algorithm import get_display
from PIL import Image, ImageDraw, ImageFont, features

from app.core.models import TextBox

RAQM_AVAILABLE: bool = features.check("raqm")

# --------------------------------------------------------------------------- #
# Text shaping / bidi
# --------------------------------------------------------------------------- #

_ARABIC_RANGES = (
    (0x0600, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF),
    (0xFB50, 0xFDFF), (0xFE70, 0xFEFF),
)


def source_is_rtl(text: str) -> bool:
    """True when *text* is predominantly Arabic-script (used to decide whether
    the original alignment already matches RTL reading)."""
    if not text:
        return False
    arabic = 0
    letters = 0
    for ch in text:
        if ch.isalpha():
            letters += 1
            code = ord(ch)
            if any(lo <= code <= hi for lo, hi in _ARABIC_RANGES):
                arabic += 1
    return letters > 0 and arabic / letters > 0.25


def _make_reshaper() -> arabic_reshaper.ArabicReshaper:
    """Kurdish config first (adds Kurdish letters to the joining tables)."""
    for conf in ({"language": "Kurdish", "support_ligatures": False},
                 {"support_ligatures": False}):
        try:
            return arabic_reshaper.ArabicReshaper(configuration=conf)
        except Exception:  # unknown config key in old versions
            continue
    return arabic_reshaper.ArabicReshaper()


_RESHAPER = _make_reshaper()


def reshape(text: str) -> str:
    """Convert Arabic-script letters to their joined presentation forms."""
    return _RESHAPER.reshape(text)


def shape_for_display(text: str) -> str:
    """Reshape + bidi-reorder into visual order (non-raqm rendering path)."""
    return get_display(reshape(text), base_dir="R")


_WESTERN_TO_EASTERN = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def convert_numerals(text: str) -> str:
    """Convert ASCII digits to Eastern Arabic-Indic digits."""
    return text.translate(_WESTERN_TO_EASTERN)


def effective_alignment(original: str, mode: str, source_text: str) -> str:
    """Decide the visual alignment for the Kurdish block.

    * ``preserve`` — keep the original visual side.
    * ``mirror``   — swap left/right (a left-aligned English paragraph becomes
      a right-aligned Kurdish paragraph).
    * ``right``    — always right-align.
    * ``auto``     — mirror only when the source text is LTR (e.g. English);
      an already-RTL source (Arabic book) keeps its visual side.
    """
    orig = (original or "left").lower()
    if orig not in ("left", "center", "right"):
        orig = "left"
    if mode == "right":
        return "right"
    if mode == "auto":
        mode = "preserve" if source_is_rtl(source_text) else "mirror"
    if mode == "mirror":
        return {"left": "right", "right": "left", "center": "center"}[orig]
    return orig  # preserve


# --------------------------------------------------------------------------- #
# Font loading
# --------------------------------------------------------------------------- #

_SYSTEM_FONT_CANDIDATES = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/TTF/DejaVuSans.ttf",
    "/usr/share/fonts/dejavu/DejaVuSans.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "C:/Windows/Fonts/arial.ttf",
)


def load_font(path: str | Path | None, size: int, bold: bool = False,
              italic: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Load a font at *size* px, honouring named instances of variable fonts."""
    size = max(1, int(size))
    if path and Path(path).is_file():
        font = ImageFont.truetype(str(path), size)
        try:
            names = [n.decode("utf-8", "ignore") if isinstance(n, bytes) else str(n)
                     for n in font.get_variation_names()]
        except Exception:
            names = []
        if names:
            wanted: list[str] = []
            if bold and italic:
                wanted += ["Bold Italic", "BoldItalic"]
            if bold:
                wanted += ["Bold", "SemiBold", "DemiBold"]
            if italic:
                wanted += ["Italic", "Oblique", "Slanted"]
            for w in wanted:
                for n in names:
                    if n.replace(" ", "").lower() == w.replace(" ", "").lower():
                        font.set_variation_by_name(n)
                        return font
        return font
    return default_font(size)


def default_font(size: int):
    """Last-resort font when no Kurdish font file is available."""
    for cand in _SYSTEM_FONT_CANDIDATES:
        if Path(cand).is_file():
            return ImageFont.truetype(cand, max(1, int(size)))
    try:
        return ImageFont.load_default(size=max(1, int(size)))  # Pillow >= 10.1
    except TypeError:
        return ImageFont.load_default()


# --------------------------------------------------------------------------- #
# Measurement / wrapping / fitting
# --------------------------------------------------------------------------- #

_scratch_lock = threading.Lock()
_scratch_img: Image.Image | None = None
_scratch_draw: ImageDraw.ImageDraw | None = None


def _scratch() -> ImageDraw.ImageDraw:
    global _scratch_img, _scratch_draw
    with _scratch_lock:
        if _scratch_draw is None:
            _scratch_img = Image.new("RGB", (8, 8))
            _scratch_draw = ImageDraw.Draw(_scratch_img)
        return _scratch_draw


def text_width(text: str, font, draw: ImageDraw.ImageDraw | None = None) -> float:
    """Width of *text* (logical order) as it will be rendered."""
    d = draw or _scratch()
    if RAQM_AVAILABLE:
        try:
            return float(d.textlength(text, font=font, direction="rtl"))
        except Exception:
            pass  # bitmap fonts don't support direction — fall through
    try:
        return float(font.getlength(shape_for_display(text)))
    except Exception:
        return float(font.getlength(text))


def wrap_text(text: str, font, max_width: float,
              draw: ImageDraw.ImageDraw | None = None) -> list[str]:
    """Word-wrap *text* (logical order) to *max_width* pixels."""
    lines: list[str] = []
    for para in (text or "").split("\n"):
        words = [w for w in para.split(" ") if w]
        if not words:
            lines.append("")
            continue
        current = words[0]
        for word in words[1:]:
            trial = f"{current} {word}"
            if text_width(trial, font, draw) <= max_width:
                current = trial
            else:
                lines.append(current)
                current = word
        lines.append(current)
    return lines or [""]


def fit_text(text: str, font_path: str | Path | None, box_w: int, box_h: int,
             start_size: int, *, min_size: int = 9, line_spacing: float = 1.15,
             bold: bool = False, italic: bool = False,
             draw: ImageDraw.ImageDraw | None = None):
    """Binary-search the largest font size whose wrapped text fits the box.

    Returns ``(size, lines, line_step, overflow)``; ``overflow`` is True when
    even ``min_size`` does not fit (text is still rendered, best effort).
    """
    min_size = max(4, int(min_size))
    start = max(min_size, int(start_size))
    best = None
    lo, hi = min_size, start
    while lo <= hi:
        mid = (lo + hi) // 2
        font = load_font(font_path, mid, bold, italic)
        lines = wrap_text(text, font, max(1, box_w), draw)
        asc, desc = font.getmetrics()
        step = max(1, int((asc + desc) * line_spacing))
        widths = [text_width(line, font, draw) for line in lines]
        if max(widths, default=0.0) <= box_w and step * len(lines) <= box_h:
            best = (mid, lines, step)
            lo = mid + 1
        else:
            hi = mid - 1
    if best is None:
        font = load_font(font_path, min_size, bold, italic)
        lines = wrap_text(text, font, max(1, box_w), draw)
        asc, desc = font.getmetrics()
        best = (min_size, lines, max(1, int((asc + desc) * line_spacing)))
        return best[0], best[1], best[2], True
    return best[0], best[1], best[2], False


# --------------------------------------------------------------------------- #
# Block rendering
# --------------------------------------------------------------------------- #

def draw_block(image: Image.Image, bbox: tuple[int, int, int, int], text: str, *,
               font_path: str | Path | None = None,
               color: tuple[int, int, int] = (0, 0, 0),
               bold: bool = False, italic: bool = False,
               simulate_bold: bool = False,
               alignment: str = "left",
               alignment_mode: str = "auto",
               source_text: str | None = None,
               start_size_px: int | None = None,
               min_size: int = 9,
               line_spacing: float = 1.15,
               padding: int = 3,
               eastern_numerals: bool = False,
               draw: ImageDraw.ImageDraw | None = None) -> dict:
    """Render one translated text block RTL into *bbox* on *image*.

    ``alignment`` is the ORIGINAL visual alignment of the source block;
    ``alignment_mode`` (auto/mirror/preserve/right) decides the final side.
    ``source_text`` is the pre-translation text (used by ``auto``).
    Returns ``{"size", "lines", "alignment", "overflow"}``.
    """
    text = (text or "").strip()
    if not text:
        return {"size": 0, "lines": 0, "alignment": alignment, "overflow": False}
    if eastern_numerals:
        text = convert_numerals(text)

    x0, y0, x1, y1 = (int(v) for v in bbox)
    box_w = max(1, x1 - x0 - 2 * padding)
    box_h = max(1, y1 - y0 - 2 * padding)
    start = int(start_size_px) if start_size_px else max(int(box_h * 0.8), min_size)

    size, lines, step, overflow = fit_text(
        text, font_path, box_w, box_h, start,
        min_size=min_size, line_spacing=line_spacing, bold=bold, italic=italic)
    font = load_font(font_path, size, bold and not simulate_bold, italic)

    align = effective_alignment(alignment, alignment_mode,
                                 source_text if source_text is not None else text)
    draw = draw or ImageDraw.Draw(image)
    stroke = max(1, size // 22) if (bold and simulate_bold) else 0

    total_h = step * len(lines)
    y = y0 + padding
    if len(lines) == 1:  # vertically centre single-line blocks (headings etc.)
        y = y0 + padding + max(0, (box_h - total_h) // 2)

    for line in lines:
        lw = text_width(line, font, draw)
        if align == "right":
            x = x1 - padding - lw
        elif align == "center":
            x = x0 + padding + max(0, (box_w - lw) / 2)
        else:
            x = x0 + padding
        payload = line if RAQM_AVAILABLE else shape_for_display(line)
        kwargs: dict = {"font": font, "fill": color}
        if RAQM_AVAILABLE:
            kwargs["direction"] = "rtl"
        if stroke:
            kwargs.update(stroke_width=stroke, stroke_fill=color)
        try:
            draw.text((x, y), payload, **kwargs)
        except Exception:
            # e.g. bitmap default font without direction support
            draw.text((x, y), shape_for_display(line), font=font, fill=color,
                      stroke_width=stroke, stroke_fill=color)
        y += step

    return {"size": size, "lines": len(lines), "alignment": align,
            "overflow": overflow}


def render_box(image: Image.Image, box: TextBox, translated: str, *,
               font_path: str | Path | None, alignment_mode: str = "auto",
               min_size: int = 9, line_spacing: float = 1.15, padding: int = 3,
               eastern_numerals: bool = False, simulate_bold: bool = False,
               draw: ImageDraw.ImageDraw | None = None) -> dict:
    """Convenience wrapper: render a :class:`TextBox` with its own style."""
    return draw_block(
        image, box.bbox, translated,
        font_path=font_path, color=box.color,
        bold=box.bold, italic=box.italic, simulate_bold=simulate_bold,
        alignment=box.alignment, alignment_mode=alignment_mode,
        source_text=box.text, start_size_px=box.font_size_px,
        min_size=min_size, line_spacing=line_spacing, padding=padding,
        eastern_numerals=eastern_numerals, draw=draw)
