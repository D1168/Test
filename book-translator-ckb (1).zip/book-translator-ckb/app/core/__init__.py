"""Core package: configuration, data models, job manager, pipeline."""
