"""Job manager: persistent job registry, background threads, resume & cancel.

Each job is a JSON file under ``jobs.dir`` holding the full
:class:`JobState` — per-page status included — written atomically after every
page.  That file is the single source of truth: after a crash or server
restart, "running" jobs are demoted to "interrupted" and can be resumed with
one call; pages already marked ``done`` are skipped, failed pages are retried,
and the translation cache keeps retries cheap.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from app.core.config import AppConfig, resolve_path
from app.core.models import JobState
from app.core.pipeline import BookJob
from app.extract import classify_input, peek_page_count

logger = logging.getLogger(__name__)


class JobControlError(Exception):
    """Raised for invalid job-management operations (maps to HTTP 409/404)."""


class JobManager:
    def __init__(self, config: AppConfig):
        self.config = config
        self.jobs_dir = resolve_path(config, config.jobs.dir)
        self.uploads_dir = resolve_path(config, config.jobs.uploads_dir)
        self.output_dir = resolve_path(config, config.jobs.output_dir)
        for directory in (self.jobs_dir, self.uploads_dir, self.output_dir):
            directory.mkdir(parents=True, exist_ok=True)
        self._threads: dict[str, threading.Thread] = {}
        self._cancel: dict[str, threading.Event] = {}
        self._locks: dict[str, threading.Lock] = {}
        self._registry_lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # state persistence (atomic writes)
    # ------------------------------------------------------------------ #

    def _state_path(self, job_id: str) -> Path:
        return self.jobs_dir / f"{job_id}.json"

    def _lock_for(self, job_id: str) -> threading.Lock:
        with self._registry_lock:
            return self._locks.setdefault(job_id, threading.Lock())

    def save(self, state: JobState) -> None:
        state.touch()
        path = self._state_path(state.id)
        tmp = path.with_suffix(".tmp")
        with self._lock_for(state.id):
            tmp.write_text(state.to_json(), encoding="utf-8")
            tmp.replace(path)

    def load(self, job_id: str) -> JobState:
        path = self._state_path(job_id)
        if not path.is_file():
            raise JobControlError(f"unknown job: {job_id}")
        try:
            return JobState.from_json(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise JobControlError(f"corrupt job state for {job_id}: {exc}") from exc

    # ------------------------------------------------------------------ #
    # lifecycle
    # ------------------------------------------------------------------ #

    def create(self, input_paths: list[str], input_name: str, input_type: str,
               options: dict) -> JobState:
        for p in input_paths:
            if not Path(p).is_file():
                raise JobControlError(f"input file missing: {p}")
        total = peek_page_count(input_paths, input_type)
        job_id = f"job_{datetime.now():%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}"
        state = JobState(
            id=job_id, input_name=input_name, input_paths=list(input_paths),
            input_type=input_type, options=options, status="pending",
            pages=[])
        (self.jobs_dir / job_id).mkdir(parents=True, exist_ok=True)
        from app.core.models import PageEntry
        state.pages = [PageEntry(index=i) for i in range(total)]
        self.save(state)
        logger.info("created job %s (%s, %d units)", job_id, input_type, total)
        return state

    def start(self, job_id: str) -> JobState:
        state = self.load(job_id)
        if self.is_running(job_id):
            raise JobControlError(f"job {job_id} is already running")
        if state.status == "completed":
            # nothing new to do unless some pages failed earlier
            if not any(p.status == "failed" for p in state.pages):
                raise JobControlError(
                    f"job {job_id} already completed — nothing to resume")
        state.status = "running"
        state.error = None
        self.save(state)

        event = threading.Event()
        thread = threading.Thread(target=self._run, args=(job_id, event),
                                  daemon=True, name=f"job-{job_id}")
        with self._registry_lock:
            self._cancel[job_id] = event
            self._threads[job_id] = thread
        thread.start()
        return self.load(job_id)

    def _run(self, job_id: str, cancel_event: threading.Event) -> None:
        try:
            state = self.load(job_id)
            job = BookJob(state, self.config, cancel_event=cancel_event)
            job.persist_hook = lambda: self.save(job.state)
            job.run()
        except Exception as exc:  # defensive: BookJob.run() already handles
            logger.exception("job thread crashed")
            try:
                state = self.load(job_id)
                state.status = "failed"
                state.error = str(exc)
                self.save(state)
            except Exception:
                pass
        finally:
            with self._registry_lock:
                self._threads.pop(job_id, None)
                self._cancel.pop(job_id, None)

    def cancel(self, job_id: str) -> bool:
        with self._registry_lock:
            event = self._cancel.get(job_id)
        if event is None:
            raise JobControlError(f"job {job_id} is not running")
        event.set()
        return True

    def retry(self, job_id: str) -> JobState:
        state = self.load(job_id)
        if self.is_running(job_id):
            raise JobControlError(f"job {job_id} is already running")
        changed = False
        for page in state.pages:
            if page.status == "failed":
                page.status = "pending"
                page.error = None
                changed = True
        state.status = "pending" if changed else state.status
        self.save(state)
        return self.start(job_id)

    # ------------------------------------------------------------------ #
    # queries
    # ------------------------------------------------------------------ #

    def is_running(self, job_id: str) -> bool:
        with self._registry_lock:
            thread = self._threads.get(job_id)
        return bool(thread and thread.is_alive())

    def job_dir(self, job_id: str) -> Path:
        return self.jobs_dir / job_id

    def pages_dir(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "pages"

    def list_jobs(self) -> list[JobState]:
        states: list[JobState] = []
        for path in sorted(self.jobs_dir.glob("job_*.json"), reverse=True):
            try:
                state = JobState.from_json(path.read_text(encoding="utf-8"))
                if state.status == "running" and not self.is_running(state.id):
                    state.status = "interrupted"  # server restarted mid-run
                    self.save(state)
                states.append(state)
            except Exception as exc:
                logger.warning("skipping corrupt job file %s: %s", path, exc)
        return states

    def get(self, job_id: str) -> JobState:
        state = self.load(job_id)
        if state.status == "running" and not self.is_running(job_id):
            state.status = "interrupted"
            self.save(state)
        return state

    def recover_interrupted(self) -> int:
        """Demote 'running' jobs left over from a previous process."""
        demoted = 0
        for state in self.list_jobs():
            if state.status == "running" and not self.is_running(state.id):
                demoted += 1
        return demoted


def create_job_from_uploads(manager: JobManager, upload_names: list[str],
                             options: dict) -> JobState:
    """Validate uploaded files and create + start a job for them."""
    paths: list[str] = []
    for name in upload_names:
        if "/" in name or "\\" in name or ".." in name:
            raise JobControlError(f"invalid upload name: {name}")
        path = manager.uploads_dir / name
        if not path.is_file():
            raise JobControlError(f"upload not found: {name}")
        paths.append(str(path))
    input_type = classify_input([Path(p).name for p in paths])
    display = Path(paths[0]).name if len(paths) == 1 else f"{len(paths)} images"
    return manager.create(paths, display, input_type, options)
