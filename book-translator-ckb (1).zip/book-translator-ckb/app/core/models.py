"""Shared data models: text boxes, documents, job state."""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Sequence

from PIL import Image

# Page statuses: pending -> done | failed  (terminal job statuses in JobState)
PAGE_STATUSES = ("pending", "done", "failed")
JOB_STATUSES = ("pending", "running", "completed", "completed_with_errors",
                "failed", "cancelled", "interrupted")


def rect_to_poly(rect: Sequence[int]) -> list[tuple[int, int]]:
    """(x0, y0, x1, y1) -> 4 corner points (clockwise)."""
    x0, y0, x1, y1 = int(rect[0]), int(rect[1]), int(rect[2]), int(rect[3])
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


@dataclass
class TextBox:
    """One translatable text block on a rasterised page.

    ``bbox`` and ``mask_polys`` are pixel coordinates at ``dpi``; ``bbox`` is
    the block rectangle the Kurdish text is rendered into, ``mask_polys`` are
    the (tighter) polygons of the original glyphs used for inpainting.
    """

    bbox: tuple[int, int, int, int]
    text: str
    font_size_pt: float = 12.0
    color: tuple[int, int, int] = (0, 0, 0)
    bold: bool = False
    italic: bool = False
    font_name: str = ""
    alignment: str = "left"          # original visual alignment
    mask_polys: list[list[tuple[int, int]]] = field(default_factory=list)
    dpi: int = 300
    source: str = "text"             # "text" | "ocr"
    serifed: bool | None = None      # from PyMuPDF span flags, when known
    monospaced: bool | None = None

    @property
    def width(self) -> int:
        return int(self.bbox[2] - self.bbox[0])

    @property
    def height(self) -> int:
        return int(self.bbox[3] - self.bbox[1])

    @property
    def font_size_px(self) -> int:
        return max(6, round(self.font_size_pt * self.dpi / 72.0))


class Document:
    """Base class for fixed-layout inputs (PDF, page images).

    Pages are processed independently: ``render_page`` and ``extract_boxes``
    must be callable for any index without depending on other pages.
    """

    kind = "fixed"

    def __init__(self, paths: list[Path]):
        self.paths = [Path(p) for p in paths]

    @property
    def page_count(self) -> int:
        raise NotImplementedError

    def render_page(self, index: int, dpi: int) -> Image.Image:
        raise NotImplementedError

    def extract_boxes(self, index: int, dpi: int) -> list[TextBox]:
        raise NotImplementedError

    def close(self) -> None:
        pass


@dataclass
class PageEntry:
    """Persistent per-page (or per-chapter) status — the resume ledger."""
    index: int
    status: str = "pending"
    error: str | None = None
    source: str = "text"             # text | ocr | none


@dataclass
class JobState:
    """Everything needed to resume a book translation after a crash."""
    id: str
    input_name: str
    input_paths: list[str]
    input_type: str                  # pdf | images | epub | docx
    options: dict = field(default_factory=dict)
    status: str = "pending"
    pages: list[PageEntry] = field(default_factory=list)
    output: str | None = None
    error: str | None = None
    created: float = field(default_factory=time.time)
    updated: float = field(default_factory=time.time)
    stats: dict = field(default_factory=lambda: {
        "cache_hits": 0, "engine_calls": 0, "engine_texts": 0,
        "post_edits": 0, "ocr_pages": 0, "fallback_fonts": 0,
    })

    # -- helpers -------------------------------------------------------- #

    def touch(self) -> None:
        self.updated = time.time()

    def progress(self) -> dict:
        total = len(self.pages)
        done = sum(1 for p in self.pages if p.status == "done")
        failed = sum(1 for p in self.pages if p.status == "failed")
        pending = total - done - failed
        return {"total": total, "done": done, "failed": failed, "pending": pending}

    def failed_pages(self) -> list[dict]:
        return [{"index": p.index, "error": p.error}
                for p in self.pages if p.status == "failed"]

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=1)

    @staticmethod
    def from_json(raw: str) -> "JobState":
        data = json.loads(raw)
        pages = [PageEntry(**p) for p in data.pop("pages", [])]
        return JobState(pages=pages, **data)
