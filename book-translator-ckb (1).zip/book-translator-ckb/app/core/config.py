"""Configuration loading.

Precedence (lowest to highest):

    built-in defaults  <  config.yaml  <  environment variables (BT_*)  <  per-job options

Relative paths inside the YAML file are resolved against ``AppConfig.base_dir``
(the directory that contains the config file, so the app can be started from
anywhere).  API keys are only ever read from the YAML file or from the
environment — they are never logged.
"""
from __future__ import annotations

import dataclasses
import os
import typing
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

APP_NAME = "book-translator-ckb"
TARGET_LANGUAGE = "ckb"  # Central Kurdish (Sorani)

ENGINES = ("google", "mock", "passthrough")
ALIGNMENT_MODES = ("auto", "mirror", "preserve", "right")
OUTPUT_FORMATS = ("auto", "pdf", "epub", "docx")
INPAINT_METHODS = ("telea", "ns", "lama")
IMAGE_FORMATS = ("png", "jpeg")
OCR_PROVIDERS = ("auto", "paddle", "tesseract", "none")


# --------------------------------------------------------------------------- #
# Config sections
# --------------------------------------------------------------------------- #

@dataclass
class FontsConfig:
    """Where Kurdish-capable fonts live and which family to prefer per style."""

    dir: str = "fonts"
    # Category (from the source-font classifier) -> ordered preference list.
    preferred: dict[str, list[str]] = field(default_factory=lambda: {
        "serif": ["Amiri", "Noto Naskh Arabic", "Scheherazade New"],
        "sans": ["Vazirmatn", "Noto Kufi Arabic", "Noto Naskh Arabic"],
        "kufi": ["Noto Kufi Arabic", "Vazirmatn"],
        "script": ["Scheherazade New", "Amiri"],
        "mono": ["Vazirmatn", "Noto Kufi Arabic"],
    })
    # Used when the classified category has no installed font (and as the
    # body font for reflowable EPUB/DOCX output).
    default: list[str] = field(default_factory=lambda: [
        "Noto Naskh Arabic", "Vazirmatn", "Amiri", "Scheherazade New", "Noto Kufi Arabic",
    ])


@dataclass
class TranslationConfig:
    """Machine-translation engine settings (Google Cloud Translation, ckb)."""

    engine: str = "mock"            # google | mock | passthrough
    source_language: str = "auto"   # ISO-639 code or "auto"
    target_language: str = TARGET_LANGUAGE
    google_credentials: str = ""    # path to service-account JSON (or use env)
    google_project_id: str = ""     # inferred from credentials when empty
    batch_size: int = 64            # texts per API request
    batch_chars: int = 8000         # safety cap on characters per request


@dataclass
class PostEditConfig:
    """Optional Claude post-editing pass for fluency."""

    enabled: bool = False
    provider: str = "claude"
    api_key: str = ""               # or set BT_CLAUDE_API_KEY
    model: str = "claude-sonnet-4-20250514"
    batch_size: int = 12            # segments polished per Claude request


@dataclass
class OcrConfig:
    """OCR settings for scanned pages / image inputs."""

    provider: str = "auto"          # auto | paddle | tesseract | none
    paddle_lang: str = "en"         # PaddleOCR model language
    tesseract_lang: str = "eng"     # tesseract language pack
    min_confidence: float = 0.5


@dataclass
class CacheConfig:
    """Translation cache (SQLite) — avoids re-translating on retries/resume."""

    enabled: bool = True
    path: str = "data/cache.sqlite3"


@dataclass
class JobsConfig:
    """Job persistence, concurrency and error policy."""

    dir: str = "data/jobs"
    uploads_dir: str = "data/uploads"
    output_dir: str = "data/output"
    page_workers: int = 1           # pages processed concurrently
    on_error: str = "continue"      # continue | abort


@dataclass
class RenderConfig:
    """RTL rendering options."""

    min_font_size: int = 9          # px; auto-shrink never goes below this
    alignment: str = "auto"         # auto | mirror | preserve | right
    line_spacing: float = 1.15      # multiplier between wrapped lines
    padding_px: int = 3             # inner padding inside the original bbox
    eastern_numerals: bool = False  # convert 0-9 to ٠-٩
    simulate_bold: bool = True      # fake bold with stroke when no bold face


@dataclass
class InpaintConfig:
    """Original-text removal settings."""

    method: str = "telea"           # telea | ns | lama
    radius: int = 3
    dilate_px: int = 3              # mask dilation around text boxes


@dataclass
class ExportConfig:
    image_format: str = "png"       # png (lossless) | jpeg (smaller)
    jpeg_quality: int = 85


@dataclass
class ServerConfig:
    host: str = "127.0.0.1"
    port: int = 8000


@dataclass
class AppConfig:
    dpi: int = 300                  # rendering DPI for page rasterisation
    fonts: FontsConfig = field(default_factory=FontsConfig)
    translation: TranslationConfig = field(default_factory=TranslationConfig)
    post_edit: PostEditConfig = field(default_factory=PostEditConfig)
    ocr: OcrConfig = field(default_factory=OcrConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    jobs: JobsConfig = field(default_factory=JobsConfig)
    render: RenderConfig = field(default_factory=RenderConfig)
    inpaint: InpaintConfig = field(default_factory=InpaintConfig)
    export: ExportConfig = field(default_factory=ExportConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    base_dir: Path = field(default_factory=lambda: Path.cwd())


# --------------------------------------------------------------------------- #
# Loading / merging
# --------------------------------------------------------------------------- #

def _build(cls: type, data: dict) -> Any:
    """Construct a dataclass from a dict, recursing into nested dataclass fields."""
    hints = typing.get_type_hints(cls)
    kwargs: dict[str, Any] = {}
    for key, value in data.items():
        if key not in hints or key.startswith("_"):
            continue  # silently ignore unknown keys (forward compatibility)
        ann = hints[key]
        if dataclasses.is_dataclass(ann) and isinstance(value, dict):
            value = _build(ann, value)
        kwargs[key] = value
    return cls(**kwargs)


def _apply_env(cfg: AppConfig) -> None:
    """Overlay BT_* environment variables."""
    env = os.environ

    def set_attr(section: Any, name: str, raw: str | None, cast=None) -> None:
        if raw:
            setattr(section, name, cast(raw) if cast else raw)

    set_attr(cfg.translation, "engine", env.get("BT_ENGINE"))
    set_attr(cfg.translation, "source_language", env.get("BT_SOURCE_LANG"))
    set_attr(cfg.translation, "target_language", env.get("BT_TARGET_LANG"))
    set_attr(cfg.translation, "google_credentials", env.get("BT_GOOGLE_CREDENTIALS"))
    set_attr(cfg.translation, "google_project_id", env.get("BT_GOOGLE_PROJECT"))
    set_attr(cfg.post_edit, "api_key", env.get("BT_CLAUDE_API_KEY"))
    set_attr(cfg.post_edit, "model", env.get("BT_CLAUDE_MODEL"))
    set_attr(cfg.fonts, "dir", env.get("BT_FONTS_DIR"))
    if env.get("BT_DPI"):
        cfg.dpi = int(env["BT_DPI"])


def load_config(path: str | os.PathLike | None = None) -> AppConfig:
    """Load configuration from *path* (or config.yaml / config.example.yaml)."""
    if path is None:
        env_path = os.environ.get("BT_CONFIG")
        if env_path:
            candidates = [Path(env_path)]
        else:
            candidates = [Path("config.yaml"), Path("config.example.yaml")]
        path = next((c for c in candidates if c.is_file()), candidates[0])

    path = Path(path).expanduser()
    raw: dict = {}
    if path.is_file():
        raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        raise ValueError(f"config file {path} must contain a YAML mapping")

    cfg = _build(AppConfig, raw)
    cfg.base_dir = path.parent.resolve() if path.is_file() else Path.cwd().resolve()
    _apply_env(cfg)
    return cfg


def resolve_path(cfg: AppConfig, value: str | Path) -> Path:
    """Resolve *value* against the config file's directory."""
    p = Path(value).expanduser()
    return p if p.is_absolute() else (cfg.base_dir / p)


def ensure_dirs(cfg: AppConfig) -> None:
    """Create the runtime directories (jobs, uploads, output, cache, fonts)."""
    for rel in (cfg.jobs.dir, cfg.jobs.uploads_dir, cfg.jobs.output_dir,
                str(Path(cfg.cache.path).parent), cfg.fonts.dir):
        resolve_path(cfg, rel).mkdir(parents=True, exist_ok=True)


_OPTION_KEYS = (
    "engine", "source_language", "target_language", "dpi", "post_edit",
    "output_format", "alignment", "page_workers", "ocr_provider",
    "inpaint_method", "min_font_size", "eastern_numerals", "image_format",
)


def runtime_options(cfg: AppConfig, overrides: dict | None = None) -> dict:
    """Merge per-job *overrides* over config-derived defaults into a flat,
    validated options dict that the pipeline consumes."""
    opts = {
        "engine": cfg.translation.engine,
        "source_language": cfg.translation.source_language,
        "target_language": cfg.translation.target_language,
        "dpi": int(cfg.dpi),
        "post_edit": bool(cfg.post_edit.enabled),
        "output_format": "auto",
        "alignment": cfg.render.alignment,
        "page_workers": int(cfg.jobs.page_workers),
        "ocr_provider": cfg.ocr.provider,
        "inpaint_method": cfg.inpaint.method,
        "min_font_size": int(cfg.render.min_font_size),
        "eastern_numerals": bool(cfg.render.eastern_numerals),
        "image_format": cfg.export.image_format,
    }
    if overrides:
        for key in _OPTION_KEYS:
            if overrides.get(key) is not None:
                opts[key] = overrides[key]

    # ---- validation / clamping ----
    if opts["engine"] not in ENGINES:
        raise ValueError(f"engine must be one of {ENGINES}, got {opts['engine']!r}")
    if opts["alignment"] not in ALIGNMENT_MODES:
        raise ValueError(f"alignment must be one of {ALIGNMENT_MODES}")
    if opts["output_format"] not in OUTPUT_FORMATS:
        raise ValueError(f"output_format must be one of {OUTPUT_FORMATS}")
    if opts["inpaint_method"] not in INPAINT_METHODS:
        raise ValueError(f"inpaint_method must be one of {INPAINT_METHODS}")
    if opts["image_format"] not in IMAGE_FORMATS:
        raise ValueError(f"image_format must be one of {IMAGE_FORMATS}")
    if opts["ocr_provider"] not in OCR_PROVIDERS:
        raise ValueError(f"ocr_provider must be one of {OCR_PROVIDERS}")
    opts["dpi"] = max(50, min(600, int(opts["dpi"])))
    opts["page_workers"] = max(1, min(8, int(opts["page_workers"])))
    opts["min_font_size"] = max(5, min(30, int(opts["min_font_size"])))
    opts["post_edit"] = bool(opts["post_edit"])
    opts["eastern_numerals"] = bool(opts["eastern_numerals"])
    return opts


def public_dict(cfg: AppConfig) -> dict:
    """Config summary safe to expose over the API (no secrets)."""
    return {
        "dpi": cfg.dpi,
        "target_language": cfg.translation.target_language,
        "engine": cfg.translation.engine,
        "fonts_dir": str(resolve_path(cfg, cfg.fonts.dir)),
        "render": dataclasses.asdict(cfg.render),
        "ocr": dataclasses.asdict(cfg.ocr),
        "has_google_credentials": bool(cfg.translation.google_credentials
                                       and Path(cfg.translation.google_credentials).is_file()),
        "has_claude_key": bool(cfg.post_edit.api_key),
    }
