/* Kitab — book translator to Kurdish Sorani (ckb). Vanilla JS, no build step. */
"use strict";

const $ = (id) => document.getElementById(id);
let uploadedNames = [];
let polling = null;
const expandedJobs = new Set();

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

async function api(path, options = {}) {
  const res = await fetch(path, options);
  if (!res.ok) {
    let detail = res.statusText;
    try { detail = (await res.json()).detail || detail; } catch (e) { /* ignore */ }
    throw new Error(`HTTP ${res.status}: ${detail}`);
  }
  return res.json();
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.remove("hidden");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.add("hidden"), 6000);
}

function fmtBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 ** 2).toFixed(1)} MB`;
}

/* ------------------------------------------------------------------ */
/* server info / options                                               */
/* ------------------------------------------------------------------ */

async function loadServerInfo() {
  const info = $("serverInfo");
  try {
    const [health, conf] = await Promise.all([api("/api/health"), api("/api/config")]);
    const bits = [];
    bits.push(`raqm ${health.raqm ? "✓" : "✗"}`);
    bits.push(`${health.fonts_installed} fonts`);
    bits.push(health.ocr ? health.ocr : "");
    info.innerHTML = "";
    const ok = document.createElement("span");
    ok.className = "ok";
    ok.textContent = `● online · v${health.version}`;
    info.appendChild(ok);
    const sub = document.createElement("div");
    sub.textContent = bits.filter(Boolean).join(" · ");
    info.appendChild(sub);

    // reflect availability on the engine selector
    const engineSel = $("optEngine");
    if (!conf.engines.google.available) {
      engineSel.querySelector('[value="google"]').disabled = true;
      engineSel.value = "mock";
      sub.textContent += " · google: not configured";
    }
    if (!conf.post_edit.available) {
      $("optPostEdit").disabled = true;
    }
    if (!conf.ocr.paddle && !conf.ocr.tesseract) {
      sub.textContent += " · OCR: none installed";
    }
    engineSel.dispatchEvent(new Event("change"));
  } catch (err) {
    info.innerHTML = `<span class="warn">● offline (${err.message})</span>`;
  }
}

function currentOptions() {
  return {
    engine: $("optEngine").value,
    dpi: parseInt($("optDpi").value, 10),
    output_format: $("optOutput").value,
    alignment: $("optAlignment").value,
    ocr_provider: $("optOcr").value,
    page_workers: parseInt($("optWorkers").value, 10) || 1,
    post_edit: $("optPostEdit").checked,
    eastern_numerals: $("optNumerals").checked,
  };
}

/* ------------------------------------------------------------------ */
/* upload                                                              */
/* ------------------------------------------------------------------ */

async function uploadFiles(fileList) {
  const files = Array.from(fileList);
  if (!files.length) return;
  const form = new FormData();
  files.forEach((f) => form.append("files", f, f.name));
  try {
    const res = await api("/api/upload", { method: "POST", body: form });
    uploadedNames = uploadedNames.concat(res.names).slice(0, 500);
    renderFileList(files.map((f) => `${f.name} (${fmtBytes(f.size)})`));
  } catch (err) {
    toast(`Upload failed — ${err.message}`);
  }
}

function renderFileList(descriptions) {
  const box = $("fileList");
  box.innerHTML = "";
  descriptions.forEach((desc) => {
    const chip = document.createElement("span");
    chip.className = "file-chip";
    chip.textContent = desc;
    box.appendChild(chip);
  });
  const ready = descriptions.length > 0;
  $("startBtn").disabled = !ready;
  $("startHint").textContent = ready
    ? "Ready — click Start translation."
    : "Add a file to begin.";
}

/* ------------------------------------------------------------------ */
/* job creation                                                        */
/* ------------------------------------------------------------------ */

async function startJob() {
  if (!uploadedNames.length) return;
  try {
    const body = { uploads: uploadedNames, options: currentOptions() };
    const res = await api("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    uploadedNames = [];
    renderFileList([]);
    await refreshJobs();
    if (!polling) polling = setInterval(refreshJobs, 1200);
    expandJob(res.id);
  } catch (err) {
    toast(`Could not start job — ${err.message}`);
  }
}

/* ------------------------------------------------------------------ */
/* job list                                                            */
/* ------------------------------------------------------------------ */

async function refreshJobs() {
  let jobs;
  try {
    jobs = (await api("/api/jobs")).jobs;
  } catch (err) {
    return; // server restarting — keep polling silently
  }
  const box = $("jobsList");
  if (!jobs.length) {
    box.innerHTML = '<p class="empty">No jobs yet.</p>';
    return;
  }
  box.innerHTML = "";
  for (const job of jobs) {
    box.appendChild(await renderJobCard(job));
  }
  const active = jobs.some((j) => j.running);
  if (!active && polling) {
    clearInterval(polling);
    polling = null;
  } else if (active && !polling) {
    polling = setInterval(refreshJobs, 1200);
  }
}

async function renderJobCard(job) {
  const card = document.createElement("div");
  card.className = "job";
  card.dataset.id = job.id;

  const top = document.createElement("div");
  top.className = "job-top";
  const name = document.createElement("span");
  name.className = "job-name";
  name.textContent = job.input_name;
  const chip = document.createElement("span");
  chip.className = `chip ${job.status}`;
  chip.textContent = job.status.replace(/_/g, " ");
  const actions = document.createElement("div");
  actions.className = "job-actions";

  if (job.running) {
    const cancel = document.createElement("button");
    cancel.textContent = "Cancel";
    cancel.className = "danger";
    cancel.onclick = () => api(`/api/jobs/${job.id}/cancel`, { method: "POST" })
      .then(refreshJobs).catch((e) => toast(e.message));
    actions.appendChild(cancel);
  } else if (job.progress.failed > 0 || ["failed", "interrupted", "cancelled"].includes(job.status)) {
    const retry = document.createElement("button");
    retry.textContent = "Retry failed";
    retry.onclick = () => api(`/api/jobs/${job.id}/retry`, { method: "POST" })
      .then(refreshJobs).catch((e) => toast(e.message));
    actions.appendChild(retry);
  }
  if (job.output) {
    const dl = document.createElement("button");
    dl.textContent = "⬇ Download";
    dl.onclick = () => { window.location = `/api/jobs/${job.id}/output`; };
    actions.appendChild(dl);
  }
  top.append(name, chip, actions);
  card.appendChild(top);

  const total = job.progress.total || 1;
  const pct = Math.round(((job.progress.done + job.progress.failed) / total) * 100);
  const bar = document.createElement("div");
  bar.className = "bar";
  const fill = document.createElement("div");
  fill.className = job.progress.failed ? "fill err" : "fill";
  fill.style.width = `${pct}%`;
  bar.appendChild(fill);
  card.appendChild(bar);

  const stats = document.createElement("div");
  stats.className = "job-stats";
  stats.innerHTML =
    `<span>${job.progress.done}/${job.progress.total} pages done</span>` +
    (job.progress.failed ? `<span style="color:var(--red)">${job.progress.failed} failed</span>` : "") +
    `<span>${job.input_type}</span>` +
    `<span>${new Date(job.created * 1000).toLocaleString()}</span>`;
  card.appendChild(stats);

  const toggle = document.createElement("button");
  toggle.className = "pages-toggle";
  toggle.textContent = expandedJobs.has(job.id) ? "hide pages" : "show pages";
  toggle.onclick = async () => {
    if (expandedJobs.has(job.id)) expandedJobs.delete(job.id);
    else expandJob(job.id);
    await refreshJobs();
  };
  card.appendChild(toggle);

  if (expandedJobs.has(job.id)) {
    const detail = await api(`/api/jobs/${job.id}`);
    const grid = document.createElement("div");
    grid.className = "grid";
    const maxCells = 600;
    detail.pages.slice(0, maxCells).forEach((page) => {
      const cell = document.createElement("span");
      cell.className = `cell ${page.status === "done" || page.status === "failed" ? page.status : "off"}`;
      cell.title = `page ${page.index + 1}: ${page.status}`;
      if (page.status === "done" || page.status === "failed") {
        cell.classList.remove("off");
        cell.onclick = () => openPreview(job.id, page.index);
      }
      grid.appendChild(cell);
    });
    if (detail.pages.length > maxCells) {
      const more = document.createElement("span");
      more.className = "cell off";
      more.textContent = `+${detail.pages.length - maxCells}`;
      grid.appendChild(more);
    }
    card.appendChild(grid);
    if (detail.error) {
      const err = document.createElement("p");
      err.style.cssText = "color:var(--red);font-size:12px;margin:10px 0 0;";
      err.textContent = detail.error;
      card.appendChild(err);
    }
    if (job.running) setTimeout(() => { if (document.contains(card)) refreshJobs(); }, 1500);
  }
  return card;
}

function expandJob(id) { expandedJobs.add(id); }

/* ------------------------------------------------------------------ */
/* preview modal                                                       */
/* ------------------------------------------------------------------ */

function openPreview(jobId, pageIndex) {
  $("previewImg").src = `/api/jobs/${jobId}/pages/${pageIndex}/preview`;
  $("previewCaption").textContent = `job ${jobId} · page ${pageIndex + 1}`;
  $("previewModal").classList.remove("hidden");
}

/* ------------------------------------------------------------------ */
/* wiring                                                              */
/* ------------------------------------------------------------------ */

function init() {
  const dz = $("dropzone");
  const input = $("fileInput");
  dz.addEventListener("click", () => input.click());
  input.addEventListener("change", () => uploadFiles(input.files));
  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("drag"); }));
  dz.addEventListener("drop", (e) => uploadFiles(e.dataTransfer.files));

  $("startBtn").addEventListener("click", startJob);
  $("refreshBtn").addEventListener("click", refreshJobs);
  $("previewClose").addEventListener("click", () =>
    $("previewModal").classList.add("hidden"));
  $("previewModal").addEventListener("click", (e) => {
    if (e.target === $("previewModal")) $("previewModal").classList.add("hidden");
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") $("previewModal").classList.add("hidden");
  });

  loadServerInfo();
  refreshJobs();
}

init();
