"""REST API for the web UI."""
from __future__ import annotations

import logging
import re
import time
import uuid
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from app.api.schemas import JobCreateAPI
from app.core.config import runtime_options
from app.core.jobs import JobControlError, create_job_from_uploads
from app.extract import SUPPORTED_EXTS, IMAGE_EXTS
from app.font_match import FontLibrary
from app.translate import claude_ready, google_ready

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api")

MAX_UPLOAD_BYTES = 400 * 1024 * 1024  # 400 MB


def _manager(request: Request):
    return request.app.state.manager


def _config(request: Request):
    return request.app.state.config


def _secure_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)
    return f"{uuid.uuid4().hex[:8]}_{cleaned}"


# --------------------------------------------------------------------------- #
# health / config
# --------------------------------------------------------------------------- #

@router.get("/health")
def health(request: Request):
    cfg = _config(request)
    from app.render import RAQM_AVAILABLE
    library = FontLibrary(Path(cfg.fonts.dir))
    return {
        "status": "ok",
        "version": request.app.version,
        "raqm": RAQM_AVAILABLE,
        "fonts_installed": len(library.families()),
        "translation_engine_default": cfg.translation.engine,
        "time": time.time(),
    }


@router.get("/config")
def get_config(request: Request):
    """Sanitised configuration + capability report (no secrets)."""
    cfg = _config(request)
    library = FontLibrary(Path(cfg.fonts.dir))
    from app.render import RAQM_AVAILABLE
    from app.extract.ocr import _paddle_available, _tesseract_available
    g_ok, g_reason = google_ready(cfg.translation)
    c_ok, c_reason = claude_ready(cfg.post_edit)
    return {
        "defaults": runtime_options(cfg),
        "engines": {
            "google": {"available": g_ok, "reason": g_reason},
            "mock": {"available": True, "reason": ""},
            "passthrough": {"available": True, "reason": ""},
        },
        "post_edit": {"available": c_ok, "reason": c_reason},
        "ocr": {
            "paddle": _paddle_available(),
            "tesseract": _tesseract_available(),
        },
        "fonts": {"dir": str(Path(cfg.fonts.dir).resolve()),
                  "families": library.families()},
        "raqm": RAQM_AVAILABLE,
    }


# --------------------------------------------------------------------------- #
# uploads
# --------------------------------------------------------------------------- #

@router.post("/upload")
async def upload(request: Request, files: list[UploadFile] = File(...)):
    if not files:
        raise HTTPException(400, "no files uploaded")
    uploads_dir = Path(_config(request).jobs.uploads_dir)
    uploads_dir.mkdir(parents=True, exist_ok=True)

    names: list[str] = []
    for upload in files:
        ext = Path(upload.filename or "").suffix.lower()
        if ext not in SUPPORTED_EXTS:
            raise HTTPException(415, f"unsupported file type: {ext or upload.filename}")
        data = await upload.read()
        if not data:
            raise HTTPException(400, f"empty file: {upload.filename}")
        if len(data) > MAX_UPLOAD_BYTES:
            raise HTTPException(413, f"file too large: {upload.filename}")
        stored = _secure_name(upload.filename or "upload")
        (uploads_dir / stored).write_bytes(data)
        names.append(stored)

    non_images = [n for n in names if Path(n).suffix.lower() not in IMAGE_EXTS]
    if len(non_images) > 1 or (non_images and len(names) > 1):
        raise HTTPException(400, "only a single PDF/EPUB/DOCX can be combined "
                                 "with nothing else; multiple files are for page images")
    return {"names": names}


# --------------------------------------------------------------------------- #
# jobs
# --------------------------------------------------------------------------- #

@router.post("/jobs")
def create_job(request: Request, body: JobCreateAPI):
    cfg = _config(request)
    manager = _manager(request)
    try:
        options = runtime_options(cfg, body.options.model_dump(exclude_none=True))
    except ValueError as exc:
        raise HTTPException(400, str(exc))

    # fail fast on unavailable engines / OCR providers
    if options["engine"] == "google":
        ok, reason = google_ready(cfg.translation)
        if not ok:
            raise HTTPException(400, f"Google engine unavailable: {reason}")
    if options.get("post_edit"):
        ok, reason = claude_ready(cfg.post_edit)
        if not ok:
            raise HTTPException(400, f"Claude post-edit unavailable: {reason}")
    if options.get("ocr_provider") == "paddle":
        from app.extract.ocr import _paddle_available
        if not _paddle_available():
            raise HTTPException(400, "PaddleOCR requested but not installed")

    try:
        state = create_job_from_uploads(manager, body.uploads, options)
        manager.start(state.id)
    except JobControlError as exc:
        raise HTTPException(400, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"id": state.id}


@router.get("/jobs")
def list_jobs(request: Request):
    manager = _manager(request)
    jobs = []
    for state in manager.list_jobs()[:50]:
        jobs.append(_summary(state, manager))
    return {"jobs": jobs}


@router.get("/jobs/{job_id}")
def get_job(request: Request, job_id: str):
    manager = _manager(request)
    try:
        state = manager.get(job_id)
    except JobControlError as exc:
        raise HTTPException(404, str(exc))
    detail = _summary(state, manager)
    detail.update({
        "options": state.options,
        "stats": state.stats,
        "failed_pages": state.failed_pages(),
        "pages": [{"index": p.index, "status": p.status} for p in state.pages],
        "error": state.error,
    })
    return detail


@router.post("/jobs/{job_id}/retry")
def retry_job(request: Request, job_id: str):
    manager = _manager(request)
    try:
        state = manager.retry(job_id)
    except JobControlError as exc:
        raise HTTPException(409, str(exc))
    return _summary(state, manager)


@router.post("/jobs/{job_id}/cancel")
def cancel_job(request: Request, job_id: str):
    manager = _manager(request)
    try:
        manager.cancel(job_id)
    except JobControlError as exc:
        raise HTTPException(409, str(exc))
    return {"id": job_id, "cancelled": True}


@router.get("/jobs/{job_id}/output")
def download_output(request: Request, job_id: str):
    manager = _manager(request)
    try:
        state = manager.get(job_id)
    except JobControlError as exc:
        raise HTTPException(404, str(exc))
    if not state.output or not Path(state.output).is_file():
        raise HTTPException(404, "output not ready")
    suffix = Path(state.output).suffix
    return FileResponse(state.output, filename=f"{Path(state.input_name).stem}_ckb{suffix}")


@router.get("/jobs/{job_id}/pages/{index}/preview")
def page_preview(request: Request, job_id: str, index: int):
    """JPEG thumbnail of a rendered page (created on demand)."""
    manager = _manager(request)
    page_png = manager.pages_dir(job_id) / f"page_{index:04d}.png"
    if not page_png.is_file():
        raise HTTPException(404, f"page {index} not rendered yet")
    thumbs = manager.job_dir(job_id) / "thumbs"
    thumbs.mkdir(exist_ok=True)
    thumb = thumbs / f"page_{index:04d}.jpg"
    if not thumb.is_file():
        from PIL import Image
        with Image.open(page_png) as img:
            img.thumbnail((900, 900))
            img.convert("RGB").save(thumb, "JPEG", quality=82)
    return FileResponse(thumb, media_type="image/jpeg")


# --------------------------------------------------------------------------- #

def _summary(state, manager) -> dict:
    running = manager.is_running(state.id)
    return {
        "id": state.id,
        "input_name": state.input_name,
        "input_type": state.input_type,
        "status": "running" if running and state.status == "running" else state.status,
        "running": running,
        "progress": state.progress(),
        "output": state.output,
        "created": state.created,
        "updated": state.updated,
    }
