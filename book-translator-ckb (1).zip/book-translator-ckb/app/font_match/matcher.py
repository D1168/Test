"""Classify the original font style and pick the closest Kurdish-capable font.

Classification maps the source font name (plus PyMuPDF span flags when
available) to a category: ``serif`` / ``sans`` / ``kufi`` / ``script`` /
``mono``.  Each category maps to an ordered preference list of Kurdish-capable
families (Amiri, Noto Naskh Arabic, Vazirmatn, Noto Kufi Arabic,
Scheherazade New).  Among the installed candidates the first family that fully
covers the characters of the translated text wins; otherwise the family with
the best coverage is used and flagged as a fallback.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

logger = __import__("logging").getLogger(__name__)

# --------------------------------------------------------------------------- #
# Classification
# --------------------------------------------------------------------------- #

_SERIF_HINTS = ("times", "georgia", "garamond", "serif", "roman", "palatino",
                "caslon", "minion", "cambria", "charter", "baskerville",
                "book", "naskh", "traditional", "sultan", "adobe")
_SANS_HINTS = ("arial", "helvetica", "verdana", "segoe", "tahoma", "calibri",
               "carlito", "roboto", "opensans", "lato", "ubuntu", "notosans",
               "dejavusans", "liberation", "inter", "fira", "droid", "vazir",
               "sfpro", "frutiger", "univers", "gill", "franklin", "clear")
_SCRIPT_HINTS = ("script", "cursive", "hand", "brush", "comic", "zapf",
                 "bradley", "diwani", "thuluth", "ruqaa", "ruqʿa", "farhadi",
                 "freestyle", "papyrus")
_KUFI_HINTS = ("kufi",)
_MONO_HINTS = ("mono", "courier", "consolas", "menlo", "cascadia", "sourcecode")

CATEGORIES = ("serif", "sans", "kufi", "script", "mono")


def _normalize(name: str) -> str:
    """Lowercase, strip PDF subset prefixes ('ABCDEF+'), drop separators."""
    n = (name or "").lower()
    if "+" in n:
        n = n.split("+")[-1]
    return re.sub(r"[^a-z0-9]", "", n)


def classify_font(font_name: str, *, serifed: bool | None = None,
                  monospaced: bool | None = None) -> str:
    """Return the style category for a source font name."""
    n = _normalize(font_name)
    if any(k in n for k in _KUFI_HINTS):
        return "kufi"
    if any(k in n for k in _SCRIPT_HINTS):
        return "script"
    if any(k in n for k in _MONO_HINTS):
        return "mono"
    if any(k in n for k in _SERIF_HINTS):
        return "serif"
    if any(k in n for k in _SANS_HINTS):
        return "sans"
    if monospaced:
        return "mono"
    if serifed is True:
        return "serif"
    if serifed is False:
        return "sans"
    return "serif"  # books default to serif


# --------------------------------------------------------------------------- #
# Font library
# --------------------------------------------------------------------------- #

_STYLE_WORDS = re.compile(
    r"regular|bold|italic|oblique|slant(?:ed)?|black|heavy|semibold|semi"
    r"|extrabold|demi|medium|thin|light|book|variable|wght|\[wght\]",
    re.IGNORECASE)
_BOLD_WORDS = re.compile(r"bold|black|heavy|semibold|semi|extrabold|demi", re.IGNORECASE)
_ITALIC_WORDS = re.compile(r"italic|oblique|slant(?:ed)?|ital", re.IGNORECASE)
_FONT_EXTS = {".ttf", ".otf"}


@dataclass
class FontChoice:
    """The Kurdish font chosen for one text block."""
    family: str
    path: Path | None
    category: str
    simulated_bold: bool = False   # stroke-faked bold (no bold face installed)
    fallback: bool = False         # family lacks full glyph coverage
    coverage: float = 1.0


@dataclass
class _FontEntry:
    regular: Path | None = None
    bold: Path | None = None
    italic: Path | None = None
    bolditalic: Path | None = None
    variable: Path | None = None


class FontLibrary:
    """Scans a directory of Kurdish-capable fonts and resolves choices."""

    def __init__(self, fonts_dir: str | Path, preferred: dict[str, list[str]] | None = None,
                 default: list[str] | None = None):
        self.dir = Path(fonts_dir)
        self.preferred = preferred or {}
        self.default = default or []
        self._fonts: dict[str, _FontEntry] = {}
        self._cmaps: dict[Path, frozenset[int]] = {}
        self.scan()

    # -- scanning -------------------------------------------------------- #

    def scan(self) -> None:
        self._fonts.clear()
        if not self.dir.is_dir():
            return
        for path in sorted(self.dir.iterdir()):
            if path.suffix.lower() not in _FONT_EXTS or not path.is_file():
                continue
            stem = path.stem
            family = _STYLE_WORDS.sub("", stem)
            family = re.sub(r"[^A-Za-z0-9]", "", family).lower()
            if not family:
                family = re.sub(r"[^A-Za-z0-9]", "", stem).lower()
            entry = self._fonts.setdefault(family, _FontEntry())
            variable = "[wght]" in stem or "variable" in stem.lower()
            if variable:
                entry.variable = path
            bold = bool(_BOLD_WORDS.search(stem))
            italic = bool(_ITALIC_WORDS.search(stem))
            if bold and italic:
                entry.bolditalic = entry.bolditalic or path
            elif bold:
                entry.bold = entry.bold or path
            elif italic:
                entry.italic = entry.italic or path
            else:
                entry.regular = entry.regular or path
                if variable:
                    entry.variable = entry.variable or path

    def families(self) -> list[str]:
        return sorted(self._fonts)

    # -- coverage -------------------------------------------------------- #

    def _cmap(self, path: Path) -> frozenset[int]:
        cached = self._cmaps.get(path)
        if cached is not None:
            return cached
        codes: frozenset[int] = frozenset()
        try:
            from fontTools.ttLib import TTFont
            with TTFont(str(path), lazy=True) as font:
                cmap = font.getBestCmap()
                codes = frozenset(cmap.keys()) if cmap else frozenset()
        except Exception as exc:  # fontTools is optional at runtime
            logger.debug("cmap read failed for %s: %s", path, exc)
            codes = frozenset()
        self._cmaps[path] = codes
        return codes

    def coverage(self, path: Path | None, text: str) -> float:
        """Fraction of unique non-space characters of *text* present in *path*."""
        if path is None or not text:
            return 1.0
        needed = {ord(ch) for ch in text if not ch.isspace()}
        if not needed:
            return 1.0
        cmap = self._cmap(Path(path))
        if not cmap:  # fontTools unavailable — assume OK
            return 1.0
        return len(needed & cmap) / len(needed)

    # -- resolution ------------------------------------------------------ #

    def _resolve_style(self, family: str, bold: bool, italic: bool):
        """Return (path, style_key) for the closest installed style."""
        entry = self._fonts.get(_normalize(family))
        if entry is None:
            return None, None
        order = ["bolditalic", "bold", "italic", "regular"]
        wanted = ("bolditalic" if bold and italic
                  else "bold" if bold
                  else "italic" if italic
                  else "regular")
        for key in [wanted] + [k for k in order if k != wanted]:
            path = getattr(entry, key)
            if path is not None:
                return path, key
        if entry.variable is not None:
            return entry.variable, "variable"
        return None, None

    def match(self, *, font_name: str = "", bold: bool = False, italic: bool = False,
              serifed: bool | None = None, monospaced: bool | None = None,
              text: str = "") -> FontChoice:
        """Choose a Kurdish font for one block (see module docstring)."""
        category = classify_font(font_name, serifed=serifed, monospaced=monospaced)
        candidates = list(self.preferred.get(category, [])) + list(self.default)

        best: tuple[str, Path, float] | None = None
        for family in candidates:
            path, style_key = self._resolve_style(family, bold, italic)
            if path is None:
                continue
            simulated_bold = bold and style_key not in ("bold", "bolditalic", "variable")
            ratio = self.coverage(path, text) if text else 1.0
            if ratio >= 1.0:
                return FontChoice(family, path, category,
                                  simulated_bold=simulated_bold, fallback=False,
                                  coverage=1.0)
            if best is None or ratio > best[2]:
                best = (family, path, ratio)

        if best is not None:
            family, path, ratio = best
            _, style_key = self._resolve_style(family, bold, italic)
            simulated = bold and style_key not in ("bold", "bolditalic", "variable")
            return FontChoice(family, path, category, simulated_bold=simulated,
                              fallback=True, coverage=ratio)

        # nothing installed at all — renderer will use a system default
        return FontChoice("(default)", None, category, simulated_bold=bold,
                          fallback=True, coverage=0.0)

    def body_font(self, text: str = "", bold: bool = False) -> FontChoice:
        """Default body font for reflowable output (EPUB/DOCX typesetting)."""
        return self.match(font_name="Times New Roman", bold=bold, text=text)

    def any_font_path(self) -> Path | None:
        for family in self.default:
            path, _ = self._resolve_style(family, False, False)
            if path is not None:
                return path
        for entry in self._fonts.values():
            path = entry.regular or entry.variable or entry.bold
            if path is not None:
                return path
        return None
