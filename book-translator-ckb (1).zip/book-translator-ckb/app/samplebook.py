"""Generate the demo book used by `python -m app.cli demo` and the tests.

The book deliberately exercises every stage of the pipeline:
serif/sans/italic faces, bold headings, justified paragraphs, two columns,
a coloured pull-quote, small footnotes and page numbers.
"""
from __future__ import annotations

from pathlib import Path

import fitz

PAGE_W, PAGE_H = 595, 842  # A4, points


def make_sample_pdf(path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = fitz.open()

    # ---------------- page 1: title page ---------------- #
    page = doc.new_page(width=PAGE_W, height=PAGE_H)
    page.insert_textbox(fitz.Rect(72, 160, 523, 240),
                        "The Little Book of Kurdistan",
                        fontname="tibo", fontsize=28, color=(0.13, 0.16, 0.45),
                        align=fitz.TEXT_ALIGN_CENTER)
    page.insert_textbox(fitz.Rect(72, 260, 523, 300),
                        "A sample book for the translation pipeline",
                        fontname="helv", fontsize=12, color=(0.35, 0.35, 0.35),
                        align=fitz.TEXT_ALIGN_CENTER)
    page.insert_textbox(fitz.Rect(72, 320, 523, 350),
                        "Sample Author",
                        fontname="tiit", fontsize=12, color=(0.1, 0.1, 0.1),
                        align=fitz.TEXT_ALIGN_CENTER)
    page.insert_textbox(fitz.Rect(72, 700, 523, 730),
                        "First Edition",
                        fontname="helv", fontsize=10, color=(0.45, 0.45, 0.45),
                        align=fitz.TEXT_ALIGN_CENTER)

    # ---------------- page 2: chapter with justified body ---------------- #
    page = doc.new_page(width=PAGE_W, height=PAGE_H)
    page.insert_textbox(fitz.Rect(72, 90, 523, 130),
                        "Chapter One — The Mountains",
                        fontname="tibo", fontsize=20, color=(0.1, 0.12, 0.3),
                        align=fitz.TEXT_ALIGN_LEFT)
    page.insert_textbox(
        fitz.Rect(72, 160, 523, 300),
        "The mountains stand high above the valley. Every spring the snow melts "
        "and the rivers run toward the sea. The shepherds move with their flocks "
        "from village to village.",
        fontname="tiro", fontsize=11, align=fitz.TEXT_ALIGN_JUSTIFY)
    page.insert_textbox(
        fitz.Rect(72, 330, 523, 470),
        "In the evening the old men gather in the teahouse. They tell stories "
        "about the past and about the heroes of the land. The tea is hot and "
        "the nights are long.",
        fontname="tiro", fontsize=11, align=fitz.TEXT_ALIGN_JUSTIFY)
    page.insert_textbox(fitz.Rect(272, 780, 323, 800), "2",
                        fontname="helv", fontsize=10, align=fitz.TEXT_ALIGN_CENTER)

    # ---------------- page 3: two columns + pull quote ---------------- #
    page = doc.new_page(width=PAGE_W, height=PAGE_H)
    page.insert_textbox(
        fitz.Rect(60, 90, 285, 300),
        "The valley is green in spring and golden in autumn. Small gardens "
        "surround every house, and the sound of water follows the paths.",
        fontname="tiro", fontsize=11, align=fitz.TEXT_ALIGN_JUSTIFY)
    page.insert_textbox(
        fitz.Rect(310, 90, 535, 300),
        "Language is the road map of a culture. It tells you where its people "
        "come from and where they are going.",
        fontname="helv", fontsize=11, align=fitz.TEXT_ALIGN_JUSTIFY)
    page.insert_textbox(fitz.Rect(140, 380, 455, 440),
                        "A language is a map of the human heart.",
                        fontname="tiit", fontsize=14, color=(0.55, 0.1, 0.1),
                        align=fitz.TEXT_ALIGN_CENTER)
    page.insert_textbox(fitz.Rect(60, 700, 535, 730),
                        "This page was set with mixed serif and sans typefaces.",
                        fontname="helv", fontsize=9, color=(0.4, 0.4, 0.4),
                        align=fitz.TEXT_ALIGN_LEFT)
    page.insert_textbox(fitz.Rect(272, 780, 323, 800), "3",
                        fontname="helv", fontsize=10, align=fitz.TEXT_ALIGN_CENTER)

    doc.save(str(path))
    doc.close()
    return path


def make_scanned_pdf(source: str | Path, target: str | Path,
                     dpi: int = 150) -> Path:
    """Rasterise a text PDF into an image-only 'scan' (for the OCR path)."""
    source, target = Path(source), Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    src = fitz.open(str(source))
    out = fitz.open()
    for page in src:
        pix = page.get_pixmap(dpi=dpi, colorspace=fitz.csRGB, alpha=False)
        new_page = out.new_page(width=page.rect.width, height=page.rect.height)
        new_page.insert_image(new_page.rect, stream=pix.tobytes("png"))
    out.save(str(target))
    out.close()
    src.close()
    return target


if __name__ == "__main__":
    import sys
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("samples/sample_book.pdf")
    make_sample_pdf(target)
    print(f"wrote {target}")
