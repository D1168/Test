"""OCR providers for scanned pages and image inputs.

Providers (first available wins for ``auto``):

* **PaddleOCR** — preferred, per requirements; heavyweight install
  (``pip install paddlepaddle paddleocr``).
* **Tesseract** — lightweight fallback via ``pytesseract``.

Line boxes are grouped into paragraph blocks so translation gets sentence
context and rendering gets a paragraph-sized target box.  Font size, colour
and bold are estimated from the page image (documented heuristics).
"""
from __future__ import annotations

import logging
import statistics
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from app.core.config import OcrConfig
from app.core.models import TextBox, rect_to_poly
from app.extract.pdf_doc import guess_alignment, merge_lines

logger = logging.getLogger(__name__)


class OcrError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
# Availability
# --------------------------------------------------------------------------- #

def _paddle_available() -> bool:
    try:
        import paddleocr  # noqa: F401
        return True
    except Exception:
        return False


def _tesseract_available() -> bool:
    try:
        import pytesseract  # noqa: F401
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def build_ocr_provider(cfg: OcrConfig, override: str | None = None) -> object | None:
    """Return an OCR provider instance, ``None`` when disabled/unavailable."""
    pref = (override or cfg.provider or "auto").lower()
    if pref == "none":
        return None
    if pref == "paddle":
        if not _paddle_available():
            raise OcrError("PaddleOCR requested but not installed "
                           "(pip install paddlepaddle paddleocr)")
        return PaddleOcrProvider(cfg)
    if pref == "tesseract":
        if not _tesseract_available():
            raise OcrError("tesseract requested but not installed")
        return TesseractOcrProvider(cfg)
    # auto
    if _paddle_available():
        return PaddleOcrProvider(cfg)
    if _tesseract_available():
        return TesseractOcrProvider(cfg)
    return None


# --------------------------------------------------------------------------- #
# Shared heuristics
# --------------------------------------------------------------------------- #

@dataclass
class _Line:
    rect: tuple[int, int, int, int]
    text: str
    conf: float = 1.0
    word_h: float = 0.0


def _estimate_style(image: Image.Image, rect: tuple[int, int, int, int]
                    ) -> tuple[tuple[int, int, int], bool]:
    """Estimate text colour and boldness from a line crop (heuristic).

    Background is taken from the border ring; "ink" pixels deviate from it.
    Stroke width is measured with a distance transform and compared to the
    ink height — bold faces have a distinctly larger ratio.
    """
    x0, y0, x1, y1 = rect
    crop = image.crop((max(0, x0), max(0, y0),
                       min(image.width, x1), min(image.height, y1)))
    if crop.width < 2 or crop.height < 2:
        return (0, 0, 0), False
    gray = np.asarray(crop.convert("L"), dtype=np.float32)
    border = np.concatenate([gray[0, :], gray[-1, :], gray[:, 0], gray[:, -1]])
    bg = float(np.median(border)) if border.size else 255.0

    if bg >= 128:   # light background, dark text
        ink = (bg - gray) > 50.0
    else:           # dark background, light text
        ink = (gray - bg) > 50.0
    if ink.sum() < 8:
        return (0, 0, 0) if bg >= 128 else (255, 255, 255), False

    rgb = np.asarray(crop.convert("RGB"))[ink]
    color = tuple(int(v) for v in np.median(rgb, axis=0))

    dist = cv2.distanceTransform(ink.astype(np.uint8), cv2.DIST_L2, 3)
    stroke_w = float(dist.max()) * 2.0
    ink_rows = int(ink.any(axis=1).sum())
    bold = ink_rows > 0 and stroke_w / ink_rows > 0.13
    return color, bold


def _block_from_lines(lines: list[_Line], image: Image.Image, dpi: int) -> TextBox:
    x0 = min(l.rect[0] for l in lines)
    y0 = min(l.rect[1] for l in lines)
    x1 = max(l.rect[2] for l in lines)
    y1 = max(l.rect[3] for l in lines)
    text = merge_lines([l.text for l in lines])

    heights = [l.rect[3] - l.rect[1] for l in lines]
    line_h = float(statistics.median(heights)) if heights else 20.0
    size_pt = max(6.0, line_h * 72.0 / dpi * 0.9)

    colors: list[tuple[int, int, int]] = []
    bolds: list[bool] = []
    for line in lines:
        color, bold = _estimate_style(image, line.rect)
        colors.append(color)
        bolds.append(bold)
    color = tuple(colors[len(colors) // 2]) if colors else (0, 0, 0)
    color = tuple(int(v) for v in color)  # type: ignore[assignment]
    bold = sum(bolds) * 2 > len(bolds)

    return TextBox(
        bbox=(x0, y0, x1, y1),
        text=text,
        font_size_pt=size_pt,
        color=color,  # type: ignore[arg-type]
        bold=bold,
        italic=False,
        font_name="",
        alignment=guess_alignment([l.rect for l in lines], page_w=image.width),
        mask_polys=[rect_to_poly(l.rect) for l in lines],
        dpi=dpi,
        source="ocr",
    )


def group_lines(lines: list[_Line], image: Image.Image, dpi: int) -> list[TextBox]:
    """Cluster horizontally-overlapping, vertically-adjacent lines into blocks.

    Handles multi-column layouts: a line tries to join the most recent open
    blocks (not just the last one) so interleaved columns stay separate.
    """
    if not lines:
        return []
    ordered = sorted(lines, key=lambda l: (l.rect[1], l.rect[0]))
    heights = [l.rect[3] - l.rect[1] for l in ordered]
    median_h = float(statistics.median(heights)) if heights else 20.0

    blocks: list[list[_Line]] = []
    for line in ordered:
        placed = False
        for block in reversed(blocks[-4:]):  # recent open blocks
            prev = block[-1]
            v_gap = line.rect[1] - prev.rect[3]
            overlap = (min(prev.rect[2], line.rect[2])
                       - max(prev.rect[0], line.rect[0]))
            min_w = max(1, min(prev.rect[2] - prev.rect[0],
                               line.rect[2] - line.rect[0]))
            if v_gap < 1.2 * median_h and overlap / min_w > 0.2:
                block.append(line)
                placed = True
                break
        if not placed:
            blocks.append([line])
    return [_block_from_lines(b, image, dpi) for b in blocks if b]


# --------------------------------------------------------------------------- #
# Tesseract
# --------------------------------------------------------------------------- #

class TesseractOcrProvider:
    """Word boxes from tesseract, grouped by its own block/paragraph ids."""
    name = "tesseract"

    def __init__(self, cfg: OcrConfig):
        self.cfg = cfg

    def get_boxes(self, image: Image.Image) -> list[TextBox]:
        import pytesseract
        from pytesseract import Output

        dpi = 300  # boxes are rescaled below using the real DPI
        data = pytesseract.image_to_data(
            image, lang=self.cfg.tesseract_lang, config="--psm 3",
            output_type=Output.DICT)
        lines: dict[tuple[int, int, int], list[_Line]] = {}
        n = len(data["text"])
        for i in range(n):
            word = (data["text"][i] or "").strip()
            conf = float(data["conf"][i])
            if not word or conf < self.cfg.min_confidence * 100:
                continue
            x, y, w, h = (int(data["left"][i]), int(data["top"][i]),
                          int(data["width"][i]), int(data["height"][i]))
            key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            entry = lines.setdefault(key, _Line(rect=[x, y, x + w, y + h], text="", word_h=h))
            entry.rect = [min(entry.rect[0], x), min(entry.rect[1], y),
                          max(entry.rect[2], x + w), max(entry.rect[3], y + h)]
            entry.text = (entry.text + " " + word).strip()
            entry.word_h = max(entry.word_h, h)

        # group tesseract lines into paragraph blocks
        by_par: dict[tuple[int, int], list[_Line]] = {}
        for (block, par, _line), line in lines.items():
            by_par.setdefault((block, par), []).append(line)
        boxes: list[TextBox] = []
        for par_lines in by_par.values():
            boxes.extend(group_lines(par_lines, image, dpi))
        return boxes


# --------------------------------------------------------------------------- #
# PaddleOCR
# --------------------------------------------------------------------------- #

class PaddleOcrProvider:
    """PaddleOCR line quads -> paragraph blocks. Engine use is serialised
    (PaddleOCR is not guaranteed thread-safe)."""
    name = "paddle"
    _lock = __import__("threading").Lock()

    def __init__(self, cfg: OcrConfig):
        self.cfg = cfg
        self._engine = None

    def _get_engine(self):
        if self._engine is None:
            from paddleocr import PaddleOCR
            self._engine = PaddleOCR(use_angle_cls=True, lang=self.cfg.paddle_lang,
                                     show_tesseract_config=False)
        return self._engine

    def get_boxes(self, image: Image.Image) -> list[TextBox]:
        engine = self._get_engine()
        array = np.asarray(image.convert("RGB"))
        with self._lock:
            result = engine.ocr(array, cls=True)
        lines: list[_Line] = []
        for page in result or []:
            entries = page if isinstance(page, list) else []
            for item in entries:
                try:
                    quad, (text, conf) = item[0], item[1]
                except (TypeError, ValueError):
                    continue
                if not text or float(conf) < self.cfg.min_confidence:
                    continue
                xs = [p[0] for p in quad]
                ys = [p[1] for p in quad]
                rect = (int(min(xs)), int(min(ys)), int(max(xs)), int(max(ys)))
                lines.append(_Line(rect=rect, text=text, conf=float(conf),
                                   word_h=rect[3] - rect[1]))
        return group_lines(lines, image, 300)
