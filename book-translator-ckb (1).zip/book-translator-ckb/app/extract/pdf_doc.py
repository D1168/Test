"""PDF page extraction: 300-DPI rasterisation + text-layer block detection.

For pages WITH a real text layer, PyMuPDF's ``get_text("dict")`` provides
blocks -> lines -> spans with bbox, font size, colour, and bold/italic/serif
flags — exactly what the font matcher and renderer need.  Pages without a
text layer (scans) are delegated to the OCR provider.
"""
from __future__ import annotations

import logging
import statistics
from pathlib import Path

import fitz  # PyMuPDF
from PIL import Image

from app.core.models import Document, TextBox, rect_to_poly

logger = logging.getLogger(__name__)

_ITALIC_NAME_KEYS = ("italic", "oblique", "slant", "ital")


def merge_lines(parts: list[str]) -> str:
    """Join extracted lines into one paragraph string (de-hyphenates)."""
    out: list[str] = []
    for part in parts:
        part = " ".join(part.split())
        if out and out[-1].endswith("-") and part[:1].islower():
            out[-1] = out[-1][:-1] + part  # hyphenated word split across lines
        else:
            out.append(part)
    return " ".join(p for p in out if p)


def guess_alignment(line_rects: list[tuple[int, int, int, int]],
                    page_w: int | None = None) -> str:
    """Heuristic: which visual edge do the lines of a block align on?

    Multi-line blocks: compare the spread of left/right edges and centres.
    Single-line blocks: only page-centred text is detectable (titles, page
    numbers); everything else defaults to "left".
    """
    if len(line_rects) <= 1:
        if line_rects and page_w:
            line = line_rects[0]
            center = (line[0] + line[2]) / 2
            if abs(center - page_w / 2) <= page_w * 0.02:
                return "center"
        return "left"
    lefts = [r[0] for r in line_rects]
    rights = [r[2] for r in line_rects]
    centers = [(r[0] + r[2]) / 2 for r in line_rects]

    def spread(values: list[float]) -> float:
        return max(values) - min(values)

    if spread(centers) <= 4.0:
        return "center"
    if spread(lefts) <= spread(rights) + 1.0:
        return "left"
    return "right"


def _int_to_rgb(value: int) -> tuple[int, int, int]:
    return ((value >> 16) & 255, (value >> 8) & 255, value & 255)


class PdfDocument(Document):
    """Fixed-layout PDF: real text layer when available, OCR otherwise."""
    kind = "pdf"

    def __init__(self, path: str | Path, ocr_provider=None):
        super().__init__([Path(path)])
        self.doc = fitz.open(str(path))
        self.ocr = ocr_provider

    @property
    def page_count(self) -> int:
        return self.doc.page_count

    def close(self) -> None:
        self.doc.close()

    # -- rasterisation ---------------------------------------------------- #

    def render_page(self, index: int, dpi: int) -> Image.Image:
        page = self.doc[index]
        try:
            pix = page.get_pixmap(dpi=dpi, colorspace=fitz.csRGB, alpha=False)
        except TypeError:  # older PyMuPDF
            pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72.0, dpi / 72.0),
                                  colorspace=fitz.csRGB, alpha=False)
        return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

    def page_pixel_size(self, index: int, dpi: int) -> tuple[int, int]:
        rect = self.doc[index].rect
        scale = dpi / 72.0
        return max(1, round(rect.width * scale)), max(1, round(rect.height * scale))

    # -- text extraction --------------------------------------------------- #

    def has_text_layer(self, index: int) -> bool:
        try:
            return bool(self.doc[index].get_text("text").strip())
        except Exception:
            return False

    def extract_boxes(self, index: int, dpi: int) -> list[TextBox]:
        if not self.has_text_layer(index):
            return self._ocr_boxes(index, dpi)
        return self._text_layer_boxes(index, dpi)

    # -- text layer --------------------------------------------------------- #

    def _text_layer_boxes(self, index: int, dpi: int) -> list[TextBox]:
        page = self.doc[index]
        scale = dpi / 72.0
        rotation = page.rotation_matrix if page.rotation else None
        page_w, page_h = self.page_pixel_size(index, dpi)
        boxes: list[TextBox] = []

        raw = page.get_text("dict")
        for block in raw.get("blocks", []):
            if block.get("type") != 0:
                continue  # image block
            line_texts: list[str] = []
            line_rects: list[fitz.Rect] = []
            sizes: list[float] = []
            colors: list[int] = []
            bolds: list[bool] = []
            italics: list[bool] = []
            names: list[str] = []
            serifed_flags: list[bool] = []

            for line in block.get("lines", []):
                spans = line.get("spans", [])
                if not spans:
                    continue
                text = "".join(s.get("text", "") for s in spans).strip()
                if not text:
                    continue
                line_texts.append(text)
                line_rects.append(fitz.Rect(line["bbox"]))
                main = max(spans, key=lambda s: len(s.get("text", "")))
                sizes.append(float(main.get("size", 12.0)))
                colors.append(int(main.get("color", 0)))
                flags = int(main.get("flags", 0))
                font_name = str(main.get("font", "")).split("+")[-1]
                names.append(font_name)
                bolds.append(bool(flags & 16) or "bold" in font_name.lower())
                italics.append(bool(flags & 2)
                               or any(k in font_name.lower() for k in _ITALIC_NAME_KEYS))
                serifed_flags.append(bool(flags & 4))

            if not line_texts:
                continue

            block_rect = fitz.Rect(block["bbox"])
            if block_rect.is_empty or not line_rects:
                block_rect = line_rects[0]
            for r in line_rects:
                block_rect |= r

            def to_pixels(rect: fitz.Rect) -> tuple[int, int, int, int]:
                if rotation is not None:
                    rect = rect * rotation
                x0 = max(0, min(round(rect.x0 * scale), page_w))
                y0 = max(0, min(round(rect.y0 * scale), page_h))
                x1 = max(0, min(round(rect.x1 * scale), page_w))
                y1 = max(0, min(round(rect.y1 * scale), page_h))
                return (x0, y0, max(x1, x0 + 1), max(y1, y0 + 1))

            pixel_rects = [to_pixels(r) for r in line_rects]
            block_px = to_pixels(block_rect)
            if block_px[2] - block_px[0] < 4 or block_px[3] - block_px[1] < 4:
                continue

            color = _int_to_rgb(int(statistics.median(colors)) if colors else 0)
            boxes.append(TextBox(
                bbox=block_px,
                text=merge_lines(line_texts),
                font_size_pt=float(statistics.median(sizes)) if sizes else 12.0,
                color=color,
                bold=sum(bolds) * 2 > len(bolds),
                italic=sum(italics) * 2 > len(italics),
                font_name=statistics.mode(names) if names else "",
                alignment=guess_alignment(pixel_rects, page_w=page_w),
                mask_polys=[rect_to_poly(r) for r in pixel_rects],
                dpi=dpi,
                source="text",
                serifed=statistics.mode(serifed_flags) if serifed_flags else None,
                monospaced=False,
            ))
        return boxes

    # -- OCR fallback -------------------------------------------------------- #

    def _ocr_boxes(self, index: int, dpi: int) -> list[TextBox]:
        if self.ocr is None:
            raise RuntimeError(
                "page has no text layer and no OCR provider is available — "
                "install PaddleOCR (paddlepaddle + paddleocr) or tesseract "
                "(see README 'OCR extras')")
        image = self.render_page(index, dpi)
        boxes = self.ocr.get_boxes(image)
        for box in boxes:
            box.source = "ocr"
        return boxes
