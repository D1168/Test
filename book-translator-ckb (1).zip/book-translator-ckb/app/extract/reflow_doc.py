"""Reflowable sources (EPUB, DOCX) -> chapters of styled text blocks.

These have no fixed page layout, so the pipeline translates first and then
re-typesets the Kurdish text onto fresh pages (PDF) or into a new
EPUB/DOCX.  Blocks carry font hints so the font matcher still applies.
"""
from __future__ import annotations

import logging
import statistics
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

_HEADING_SIZES = {"h1": 20.0, "h2": 16.0, "h3": 14.0, "h4": 12.5}


@dataclass
class ReflowBlock:
    text: str
    kind: str = "body"               # "heading" | "body"
    size_pt: float = 11.0
    bold: bool = False
    italic: bool = False
    font_name: str = "Times New Roman"
    color: tuple[int, int, int] = (0, 0, 0)


@dataclass
class Chapter:
    title: str = ""
    blocks: list[ReflowBlock] = field(default_factory=list)


class ReflowDocument:
    """Common interface for EPUB/DOCX: chapters() + chapter count."""
    kind = "reflow"

    def __init__(self, path: str | Path):
        self.path = Path(path)

    @property
    def page_count(self) -> int:  # progress units = chapters
        return len(self.chapters())

    def title(self) -> str:
        return self.path.stem

    def chapters(self) -> list[Chapter]:
        raise NotImplementedError


# --------------------------------------------------------------------------- #
# EPUB
# --------------------------------------------------------------------------- #

class EpubDocument(ReflowDocument):
    kind = "epub"

    def __init__(self, path: str | Path):
        super().__init__(path)
        self._chapters: list[Chapter] | None = None
        self._title: str | None = None

    def title(self) -> str:
        if self._title is None:
            self._load()
        return self._title or self.path.stem

    def chapters(self) -> list[Chapter]:
        if self._chapters is None:
            self._load()
        return self._chapters or []

    def _load(self) -> None:
        import ebooklib
        from ebooklib import epub
        from bs4 import BeautifulSoup

        book = epub.read_epub(str(self.path))
        try:
            meta = book.get_metadata("DC", "title")
            self._title = str(meta[0][0]) if meta else None
        except Exception:
            self._title = None

        chapters: list[Chapter] = []
        for item_id, _linear in book.spine:
            item = book.get_item_with_id(item_id) if item_id else None
            if item is None or not getattr(item, "content", None):
                continue
            if isinstance(item, epub.EpubNav):
                continue
            soup = BeautifulSoup(item.get_content() or b"", "html.parser")
            blocks: list[ReflowBlock] = []
            chapter_title = ""
            for el in soup.find_all(
                    ["h1", "h2", "h3", "h4", "p", "li", "blockquote"]):
                if el.find(["p", "li", "h1", "h2", "h3", "h4", "blockquote"]):
                    continue  # container element; leaves are visited separately
                text = " ".join(el.get_text(" ", strip=True).split())
                if not text:
                    continue
                if el.name in _HEADING_SIZES:
                    if not chapter_title:
                        chapter_title = text
                    blocks.append(ReflowBlock(
                        text=text, kind="heading", size_pt=_HEADING_SIZES[el.name],
                        bold=True, font_name="Arial"))
                else:
                    blocks.append(ReflowBlock(text=text))
            if blocks:
                chapters.append(Chapter(title=chapter_title, blocks=blocks))
        self._chapters = chapters


# --------------------------------------------------------------------------- #
# DOCX
# --------------------------------------------------------------------------- #

class DocxDocument(ReflowDocument):
    kind = "docx"

    def __init__(self, path: str | Path):
        super().__init__(path)
        self._chapters: list[Chapter] | None = None
        self._title: str | None = None

    def title(self) -> str:
        if self._title is None:
            self._load()
        return self._title or self.path.stem

    def chapters(self) -> list[Chapter]:
        if self._chapters is None:
            self._load()
        return self._chapters or []

    def _load(self) -> None:
        from docx import Document as read_document

        doc = read_document(str(self.path))
        self._title = (doc.core_properties.title or "").strip() or None

        chapters: list[Chapter] = [Chapter(title="")]
        for para in doc.paragraphs:
            text = " ".join((para.text or "").split())
            if not text:
                continue
            style = (para.style.name if para.style is not None else "") or ""

            sizes: list[float] = []
            bold_flags: list[bool] = []
            names: list[str] = []
            color = (0, 0, 0)
            for run in para.runs:
                if run.font.size is not None:
                    sizes.append(run.font.size.pt)
                bold_flags.append(bool(run.font.bold))
                if run.font.name:
                    names.append(run.font.name)
                try:
                    if run.font.color and run.font.color.rgb:
                        rgb = str(run.font.color.rgb)
                        color = (int(rgb[0:2], 16), int(rgb[2:4], 16), int(rgb[4:6], 16))
                except Exception:
                    pass

            size = statistics.median(sizes) if sizes else 11.0
            font_name = statistics.mode(names) if names else "Times New Roman"
            bold = sum(bold_flags) * 2 > len(bold_flags) if bold_flags else False

            if style in ("Title", "Subtitle"):
                # front-matter heading stays inside the current chapter
                chapters[-1].blocks.append(ReflowBlock(
                    text=text, kind="heading", size_pt=22.0 if style == "Title" else 16.0,
                    bold=True, font_name="Arial"))
            elif style.startswith("Heading"):
                level = style.split()[-1] if style.split()[-1].isdigit() else "1"
                size = _HEADING_SIZES.get(f"h{level}", 16.0)
                major = level in ("1",) or style == "Heading"
                if major:
                    if chapters[-1].blocks or chapters[-1].title:
                        chapters.append(Chapter(title=text))
                    else:
                        chapters[-1].title = text
                chapters[-1].blocks.append(ReflowBlock(
                    text=text, kind="heading", size_pt=size, bold=True,
                    font_name="Arial", color=color))
            else:
                chapters[-1].blocks.append(ReflowBlock(
                    text=text, size_pt=float(size), bold=bold,
                    italic=False, font_name=font_name, color=color))

        self._chapters = [c for c in chapters if c.blocks]
