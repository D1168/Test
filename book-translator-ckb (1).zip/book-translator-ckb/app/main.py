"""FastAPI application factory."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.api.routes import router
from app.core.config import ensure_dirs, load_config
from app.core.jobs import JobManager

logger = logging.getLogger(__name__)
_STATIC_DIR = Path(__file__).resolve().parent / "web" / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    manager: JobManager = app.state.manager
    demoted = manager.recover_interrupted()
    if demoted:
        logger.info("marked %d interrupted job(s) from a previous run", demoted)
    yield


def create_app(config_path: str | None = None) -> FastAPI:
    config = load_config(config_path)
    ensure_dirs(config)

    app = FastAPI(
        title="book-translator-ckb",
        description="Translate books into Kurdish Sorani (ckb), page by page.",
        version=__version__,
        lifespan=lifespan)
    app.state.config = config
    app.state.manager = JobManager(config)
    app.include_router(router)
    app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(_STATIC_DIR / "index.html")

    return app


app = create_app()
