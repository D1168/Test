"""Command-line interface.

    python -m app.cli serve                 # start the web app
    python -m app.cli translate BOOK.pdf    # one-shot translation with progress bar
    python -m app.cli resume JOB_ID         # resume an interrupted/failed job
    python -m app.cli demo                  # offline demo on the sample book
    python -m app.cli jobs                  # list jobs
    python -m app.cli fonts                 # list installed Kurdish fonts
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from tqdm import tqdm


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="book-translator-ckb",
        description="Translate books into Kurdish Sorani (ckb), page by page.")
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve", help="start the FastAPI web app")
    serve.add_argument("--host", default=None)
    serve.add_argument("--port", type=int, default=None)
    serve.add_argument("--config", default=None)

    translate = sub.add_parser("translate", help="translate a book file")
    translate.add_argument("input", help="PDF / EPUB / DOCX file or image(s)")
    translate.add_argument("extra_inputs", nargs="*", help="additional page images")
    translate.add_argument("-o", "--output-format", default="auto",
                           choices=("auto", "pdf", "epub", "docx"))
    translate.add_argument("--engine", default=None,
                           choices=("google", "mock", "passthrough"))
    translate.add_argument("--dpi", type=int, default=None)
    translate.add_argument("--post-edit", dest="post_edit", action="store_true",
                           default=None)
    translate.add_argument("--no-post-edit", dest="post_edit", action="store_false")
    translate.add_argument("--alignment", default=None,
                           choices=("auto", "mirror", "preserve", "right"))
    translate.add_argument("--workers", type=int, default=None)
    translate.add_argument("--ocr", default=None,
                           choices=("auto", "paddle", "tesseract", "none"))
    translate.add_argument("--config", default=None)

    resume = sub.add_parser("resume", help="resume a previous job")
    resume.add_argument("job_id")
    resume.add_argument("--config", default=None)

    demo = sub.add_parser("demo", help="generate + translate the sample book offline")
    demo.add_argument("--dpi", type=int, default=200)
    demo.add_argument("--config", default=None)

    sub.add_parser("jobs", help="list jobs")
    sub.add_parser("fonts", help="list installed Kurdish fonts")
    return parser


def _load(args):
    from app.core.config import load_config
    return load_config(getattr(args, "config", None))


def cmd_serve(args) -> int:
    import uvicorn
    from app.main import create_app
    config = _load(args)
    app = create_app(getattr(args, "config", None))
    uvicorn.run(app, host=args.host or config.server.host,
                port=args.port or config.server.port, log_level="info")
    return 0


def _run_sync(state, config, cancel=None) -> int:
    """Run a BookJob in the current thread with a tqdm progress bar."""
    from app.core.jobs import JobManager
    from app.core.pipeline import BookJob
    manager = JobManager(config)
    job = BookJob(state, config, cancel_event=cancel)
    job.persist_hook = lambda: manager.save(job.state)

    bar = tqdm(total=len(state.pages), unit="pg", colour="#2dd4bf",
               desc=state.input_name[:40])

    def hook(_index, status):
        bar.update(1)
        if status == "failed":
            bar.write(f"  page {_index}: FAILED")

    job.progress_hook = hook
    job.run()
    bar.close()

    manager.save(job.state)
    state = job.state
    print(f"\nstatus : {state.status}")
    print(f"pages  : {state.progress()}")
    print(f"stats  : {state.stats}")
    if state.error:
        print(f"error  : {state.error}")
    if state.output:
        print(f"output : {state.output}")
    if state.status == "completed":
        return 0
    if state.status == "completed_with_errors":
        return 0
    return 1


def cmd_translate(args) -> int:
    from app.core.config import runtime_options
    from app.core.jobs import JobManager
    from app.extract import classify_input
    config = _load(args)

    paths = [str(Path(args.input).resolve())]
    for extra in args.extra_inputs:
        paths.append(str(Path(extra).resolve()))
    try:
        input_type = classify_input([Path(p).name for p in paths])
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    overrides = {k: v for k, v in {
        "engine": args.engine, "dpi": args.dpi, "post_edit": args.post_edit,
        "output_format": args.output_format, "alignment": args.alignment,
        "page_workers": args.workers, "ocr_provider": args.ocr,
    }.items() if v is not None}
    options = runtime_options(config, overrides)

    manager = JobManager(config)
    state = manager.create(paths, Path(paths[0]).name, input_type, options)
    return _run_sync(state, config)


def cmd_resume(args) -> int:
    from app.core.jobs import JobManager
    config = _load(args)
    manager = JobManager(config)
    try:
        state = manager.load(args.job_id)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    for page in state.pages:
        if page.status == "failed":
            page.status = "pending"
            page.error = None
    state.status = "pending"
    manager.save(state)
    return _run_sync(state, config)


def cmd_demo(args) -> int:
    from app.core.config import runtime_options
    from app.core.jobs import JobManager
    from app.samplebook import make_sample_pdf
    config = _load(args)
    root = config.base_dir
    samples = root / "samples"
    samples.mkdir(exist_ok=True)
    sample = samples / "sample_book.pdf"
    if not sample.is_file():
        make_sample_pdf(sample)
        print(f"generated sample book: {sample}")

    options = runtime_options(config, {"engine": "mock", "dpi": args.dpi})
    manager = JobManager(config)
    state = manager.create([str(sample)], sample.name, "pdf", options)
    print("translating with the offline mock engine "
          "(set engine: google in config.yaml for real translations)\n")
    return _run_sync(state, config)


def cmd_jobs(args) -> int:
    from app.core.jobs import JobManager
    config = _load(args)
    manager = JobManager(config)
    states = manager.list_jobs()
    if not states:
        print("no jobs yet — try: python -m app.cli demo")
        return 0
    print(f"{'job id':32} {'status':22} {'done/total':>10}  input")
    for state in states:
        progress = state.progress()
        print(f"{state.id:32} {state.status:22} "
              f"{progress['done']}/{progress['total']:>4}  {state.input_name}")
    return 0


def cmd_fonts(args) -> int:
    from app.font_match import FontLibrary
    from app.render import RAQM_AVAILABLE
    config = _load(args)
    library = FontLibrary(config.base_dir / config.fonts.dir,
                          config.fonts.preferred, config.fonts.default)
    print(f"raqm (HarfBuzz) rendering: {'yes' if RAQM_AVAILABLE else 'no — using arabic-reshaper + python-bidi'}")
    families = library.families()
    if not families:
        print(f"no fonts found in {config.fonts.dir!r} — run scripts/fetch_fonts.sh")
        return 1
    print(f"{len(families)} font families in {config.fonts.dir!r}:")
    for family in families:
        entry = library._fonts[family]
        styles = [k for k in ("regular", "bold", "italic", "bolditalic", "variable")
                  if getattr(entry, k)]
        print(f"  {family:24} [{', '.join(styles)}]")
    return 0


def main(argv=None) -> int:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    args = _build_parser().parse_args(argv)
    handlers = {"serve": cmd_serve, "translate": cmd_translate,
                "resume": cmd_resume, "demo": cmd_demo,
                "jobs": cmd_jobs, "fonts": cmd_fonts}
    return handlers[args.command](args)


if __name__ == "__main__":
    raise SystemExit(main())
