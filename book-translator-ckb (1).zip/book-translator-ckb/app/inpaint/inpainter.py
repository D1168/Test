"""Remove the original text from a page image via OpenCV inpainting.

A binary mask is built from the tight glyph bounding boxes (PDF spans or OCR
quads), dilated a few pixels to cover anti-aliased edges, then restored with
Telea / Navier-Stokes inpainting.  If the ``simple-lama-inpainting`` package
is installed, the higher-quality LaMa model can be used instead
(``inpaint.method: lama``).
"""
from __future__ import annotations

import logging

import cv2
import numpy as np
from PIL import Image

from app.core.models import TextBox

logger = logging.getLogger(__name__)


def build_mask(image_size: tuple[int, int], boxes: list[TextBox],
               dilate_px: int = 3) -> np.ndarray:
    """Binary mask (uint8, 255 = remove) covering all text in *boxes*."""
    width, height = image_size
    mask = np.zeros((height, width), dtype=np.uint8)
    polys: list[np.ndarray] = []
    for box in boxes:
        if box.mask_polys:
            polys.extend(np.asarray(poly, dtype=np.int32).reshape(-1, 1, 2)
                         for poly in box.mask_polys)
        else:
            x0, y0, x1, y1 = box.bbox
            polys.append(np.array([[[x0, y0]], [[x1, y0]], [[x1, y1]], [[x0, y1]]],
                                  dtype=np.int32))
    if polys:
        cv2.fillPoly(mask, polys, 255)
    if dilate_px > 0:
        kernel = np.ones((dilate_px, dilate_px), dtype=np.uint8)
        mask = cv2.dilate(mask, kernel)
    return mask


def _lama(image: Image.Image, mask: np.ndarray) -> Image.Image:
    from simple_lama_inpainting import SimpleLama  # optional dependency
    return SimpleLama()(image.convert("RGB"), Image.fromarray(mask))


def inpaint_image(image: Image.Image, boxes: list[TextBox], *,
                  method: str = "telea", radius: int = 3,
                  dilate_px: int = 3) -> Image.Image:
    """Return a copy of *image* with the text of *boxes* cleanly removed."""
    image = image.convert("RGB")
    mask = build_mask(image.size, boxes, dilate_px)
    if not mask.any():
        return image

    if method == "lama":
        try:
            return _lama(image, mask)
        except ImportError:
            logger.warning("simple-lama-inpainting not installed; "
                           "falling back to OpenCV Telea")
        except Exception as exc:
            logger.warning("LaMa inpainting failed (%s); using Telea", exc)

    arr = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)
    flag = cv2.INPAINT_NS if method == "ns" else cv2.INPAINT_TELEA
    restored = cv2.inpaint(arr, mask, max(1, int(radius)), flag)
    return Image.fromarray(cv2.cvtColor(restored, cv2.COLOR_BGR2RGB))
