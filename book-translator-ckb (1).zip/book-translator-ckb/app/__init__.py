"""book-translator-ckb — translate books into Kurdish Sorani (ckb), page by page."""

__version__ = "0.1.0"
