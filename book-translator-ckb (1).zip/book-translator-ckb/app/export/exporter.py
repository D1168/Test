"""Output assembly: page images -> PDF, translated chapters -> EPUB / DOCX."""
from __future__ import annotations

import html
import logging
import uuid
from pathlib import Path

from PIL import Image

logger = logging.getLogger(__name__)

A4_PT = (595.0, 842.0)


# --------------------------------------------------------------------------- #
# PDF (fixed-layout pipeline: one image per page, order preserved)
# --------------------------------------------------------------------------- #

def export_pdf(image_paths: list[Path], out_path: Path, dpi: int = 300,
               image_format: str = "png", jpeg_quality: int = 85) -> Path:
    """Assemble rendered page images into a PDF at the original page size."""
    paths = [Path(p) for p in image_paths]
    if not paths:
        raise ValueError("no page images to export")

    tmp_dir: Path | None = None
    if image_format == "jpeg":
        tmp_dir = paths[0].parent / "_jpeg_tmp"
        tmp_dir.mkdir(exist_ok=True)
        converted: list[Path] = []
        for i, p in enumerate(paths):
            target = tmp_dir / f"page_{i:04d}.jpg"
            if not target.is_file():
                with Image.open(p) as img:
                    img.convert("RGB").save(target, "JPEG", quality=jpeg_quality)
            converted.append(target)
        paths = converted

    try:
        import img2pdf
        layout = img2pdf.get_fixed_dpi_layout_fun((dpi, dpi))
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "wb") as fh:
            fh.write(img2pdf.convert([str(p) for p in paths], layout_fun=layout))
    except ImportError:
        logger.info("img2pdf not available; using Pillow PDF writer")
        images = [Image.open(p).convert("RGB") for p in paths]
        out_path.parent.mkdir(parents=True, exist_ok=True)
        images[0].save(out_path, "PDF", save_all=True, append_images=images[1:],
                       resolution=dpi)
        for img in images:
            img.close()
    finally:
        if tmp_dir is not None:
            for p in tmp_dir.glob("*.jpg"):
                p.unlink()
            tmp_dir.rmdir()
    return out_path


# --------------------------------------------------------------------------- #
# EPUB (reflowable pipeline)
# --------------------------------------------------------------------------- #

_EPUB_CSS = """
@charset "utf-8";
body { direction: rtl; text-align: right; font-family: "KurdishBody", serif;
       line-height: 1.6; margin: 1em; }
h1, h2, h3, h4 { font-family: "KurdishBody", sans-serif; }
"""


def _dedup_blocks(chapter_title: str,
                  blocks: list[tuple[str, bool, float]]) -> list[tuple[str, bool, float]]:
    """Drop heading blocks that duplicate the chapter title (the reader
    sets Chapter.title from the first heading AND keeps it as a block)."""
    norm_title = " ".join((chapter_title or "").split()).strip().lower()
    if not norm_title:
        return list(blocks)
    out = []
    for text, is_heading, size_pt in blocks:
        if is_heading and " ".join(text.split()).strip().lower() == norm_title:
            continue
        out.append((text, is_heading, size_pt))
    return out


def build_epub(title: str, chapters: list[tuple[str, list[tuple[str, bool, float]]]],
               out_path: Path, font_path: Path | None = None) -> Path:
    """Write a right-to-left EPUB.

    ``chapters`` is a list of ``(chapter_title, [(text, is_heading, size_pt)])``.
    When *font_path* points to a Kurdish TTF it is embedded via @font-face.
    """
    from ebooklib import epub

    book = epub.EpubBook()
    book.set_identifier(uuid.uuid4().hex)
    book.set_title(title or "Translated Book")
    book.add_author("book-translator-ckb")
    book.set_language("ckb")

    css = _EPUB_CSS
    if font_path is not None and Path(font_path).is_file():
        font_item = epub.EpubItem(
            uid="font-body", file_name=f"fonts/{Path(font_path).name}",
            media_type="application/x-font-ttf",
            content=Path(font_path).read_bytes())
        book.add_item(font_item)
        css += ("\n@font-face { font-family: 'KurdishBody'; "
                f"src: url('fonts/{Path(font_path).name}'); }}")

    style = epub.EpubItem(uid="style-main", file_name="style/main.css",
                          media_type="text/css", content=css.encode("utf-8"))
    book.add_item(style)

    spine: list = []
    for index, (chapter_title, blocks) in enumerate(chapters):
        file_name = f"chap_{index:03d}.xhtml"
        epub_ch = epub.EpubHtml(title=chapter_title or f"Chapter {index + 1}",
                                file_name=file_name, lang="ckb")
        parts: list[str] = []
        if chapter_title:
            parts.append(f"<h1>{html.escape(chapter_title)}</h1>")
        for text, is_heading, _size in _dedup_blocks(chapter_title, blocks):
            tag = "h2" if is_heading else "p"
            parts.append(f"<{tag}>{html.escape(text)}</{tag}>")
        epub_ch.set_content("\n".join(parts))
        epub_ch.add_item(style)
        book.add_item(epub_ch)
        spine.append(epub_ch)

    book.toc = spine
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    book.spine = ["nav"] + spine

    out_path.parent.mkdir(parents=True, exist_ok=True)
    epub.write_epub(str(out_path), book)
    return out_path


# --------------------------------------------------------------------------- #
# DOCX (reflowable pipeline)
# --------------------------------------------------------------------------- #

def _make_rtl_paragraph(docx_doc, text: str, font_name: str, size_pt: float,
                        bold: bool, align_center: bool = False,
                        style: str | None = None):
    """Add a right-to-left paragraph with proper bidi/run markup."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor

    para = docx_doc.add_paragraph() if style is None \
        else docx_doc.add_paragraph(style=style)
    para.alignment = (WD_ALIGN_PARAGRAPH.CENTER if align_center
                      else WD_ALIGN_PARAGRAPH.RIGHT)
    pPr = para._p.get_or_add_pPr()
    bidi = OxmlElement("w:bidi")
    bidi.set(qn("w:val"), "1")
    pPr.append(bidi)

    run = para.add_run(text)
    run.font.name = font_name
    run.font.size = Pt(max(6.0, float(size_pt)))
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)
    rPr = run._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), font_name)
    rFonts.set(qn("w:hAnsi"), font_name)
    rFonts.set(qn("w:cs"), font_name)
    szCs = OxmlElement("w:szCs")
    szCs.set(qn("w:val"), str(int(max(6.0, float(size_pt)) * 2)))
    rPr.append(szCs)
    rtl = OxmlElement("w:rtl")
    rtl.set(qn("w:val"), "1")
    rPr.append(rtl)
    return para


def build_docx(title: str, chapters: list[tuple[str, list[tuple[str, bool, float]]]],
               out_path: Path, font_name: str = "Amiri") -> Path:
    """Write a right-to-left DOCX with the translated chapters."""
    from docx import Document as new_document

    docx_doc = new_document()
    if title:
        _make_rtl_paragraph(docx_doc, title, font_name, 24.0, True,
                            align_center=True, style="Title")
    for chapter_title, blocks in chapters:
        if chapter_title:
            _make_rtl_paragraph(docx_doc, chapter_title, font_name, 18.0, True,
                                style="Heading 1")
        for text, is_heading, size_pt in _dedup_blocks(chapter_title, blocks):
            _make_rtl_paragraph(docx_doc, text, font_name,
                                14.0 if is_heading else size_pt, is_heading,
                                style="Heading 2" if is_heading else None)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    docx_doc.save(str(out_path))
    return out_path
