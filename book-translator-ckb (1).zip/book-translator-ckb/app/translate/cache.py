"""SQLite translation cache — survive retries, resumes and re-runs."""
from __future__ import annotations

import hashlib
import sqlite3
import threading
from pathlib import Path
from typing import Iterable


def cache_key(engine: str, source_lang: str, target_lang: str, text: str,
              post_edit: bool = False) -> str:
    """Stable key for one (text, direction, engine, stage) tuple."""
    payload = "|".join((engine, source_lang or "auto", target_lang,
                        "pe" if post_edit else "mt", text))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class TranslationCache:
    """Thread-safe SQLite cache (single connection guarded by a lock)."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        with self._lock:
            self._conn.execute(
                "CREATE TABLE IF NOT EXISTS translations ("
                " key TEXT PRIMARY KEY, engine TEXT NOT NULL,"
                " source_lang TEXT NOT NULL, target_lang TEXT NOT NULL,"
                " source TEXT NOT NULL, result TEXT NOT NULL,"
                " created TEXT DEFAULT CURRENT_TIMESTAMP)")
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_engine ON translations(engine)")
            self._conn.commit()

    # -- API ------------------------------------------------------------- #

    def get_many(self, keys: Iterable[str]) -> dict[str, str]:
        keys = list(keys)
        if not keys:
            return {}
        found: dict[str, str] = {}
        with self._lock:
            for i in range(0, len(keys), 500):
                chunk = keys[i:i + 500]
                placeholders = ",".join("?" * len(chunk))
                rows = self._conn.execute(
                    f"SELECT key, result FROM translations WHERE key IN ({placeholders})",
                    chunk).fetchall()
                found.update(rows)
        return found

    def put_many(self, entries: dict[str, tuple[str, str, str, str, str]]) -> None:
        """``{key: (engine, source_lang, target_lang, source_text, result)}``."""
        if not entries:
            return
        rows = [(k, *v) for k, v in entries.items()]
        with self._lock:
            self._conn.executemany(
                "INSERT OR REPLACE INTO translations"
                " (key, engine, source_lang, target_lang, source, result)"
                " VALUES (?, ?, ?, ?, ?, ?)", rows)
            self._conn.commit()

    def count(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM translations").fetchone()[0])

    def close(self) -> None:
        with self._lock:
            self._conn.close()
