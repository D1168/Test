"""Translation service: cache -> engine (batched) -> optional Claude post-edit.

Deduplicates repeated segments (headers, page numbers), keeps result order
stable, and accumulates stats for the job page.
"""
from __future__ import annotations

import threading
from typing import Sequence

from app.core.config import TranslationConfig, PostEditConfig
from app.translate.cache import TranslationCache, cache_key
from app.translate.engines import BaseTranslator, ClaudePostEditor


class TranslationService:
    def __init__(self, engine: BaseTranslator, cache: TranslationCache | None = None,
                 post_editor: ClaudePostEditor | None = None,
                 source_language: str = "auto", target_language: str = "ckb"):
        self.engine = engine
        self.cache = cache
        self.post_editor = post_editor
        self.source_language = source_language
        self.target_language = target_language
        self.stats = {"cache_hits": 0, "engine_calls": 0,
                      "engine_texts": 0, "post_edits": 0}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ #

    def translate(self, texts: Sequence[str]) -> list[str]:
        """Translate a list of texts; returns results in the same order."""
        unique: list[str] = []
        seen: set[str] = set()
        for t in texts:
            t = (t or "").strip()
            if t and t not in seen:
                seen.add(t)
                unique.append(t)

        results: dict[str, str] = {}

        # ---- machine translation (cached) ----
        mt_keys = {t: cache_key(self.engine.name, self.source_language,
                                self.target_language, t, post_edit=False)
                   for t in unique}
        cached_mt: dict[str, str] = {}
        if self.cache is not None:
            cached_mt = self.cache.get_many(mt_keys.values())
            for t, key in mt_keys.items():
                if key in cached_mt:
                    results[t] = cached_mt[key]

        missing = [t for t in unique if t not in results]
        if missing:
            fresh = self.engine.translate(missing)
            if len(fresh) != len(missing):
                raise RuntimeError(
                    f"engine {self.engine.name!r} returned {len(fresh)} "
                    f"results for {len(missing)} texts")
            results.update(zip(missing, fresh))
            if self.cache is not None:
                self.cache.put_many({
                    mt_keys[t]: (self.engine.name, self.source_language,
                                 self.target_language, t, results[t])
                    for t in missing})
            with self._lock:
                self.stats["engine_calls"] += 1
                self.stats["engine_texts"] += len(missing)

        with self._lock:
            self.stats["cache_hits"] += len(cached_mt)

        # ---- optional Claude post-edit pass ---- #
        if self.post_editor is not None:
            pe_keys = {t: cache_key(self.engine.name, self.source_language,
                                    self.target_language, t, post_edit=True)
                       for t in unique}
            cached_pe: dict[str, str] = {}
            if self.cache is not None:
                cached_pe = self.cache.get_many(pe_keys.values())
            for t, key in pe_keys.items():
                if key in cached_pe:
                    results[t] = cached_pe[key]
            pe_missing = [t for t in unique if pe_keys[t] not in cached_pe]
            if pe_missing:
                polished = self.post_editor.polish(
                    pe_missing, [results[t] for t in pe_missing])
                for t, p in zip(pe_missing, polished):
                    results[t] = p
                if self.cache is not None:
                    self.cache.put_many({
                        pe_keys[t]: (self.engine.name, self.source_language,
                                     self.target_language, t, results[t])
                        for t in pe_missing})
                with self._lock:
                    self.stats["post_edits"] += len(pe_missing)

        return [results.get((t or "").strip(), "") for t in texts]

    def snapshot_stats(self) -> dict:
        with self._lock:
            return dict(self.stats)
