# Font licenses

All bundled fonts are licensed under the SIL Open Font License, Version 1.1
(http://scripts.sil.org/OFL). The full license text is available at that URL
and is included in each font's upstream release archive.

| Family              | Styles shipped                 | Upstream |
|---------------------|--------------------------------|----------|
| Amiri               | Regular, Bold, Italic, BoldItalic | https://github.com/aliftype/amiri |
| Noto Naskh Arabic   | Regular, Bold                  | https://github.com/notofonts (Google) |
| Noto Kufi Arabic    | Regular, Bold                  | https://github.com/notofonts (Google) |
| Scheherazade New    | Regular, Bold                  | https://software.sil.org/scheherazade/ |
| Vazirmatn           | Regular, Bold                  | https://github.com/rastikerdar/vazirmatn |

To re-fetch or update the fonts, run `python scripts/fetch_fonts.py`.
